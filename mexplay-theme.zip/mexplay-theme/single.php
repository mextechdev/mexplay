<?php
/**
 * The template for displaying all single posts
 *
 * @package MexPlay_Theme
 */

get_header();
?>

<div id="primary" class="content-area">
    <main id="main" class="site-main">
        <div class="mexplay-container">
            
            <?php
            while (have_posts()) :
                the_post();
                
                if (mexplay_theme_is_restricted() && !mexplay_theme_user_has_subscription()) {
                    // Show restricted content message
                    mexplay_theme_restricted_content_message();
                } else {
                    ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class('mexplay-card'); ?>>
                        <header class="entry-header">
                            <?php the_title('<h1 class="entry-title mexplay-card-title">', '</h1>'); ?>
                            
                            <div class="entry-meta">
                                <span class="posted-on">
                                    <?php
                                    echo '<i class="far fa-calendar-alt"></i> ';
                                    echo '<time class="entry-date published" datetime="' . esc_attr(get_the_date('c')) . '">' . esc_html(get_the_date()) . '</time>';
                                    ?>
                                </span>
                                <span class="byline">
                                    <?php
                                    echo '<i class="far fa-user"></i> ';
                                    echo '<span class="author vcard"><a href="' . esc_url(get_author_posts_url(get_the_author_meta('ID'))) . '">' . esc_html(get_the_author()) . '</a></span>';
                                    ?>
                                </span>
                                <?php
                                if (has_category()) :
                                    echo '<span class="cat-links">';
                                    echo '<i class="fas fa-folder"></i> ';
                                    the_category(', ');
                                    echo '</span>';
                                endif;
                                ?>
                            </div>
                        </header>
                        
                        <?php if (has_post_thumbnail()) : ?>
                            <div class="post-thumbnail">
                                <?php the_post_thumbnail('large'); ?>
                            </div>
                        <?php endif; ?>
                        
                        <div class="entry-content">
                            <?php
                            the_content();
                            
                            wp_link_pages(array(
                                'before' => '<div class="page-links">' . esc_html__('Pages:', 'mexplay-theme'),
                                'after'  => '</div>',
                            ));
                            ?>
                        </div>
                        
                        <footer class="entry-footer">
                            <?php if (has_tag()) : ?>
                                <div class="entry-tags">
                                    <i class="fas fa-tags"></i> 
                                    <?php the_tags('', ', '); ?>
                                </div>
                            <?php endif; ?>
                            
                            <div class="post-navigation">
                                <div class="prev-post">
                                    <?php
                                    $prev_post = get_previous_post();
                                    if (!empty($prev_post)) :
                                        ?>
                                        <a href="<?php echo esc_url(get_permalink($prev_post->ID)); ?>" class="mexplay-button-outline">
                                            <i class="fas fa-chevron-left"></i> <?php esc_html_e('Previous Post', 'mexplay-theme'); ?>
                                        </a>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="next-post">
                                    <?php
                                    $next_post = get_next_post();
                                    if (!empty($next_post)) :
                                        ?>
                                        <a href="<?php echo esc_url(get_permalink($next_post->ID)); ?>" class="mexplay-button-outline">
                                            <?php esc_html_e('Next Post', 'mexplay-theme'); ?> <i class="fas fa-chevron-right"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </footer>
                    </article>
                    
                    <?php
                    // If comments are open or we have at least one comment, load up the comment template.
                    if (comments_open() || get_comments_number()) :
                        comments_template();
                    endif;
                }
                
            endwhile; // End of the loop.
            ?>
            
        </div>
    </main>
</div>

<?php
get_footer();