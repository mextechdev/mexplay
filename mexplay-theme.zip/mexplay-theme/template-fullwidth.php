<?php
/**
 * Template Name: Full Width Template
 *
 * @package MexPlay_Theme
 */

get_header();

while (have_posts()) :
    the_post();
    
    if (mexplay_theme_is_restricted() && !mexplay_theme_user_has_subscription()) {
        // Show restricted content message
        echo '<div class="mexplay-container">';
        mexplay_theme_restricted_content_message();
        echo '</div>';
    } else {
        ?>
        <div id="primary" class="content-area">
            <main id="main" class="site-main">
                <?php
                /* Get the content without wrapper */
                the_content();
                
                // If comments are open or we have at least one comment, load up the comment template.
                if (comments_open() || get_comments_number()) :
                    echo '<div class="mexplay-container">';
                    comments_template();
                    echo '</div>';
                endif;
                ?>
            </main>
        </div>
        <?php
    }
    
endwhile;

get_footer();