<?php
/**
 * The template for displaying the footer
 *
 * @package MexPlay_Theme
 */

?>
    </div><!-- #content -->
</div><!-- #page -->

<?php
// Only display footer if it's not a plugin page
if (!function_exists('mexplay_theme_is_plugin_page') || !mexplay_theme_is_plugin_page()) :
    ?>
    <div class="mexplay-mini-footer">
        <div class="mexplay-container">
            <div class="mexplay-mini-footer-content">
                <div class="mexplay-copyright">
                    &copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. <?php esc_html_e('All rights reserved.', 'mexplay-theme'); ?>
                </div>
                <?php
                if (function_exists('mexplay_theme_login_logout_link')) :
                    ?>
                    <div class="mexplay-footer-links">
                        <?php
                        if (is_user_logged_in()) :
                            if (function_exists('mexplay_theme_get_subscription_url')) :
                                ?>
                                <a href="<?php echo esc_url(mexplay_theme_get_subscription_url()); ?>">
                                    <i class="fas fa-star"></i> <?php esc_html_e('Subscription', 'mexplay-theme'); ?>
                                </a>
                                <?php
                            endif;
                            
                            if (function_exists('mexplay_theme_get_dashboard_url')) :
                                ?>
                                <a href="<?php echo esc_url(mexplay_theme_get_dashboard_url()); ?>">
                                    <i class="fas fa-tachometer-alt"></i> <?php esc_html_e('Dashboard', 'mexplay-theme'); ?>
                                </a>
                                <?php
                            endif;
                        else :
                            ?>
                            <a href="<?php echo esc_url(site_url('/mexplay-login/')); ?>">
                                <i class="fas fa-sign-in-alt"></i> <?php esc_html_e('Login', 'mexplay-theme'); ?>
                            </a>
                            <?php
                        endif;
                        ?>
                    </div>
                    <?php
                endif;
                ?>
            </div>
        </div>
    </div>
    <?php
endif;

wp_footer();
?>

</body>
</html>