<?php
/**
 * The main template file
 *
 * @package MexPlay_Theme
 */

get_header();
?>

<div id="primary" class="content-area">
    <main id="main" class="site-main">
        <div class="mexplay-container">
            
            <?php
            if (have_posts()) :
                
                // Start the Loop.
                while (have_posts()) :
                    the_post();
                    
                    if (mexplay_theme_is_restricted() && !mexplay_theme_user_has_subscription()) {
                        // Show restricted content message
                        mexplay_theme_restricted_content_message();
                    } else {
                        // Display the post content.
                        ?>
                        <article id="post-<?php the_ID(); ?>" <?php post_class('mexplay-card'); ?>>
                            <header class="entry-header">
                                <?php
                                if (is_singular()) :
                                    the_title('<h1 class="entry-title mexplay-card-title">', '</h1>');
                                else :
                                    the_title('<h2 class="entry-title mexplay-card-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h2>');
                                endif;
                                
                                if ('post' === get_post_type()) :
                                    ?>
                                    <div class="entry-meta">
                                        <span class="posted-on">
                                            <?php
                                            echo '<i class="far fa-calendar-alt"></i> ';
                                            echo '<time class="entry-date published" datetime="' . esc_attr(get_the_date('c')) . '">' . esc_html(get_the_date()) . '</time>';
                                            ?>
                                        </span>
                                        <span class="byline">
                                            <?php
                                            echo '<i class="far fa-user"></i> ';
                                            echo '<span class="author vcard"><a href="' . esc_url(get_author_posts_url(get_the_author_meta('ID'))) . '">' . esc_html(get_the_author()) . '</a></span>';
                                            ?>
                                        </span>
                                    </div>
                                <?php endif; ?>
                            </header>
                            
                            <div class="entry-content">
                                <?php
                                if (is_singular()) :
                                    the_content();
                                else :
                                    the_excerpt();
                                    echo '<a href="' . esc_url(get_permalink()) . '" class="mexplay-button">' . esc_html__('Read More', 'mexplay-theme') . '</a>';
                                endif;
                                ?>
                            </div>
                            
                            <?php if (is_singular() && 'post' === get_post_type()) : ?>
                                <footer class="entry-footer">
                                    <div class="entry-categories">
                                        <i class="fas fa-folder"></i> 
                                        <?php the_category(', '); ?>
                                    </div>
                                    
                                    <?php if (has_tag()) : ?>
                                        <div class="entry-tags">
                                            <i class="fas fa-tags"></i> 
                                            <?php the_tags('', ', '); ?>
                                        </div>
                                    <?php endif; ?>
                                </footer>
                            <?php endif; ?>
                        </article>
                        <?php
                    }
                    
                endwhile;
                
                // Previous/next page navigation.
                the_posts_pagination(array(
                    'prev_text' => '<i class="fas fa-chevron-left"></i> ' . esc_html__('Previous', 'mexplay-theme'),
                    'next_text' => esc_html__('Next', 'mexplay-theme') . ' <i class="fas fa-chevron-right"></i>',
                ));
                
            else :
                
                // If no content, include the "No posts found" template.
                ?>
                <div class="mexplay-card">
                    <header class="entry-header">
                        <h1 class="entry-title mexplay-card-title"><?php esc_html_e('Nothing Found', 'mexplay-theme'); ?></h1>
                    </header>
                    
                    <div class="entry-content">
                        <?php
                        if (is_search()) :
                            ?>
                            <p><?php esc_html_e('Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'mexplay-theme'); ?></p>
                            <?php
                            get_search_form();
                        else :
                            ?>
                            <p><?php esc_html_e('It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'mexplay-theme'); ?></p>
                            <?php
                            get_search_form();
                        endif;
                        ?>
                    </div>
                </div>
                <?php
                
            endif;
            ?>
            
        </div>
    </main>
</div>

<?php
get_footer();