<?php
/**
 * The template for displaying all pages
 *
 * @package MexPlay_Theme
 */

get_header();
?>

<div id="primary" class="content-area">
    <main id="main" class="site-main">
        <div class="mexplay-container">
            
            <?php
            while (have_posts()) :
                the_post();
                
                if (mexplay_theme_is_restricted() && !mexplay_theme_user_has_subscription()) {
                    // Show restricted content message
                    mexplay_theme_restricted_content_message();
                } else {
                    ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class('mexplay-card'); ?>>
                        <?php if (!get_post_meta(get_the_ID(), '_wp_page_template', true) == 'template-fullwidth.php') : ?>
                            <header class="entry-header">
                                <?php the_title('<h1 class="entry-title mexplay-card-title">', '</h1>'); ?>
                            </header>
                        <?php endif; ?>
                        
                        <div class="entry-content">
                            <?php
                            the_content();
                            
                            wp_link_pages(array(
                                'before' => '<div class="page-links">' . esc_html__('Pages:', 'mexplay-theme'),
                                'after'  => '</div>',
                            ));
                            ?>
                        </div>
                    </article>
                    
                    <?php
                    // If comments are open or we have at least one comment, load up the comment template.
                    if (comments_open() || get_comments_number()) :
                        comments_template();
                    endif;
                }
                
            endwhile; // End of the loop.
            ?>
            
        </div>
    </main>
</div>

<?php
get_footer();