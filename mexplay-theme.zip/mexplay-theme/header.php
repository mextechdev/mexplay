<?php
/**
 * The header for our theme
 *
 * @package MexPlay_Theme
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">
    <div id="content" class="site-content">
        <?php
        // If not a plugin page, show a minimal header
        if (!function_exists('mexplay_theme_is_plugin_page') || !mexplay_theme_is_plugin_page()) :
            ?>
            <div class="mexplay-mini-header">
                <div class="mexplay-container">
                    <div class="mexplay-mini-header-content">
                        <?php
                        // Get the custom logo
                        $custom_logo_id = get_theme_mod('custom_logo');
                        $logo = wp_get_attachment_image_src($custom_logo_id, 'full');
                        
                        if ($logo) :
                            ?>
                            <div class="mexplay-logo">
                                <a href="<?php echo esc_url(home_url('/')); ?>" rel="home">
                                    <img src="<?php echo esc_url($logo[0]); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>">
                                </a>
                            </div>
                            <?php
                        else :
                            ?>
                            <div class="mexplay-site-title">
                                <a href="<?php echo esc_url(home_url('/')); ?>" rel="home">
                                    <?php bloginfo('name'); ?>
                                </a>
                            </div>
                            <?php
                        endif;
                        
                        // Show login/logout link
                        if (function_exists('mexplay_theme_login_logout_link')) :
                            ?>
                            <div class="mexplay-account-links">
                                <?php 
                                if (is_user_logged_in() && function_exists('mexplay_theme_get_dashboard_url')) {
                                    echo '<a href="' . esc_url(mexplay_theme_get_dashboard_url()) . '" class="mexplay-dashboard-link">';
                                    echo '<i class="fas fa-tachometer-alt"></i> ';
                                    echo esc_html__('Dashboard', 'mexplay-theme');
                                    echo '</a>';
                                }
                                
                                mexplay_theme_login_logout_link(
                                    '<i class="fas fa-sign-in-alt"></i> ' . esc_html__('Login', 'mexplay-theme'),
                                    '<i class="fas fa-sign-out-alt"></i> ' . esc_html__('Logout', 'mexplay-theme')
                                );
                                ?>
                            </div>
                            <?php
                        endif;
                        ?>
                    </div>
                </div>
            </div>
            <?php
        endif;
        ?>