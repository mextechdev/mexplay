<?php
/**
 * Elementor Compatibility File
 *
 * @package MexPlay_Theme
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Register Elementor locations.
 *
 * @param \ElementorPro\Modules\ThemeBuilder\Classes\Locations_Manager $locations_manager Locations manager.
 */
function mexplay_theme_register_elementor_locations($locations_manager) {
    $locations_manager->register_location(
        'header',
        [
            'label' => __('Header', 'mexplay-theme'),
            'multiple' => false,
            'edit_in_content' => false,
        ]
    );
    
    $locations_manager->register_location(
        'footer',
        [
            'label' => __('Footer', 'mexplay-theme'),
            'multiple' => false,
            'edit_in_content' => false,
        ]
    );
}
add_action('elementor/theme/register_locations', 'mexplay_theme_register_elementor_locations');

/**
 * Add custom CSS to Elementor.
 */
function mexplay_theme_elementor_custom_css() {
    if (!did_action('elementor/loaded')) {
        return;
    }
    
    wp_add_inline_style('elementor-frontend', '
        .elementor-section.elementor-section-boxed > .elementor-container {
            max-width: 100% !important;
        }
        
        .elementor-widget-heading .elementor-heading-title {
            font-family: "Montserrat", sans-serif !important;
        }
        
        .elementor-widget-text-editor {
            font-family: "Poppins", sans-serif !important;
        }
        
        .elementor-widget-button .elementor-button {
            background-color: #4e8457 !important;
            border-radius: 50px !important;
            font-weight: 600 !important;
            text-transform: uppercase !important;
            letter-spacing: 1px !important;
            transition: all 0.3s ease !important;
            box-shadow: 0 0 15px rgba(78, 132, 87, 0.5) !important;
        }
        
        .elementor-widget-button .elementor-button:hover {
            background-color: #d96e28 !important;
            transform: translateY(-3px) !important;
            box-shadow: 0 0 15px rgba(217, 110, 40, 0.5), 0 10px 20px rgba(0, 0, 0, 0.3) !important;
        }
        
        .elementor-column-gap-default > .elementor-column > .elementor-element-populated {
            padding: 10px !important;
        }
        
        .elementor-screen-only {
            display: none !important;
        }
    ');
}
add_action('wp_enqueue_scripts', 'mexplay_theme_elementor_custom_css', 20);

/**
 * Add custom fonts to Elementor.
 */
function mexplay_theme_elementor_custom_fonts($fonts) {
    $fonts['Poppins'] = 'system';
    $fonts['Montserrat'] = 'system';
    
    return $fonts;
}
add_filter('elementor/fonts/additional_fonts', 'mexplay_theme_elementor_custom_fonts');

/**
 * Add custom colors to Elementor.
 */
function mexplay_theme_elementor_custom_colors($colors) {
    $additional_colors = [
        'MexPlay Primary' => '#4e8457',
        'MexPlay Accent' => '#d96e28',
        'MexPlay Background' => '#000000',
        'MexPlay Card' => '#121212',
        'MexPlay Card Dark' => '#1a1a1a',
        'MexPlay Light BG' => '#1e1e1e',
        'MexPlay Lighter BG' => '#2d2d2d',
        'MexPlay Text' => '#e0e0e0',
        'MexPlay Light Text' => '#ffffff',
        'MexPlay Muted Text' => '#9e9e9e',
        'MexPlay Border' => '#333333',
    ];
    
    foreach ($additional_colors as $name => $color) {
        $colors[] = [
            'name' => $name,
            'color' => $color,
        ];
    }
    
    return $colors;
}
add_filter('elementor/editor/localize_settings', function($settings) {
    if (isset($settings['colors'])) {
        $settings['colors'] = mexplay_theme_elementor_custom_colors($settings['colors']);
    }
    
    return $settings;
});

/**
 * Add custom styles to Elementor editor.
 */
function mexplay_theme_elementor_editor_styles() {
    if (!did_action('elementor/loaded')) {
        return;
    }
    
    wp_add_inline_style('elementor-editor', '
        .elementor-panel .elementor-panel-heading-title,
        .elementor-panel .elementor-panel-heading-sub-title {
            font-family: "Montserrat", sans-serif !important;
        }
        
        .elementor-panel .elementor-control-title,
        .elementor-panel .elementor-control-field {
            font-family: "Poppins", sans-serif !important;
        }
    ');
}
add_action('elementor/editor/after_enqueue_styles', 'mexplay_theme_elementor_editor_styles');