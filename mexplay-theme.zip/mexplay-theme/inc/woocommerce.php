<?php
/**
 * WooCommerce Compatibility File
 *
 * @package MexPlay_Theme
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * WooCommerce setup function.
 */
function mexplay_theme_woocommerce_setup() {
    // Add theme support for WooCommerce.
    add_theme_support('woocommerce');
    
    // Add theme support for WooCommerce product gallery features.
    add_theme_support('woocommerce-product-gallery-zoom');
    add_theme_support('woocommerce-product-gallery-lightbox');
    add_theme_support('woocommerce-product-gallery-slider');
}
add_action('after_setup_theme', 'mexplay_theme_woocommerce_setup');

/**
 * WooCommerce specific scripts & stylesheets.
 */
function mexplay_theme_woocommerce_scripts() {
    // Add custom WooCommerce styles.
    wp_enqueue_style('mexplay-theme-woocommerce-style', MEXPLAY_THEME_URI . 'assets/css/woocommerce.css', array(), MEXPLAY_THEME_VERSION);
    
    // Add inline WooCommerce styles.
    $woocommerce_styles = '
        .woocommerce #respond input#submit,
        .woocommerce a.button,
        .woocommerce button.button,
        .woocommerce input.button,
        .woocommerce #respond input#submit.alt,
        .woocommerce a.button.alt,
        .woocommerce button.button.alt,
        .woocommerce input.button.alt {
            background-color: #4e8457;
            color: #ffffff;
            border-radius: 50px;
            font-weight: 600;
            padding: 12px 30px;
            text-transform: uppercase;
            letter-spacing: 1px;
            box-shadow: 0 0 15px rgba(78, 132, 87, 0.5);
            transition: all 0.3s ease;
        }
        
        .woocommerce #respond input#submit:hover,
        .woocommerce a.button:hover,
        .woocommerce button.button:hover,
        .woocommerce input.button:hover,
        .woocommerce #respond input#submit.alt:hover,
        .woocommerce a.button.alt:hover,
        .woocommerce button.button.alt:hover,
        .woocommerce input.button.alt:hover {
            background-color: #d96e28;
            color: #ffffff;
            transform: translateY(-3px);
            box-shadow: 0 0 15px rgba(217, 110, 40, 0.5), 0 10px 20px rgba(0, 0, 0, 0.3);
        }
        
        .woocommerce ul.products li.product .woocommerce-loop-product__title,
        .woocommerce ul.products li.product .price,
        .woocommerce div.product p.price,
        .woocommerce div.product span.price {
            color: #e0e0e0;
        }
        
        .woocommerce div.product .woocommerce-tabs ul.tabs li {
            background-color: #1a1a1a;
            border-color: #333333;
        }
        
        .woocommerce div.product .woocommerce-tabs ul.tabs li.active {
            background-color: #000000;
            border-bottom-color: #000000;
        }
        
        .woocommerce div.product .woocommerce-tabs ul.tabs li a {
            color: #e0e0e0;
        }
        
        .woocommerce div.product .woocommerce-tabs ul.tabs li.active a {
            color: #ffffff;
        }
        
        .woocommerce div.product .woocommerce-tabs ul.tabs::before {
            border-color: #333333;
        }
        
        .woocommerce-message,
        .woocommerce-info,
        .woocommerce-error {
            background-color: #1a1a1a;
            color: #e0e0e0;
            border-top-color: #4e8457;
        }
        
        .woocommerce-message::before,
        .woocommerce-info::before {
            color: #4e8457;
        }
        
        .woocommerce-error::before {
            color: #ff5252;
        }
        
        .woocommerce-error {
            border-top-color: #ff5252;
        }
        
        .woocommerce .quantity .qty {
            background-color: #1a1a1a;
            border-color: #333333;
            color: #e0e0e0;
            padding: 10px;
        }
        
        .woocommerce form .form-row input.input-text,
        .woocommerce form .form-row textarea {
            background-color: #1a1a1a;
            border-color: #333333;
            color: #e0e0e0;
            padding: 15px;
        }
        
        .woocommerce table.shop_table {
            background-color: #1a1a1a;
            border-color: #333333;
        }
        
        .woocommerce table.shop_table td,
        .woocommerce table.shop_table th {
            border-color: #333333;
            color: #e0e0e0;
        }
        
        .woocommerce-cart table.cart img {
            width: 80px;
        }
        
        .woocommerce .woocommerce-breadcrumb {
            color: #9e9e9e;
        }
        
        .woocommerce .woocommerce-breadcrumb a {
            color: #e0e0e0;
        }
        
        .woocommerce .woocommerce-breadcrumb a:hover {
            color: #4e8457;
        }
        
        .woocommerce ul.products li.product .price {
            color: #4e8457;
            font-size: 18px;
            font-weight: 700;
        }
        
        .woocommerce span.onsale {
            background-color: #d96e28;
            padding: 10px 15px;
        }
        
        .woocommerce div.product p.price,
        .woocommerce div.product span.price {
            color: #4e8457;
            font-size: 26px;
            font-weight: 700;
        }
        
        .woocommerce div.product .product_title {
            font-family: "Montserrat", sans-serif;
            font-weight: 700;
        }
        
        .woocommerce .star-rating span::before {
            color: #d96e28;
        }
    ';
    
    wp_add_inline_style('mexplay-theme-woocommerce-style', $woocommerce_styles);
}
add_action('wp_enqueue_scripts', 'mexplay_theme_woocommerce_scripts');

/**
 * Disable the default WooCommerce CSS.
 */
add_filter('woocommerce_enqueue_styles', '__return_false');

/**
 * Add 'woocommerce-active' class to the body tag.
 */
function mexplay_theme_woocommerce_active_body_class($classes) {
    $classes[] = 'woocommerce-active';
    
    return $classes;
}
add_filter('body_class', 'mexplay_theme_woocommerce_active_body_class');

/**
 * Remove default WooCommerce wrapper.
 */
remove_action('woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action('woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);

/**
 * Add custom WooCommerce wrapper.
 */
function mexplay_theme_woocommerce_wrapper_before() {
    ?>
    <div id="primary" class="content-area">
        <main id="main" class="site-main">
            <div class="mexplay-container">
    <?php
}
add_action('woocommerce_before_main_content', 'mexplay_theme_woocommerce_wrapper_before');

/**
 * Add custom WooCommerce wrapper end.
 */
function mexplay_theme_woocommerce_wrapper_after() {
    ?>
            </div>
        </main>
    </div>
    <?php
}
add_action('woocommerce_after_main_content', 'mexplay_theme_woocommerce_wrapper_after');

/**
 * Remove WooCommerce sidebar.
 */
remove_action('woocommerce_sidebar', 'woocommerce_get_sidebar', 10);