<?php
/**
 * Custom template tags for this theme
 *
 * @package MexPlay_Theme
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Check if current page is restricted.
 *
 * @return bool True if restricted, false otherwise.
 */
function mexplay_theme_is_restricted() {
    global $post;
    
    if (!isset($post->ID)) {
        return false;
    }
    
    return get_post_meta($post->ID, '_mexplay_restricted', true) === '1';
}

/**
 * Display restriction badge on restricted content.
 */
function mexplay_theme_restriction_badge() {
    if (mexplay_theme_is_restricted()) {
        echo '<span class="mexplay-restriction-badge">' . esc_html__('Premium Content', 'mexplay-theme') . '</span>';
    }
}

/**
 * Check if we're on a MexPlay plugin page.
 *
 * @return bool True if on a MexPlay page, false otherwise.
 */
function mexplay_theme_is_plugin_page() {
    global $wp;
    $current_url = home_url($wp->request);
    
    $plugin_pages = array(
        'mexplay-login',
        'mexplay-register',
        'mexplay-dashboard',
        'mexplay-subscription',
        'mexplay-thank-you'
    );
    
    foreach ($plugin_pages as $page) {
        if (strpos($current_url, $page) !== false) {
            return true;
        }
    }
    
    return false;
}

/**
 * Get MexPlay login URL.
 *
 * @param string $redirect_to URL to redirect to after login.
 * @return string The login URL.
 */
function mexplay_theme_get_login_url($redirect_to = '') {
    $login_url = site_url('/mexplay-login/');
    
    if (!empty($redirect_to)) {
        $login_url = add_query_arg('redirect_to', urlencode($redirect_to), $login_url);
    }
    
    return $login_url;
}

/**
 * Get MexPlay logout URL.
 *
 * @param string $redirect_to URL to redirect to after logout.
 * @return string The logout URL.
 */
function mexplay_theme_get_logout_url($redirect_to = '') {
    $logout_url = wp_logout_url();
    
    if (!empty($redirect_to)) {
        $logout_url = add_query_arg('redirect_to', urlencode($redirect_to), $logout_url);
    }
    
    return $logout_url;
}

/**
 * Get MexPlay dashboard URL.
 *
 * @return string The dashboard URL.
 */
function mexplay_theme_get_dashboard_url() {
    return site_url('/mexplay-dashboard/');
}

/**
 * Get MexPlay subscription URL.
 *
 * @return string The subscription URL.
 */
function mexplay_theme_get_subscription_url() {
    return site_url('/mexplay-subscription/');
}

/**
 * Display MexPlay login/logout link.
 *
 * @param string $login_text Text to display for login link.
 * @param string $logout_text Text to display for logout link.
 * @param string $redirect_to URL to redirect to after login/logout.
 */
function mexplay_theme_login_logout_link($login_text = '', $logout_text = '', $redirect_to = '') {
    if (empty($login_text)) {
        $login_text = __('Login', 'mexplay-theme');
    }
    
    if (empty($logout_text)) {
        $logout_text = __('Logout', 'mexplay-theme');
    }
    
    if (is_user_logged_in()) {
        echo '<a href="' . esc_url(mexplay_theme_get_logout_url($redirect_to)) . '" class="mexplay-logout-link">' . esc_html($logout_text) . '</a>';
    } else {
        echo '<a href="' . esc_url(mexplay_theme_get_login_url($redirect_to)) . '" class="mexplay-login-link">' . esc_html($login_text) . '</a>';
    }
}

/**
 * Display MexPlay subscription status.
 */
function mexplay_theme_subscription_status() {
    if (!is_user_logged_in()) {
        return;
    }
    
    if (function_exists('mexplay_get_user_subscription')) {
        $subscription = mexplay_get_user_subscription();
        
        if ($subscription && isset($subscription->status) && $subscription->status === 'active') {
            // Active subscription.
            echo '<div class="mexplay-subscription-status active">';
            echo '<i class="fas fa-check-circle"></i> ';
            echo esc_html__('Active Subscription', 'mexplay-theme');
            echo '</div>';
        } else {
            // No active subscription.
            echo '<div class="mexplay-subscription-status inactive">';
            echo '<i class="fas fa-times-circle"></i> ';
            echo esc_html__('No Active Subscription', 'mexplay-theme');
            echo '</div>';
        }
    }
}

/**
 * Display MexPlay restricted content message.
 *
 * @param string $message Custom message to display.
 */
function mexplay_theme_restricted_content_message($message = '') {
    if (empty($message)) {
        $message = __('This content is only available to members with an active subscription.', 'mexplay-theme');
    }
    
    echo '<div class="mexplay-restricted-content">';
    echo '<h2><i class="fas fa-lock"></i> ' . esc_html__('Premium Content', 'mexplay-theme') . '</h2>';
    echo '<p>' . esc_html($message) . '</p>';
    echo '<a href="' . esc_url(mexplay_theme_get_subscription_url()) . '" class="mexplay-button">';
    echo esc_html__('Subscribe Now', 'mexplay-theme');
    echo '</a>';
    echo '</div>';
}

/**
 * Check if the current user has an active subscription.
 * Wrapper for the plugin function.
 *
 * @return bool True if user has an active subscription, false otherwise.
 */
function mexplay_theme_user_has_subscription() {
    if (function_exists('mexplay_is_user_subscribed')) {
        return mexplay_is_user_subscribed();
    }
    
    return false;
}