<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package MexPlay_Theme
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Add custom body classes - moved to functions.php to avoid function redeclaration.
 *
 * Note: This function has been moved to functions.php to prevent redeclaration errors.
 * @see functions.php for the implementation.
 */
// Function mexplay_theme_body_classes is now located in functions.php

/**
 * Remove unnecessary elements from the admin bar.
 */
function mexplay_theme_remove_admin_bar_nodes() {
    global $wp_admin_bar;
    
    // Only modify for non-admins.
    if (!current_user_can('administrator')) {
        $wp_admin_bar->remove_node('wp-logo');
        $wp_admin_bar->remove_node('comments');
        $wp_admin_bar->remove_node('new-content');
        $wp_admin_bar->remove_node('edit');
    }
}
add_action('admin_bar_menu', 'mexplay_theme_remove_admin_bar_nodes', 999);

/**
 * Ajax handler to keep user session alive.
 */
function mexplay_theme_keep_session_alive() {
    check_ajax_referer('mexplay-theme-nonce', 'nonce');
    
    // Just return success, the action of calling this keeps the session alive.
    wp_send_json_success();
}
add_action('wp_ajax_mexplay_theme_keep_session_alive', 'mexplay_theme_keep_session_alive');

/**
 * Redirect user after login to dashboard.
 * 
 * Note: This function has been moved to functions.php to prevent redeclaration errors.
 * @see functions.php for the implementation.
 */
// Function mexplay_theme_login_redirect is now located in functions.php

/**
 * Redirect user after logout to login page.
 */
function mexplay_theme_logout_redirect($redirect_to, $request, $user) {
    // Redirect to MexPlay login page.
    return site_url('/mexplay-login/');
}
add_filter('logout_redirect', 'mexplay_theme_logout_redirect', 10, 3);

/**
 * Remove page titles.
 */
function mexplay_theme_remove_page_titles($title) {
    if (is_page()) {
        return '';
    }
    
    return $title;
}
add_filter('the_title', 'mexplay_theme_remove_page_titles');

/**
 * Remove archive titles.
 */
function mexplay_theme_remove_archive_titles($title) {
    return '';
}
add_filter('get_the_archive_title', 'mexplay_theme_remove_archive_titles');

/**
 * Remove comments from pages and posts.
 */
function mexplay_theme_remove_comment_support() {
    // Remove comments support from posts and pages.
    remove_post_type_support('post', 'comments');
    remove_post_type_support('page', 'comments');
}
add_action('init', 'mexplay_theme_remove_comment_support', 100);

/**
 * Redirect users to the appropriate page based on login status and page.
 */
function mexplay_theme_check_access() {
    // Don't run on admin pages.
    if (is_admin()) {
        return;
    }
    
    // Check if the current page is the login or register page.
    $current_url = $_SERVER['REQUEST_URI'];
    $is_login_page = strpos($current_url, '/mexplay-login/') !== false;
    $is_register_page = strpos($current_url, '/mexplay-register/') !== false;
    $is_subscription_page = strpos($current_url, '/mexplay-subscription/') !== false;
    $is_thank_you_page = strpos($current_url, '/mexplay-thank-you/') !== false;
    
    // If user is logged in and tries to access login or register page, redirect to dashboard.
    if (is_user_logged_in() && ($is_login_page || $is_register_page)) {
        wp_redirect(site_url('/mexplay-dashboard/'));
        exit;
    }
    
    // If user is not logged in and tries to access dashboard, redirect to login.
    if (!is_user_logged_in() && strpos($current_url, '/mexplay-dashboard/') !== false) {
        wp_redirect(site_url('/mexplay-login/'));
        exit;
    }
}
add_action('template_redirect', 'mexplay_theme_check_access', 1);

/**
 * Check if current post/page is restricted and if user has access.
 */
function mexplay_theme_check_restriction() {
    // Don't run on admin pages.
    if (is_admin()) {
        return;
    }
    
    // Only check on singular posts/pages.
    if (!is_singular()) {
        return;
    }
    
    global $post;
    
    // Check if this post is restricted.
    $is_restricted = get_post_meta($post->ID, '_mexplay_restricted', true);
    
    // Allow administrators to access all content without restriction
    if (current_user_can('administrator')) {
        return;
    }
    
    if ($is_restricted && function_exists('mexplay_is_user_subscribed')) {
        if (!mexplay_is_user_subscribed()) {
            // User does not have an active subscription, redirect to subscription page.
            wp_redirect(site_url('/mexplay-subscription/'));
            exit;
        }
    }
}
add_action('template_redirect', 'mexplay_theme_check_restriction', 2);

/**
 * Add session maintenance to keep users logged in.
 */
function mexplay_theme_extend_user_session() {
    if (is_user_logged_in()) {
        // Get current session expiration.
        $expiration = time() + (30 * DAY_IN_SECONDS); // 30 days
        
        // Set session expiration.
        $_SESSION['mexplay_session_expires'] = $expiration;
        
        // Set auth cookie expiration.
        if (isset($_COOKIE[LOGGED_IN_COOKIE])) {
            setcookie(LOGGED_IN_COOKIE, $_COOKIE[LOGGED_IN_COOKIE], $expiration, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
        }
    }
}
add_action('init', 'mexplay_theme_extend_user_session');

/**
 * Add custom query vars.
 */
function mexplay_theme_query_vars($vars) {
    $vars[] = 'mexplay_action';
    $vars[] = 'mexplay_id';
    return $vars;
}
add_filter('query_vars', 'mexplay_theme_query_vars');

/**
 * Customize the login page URL to use the plugin login page, except for admin-related logins.
 */
function mexplay_theme_login_url($login_url, $redirect, $force_reauth) {
    // Preserve original login URL for admin-related logins
    if (!empty($redirect) && (strpos($redirect, '/wp-admin') !== false || strpos($redirect, '/wp-login.php') !== false)) {
        return $login_url;
    }
    
    // For all other logins, use the custom login page
    return site_url('/mexplay-login/');
}
add_filter('login_url', 'mexplay_theme_login_url', 10, 3);

/**
 * Customize the logout URL to redirect to appropriate locations.
 */
function mexplay_theme_logout_url($logout_url, $redirect) {
    // If logging out from admin, keep default behavior
    if (is_admin()) {
        return $logout_url;
    }
    
    // For front-end users, redirect to the custom login page
    return wp_nonce_url(site_url('/mexplay-login/?action=logout'), 'log-out');
}
add_filter('logout_url', 'mexplay_theme_logout_url', 10, 2);