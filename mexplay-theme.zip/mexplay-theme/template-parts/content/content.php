<?php
/**
 * Template part for displaying posts
 *
 * @package MexPlay_Theme
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class('mexplay-card'); ?>>
    <header class="entry-header">
        <?php
        if (is_singular()) :
            the_title('<h1 class="entry-title mexplay-card-title">', '</h1>');
        else :
            the_title('<h2 class="entry-title mexplay-card-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h2>');
        endif;
        
        if ('post' === get_post_type()) :
            ?>
            <div class="entry-meta">
                <span class="posted-on">
                    <?php
                    echo '<i class="far fa-calendar-alt"></i> ';
                    echo '<time class="entry-date published" datetime="' . esc_attr(get_the_date('c')) . '">' . esc_html(get_the_date()) . '</time>';
                    ?>
                </span>
                <span class="byline">
                    <?php
                    echo '<i class="far fa-user"></i> ';
                    echo '<span class="author vcard"><a href="' . esc_url(get_author_posts_url(get_the_author_meta('ID'))) . '">' . esc_html(get_the_author()) . '</a></span>';
                    ?>
                </span>
            </div>
        <?php endif; ?>
    </header>
    
    <?php if (has_post_thumbnail() && !is_singular()) : ?>
        <div class="post-thumbnail">
            <a href="<?php the_permalink(); ?>">
                <?php the_post_thumbnail('medium'); ?>
            </a>
        </div>
    <?php endif; ?>
    
    <div class="entry-content">
        <?php
        if (is_singular()) :
            the_content();
            
            wp_link_pages(array(
                'before' => '<div class="page-links">' . esc_html__('Pages:', 'mexplay-theme'),
                'after'  => '</div>',
            ));
        else :
            the_excerpt();
            echo '<a href="' . esc_url(get_permalink()) . '" class="mexplay-button">' . esc_html__('Read More', 'mexplay-theme') . '</a>';
        endif;
        ?>
    </div>
    
    <?php if (is_singular() && 'post' === get_post_type()) : ?>
        <footer class="entry-footer">
            <div class="entry-categories">
                <i class="fas fa-folder"></i> 
                <?php the_category(', '); ?>
            </div>
            
            <?php if (has_tag()) : ?>
                <div class="entry-tags">
                    <i class="fas fa-tags"></i> 
                    <?php the_tags('', ', '); ?>
                </div>
            <?php endif; ?>
        </footer>
    <?php endif; ?>
</article>