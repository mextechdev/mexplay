<?php
/**
 * Template part for displaying restricted content message
 *
 * @package MexPlay_Theme
 */

?>

<div class="mexplay-restricted-content">
    <h2><i class="fas fa-lock"></i> <?php esc_html_e('Premium Content', 'mexplay-theme'); ?></h2>
    <p><?php esc_html_e('This content is only available to members with an active subscription.', 'mexplay-theme'); ?></p>
    <?php if (function_exists('mexplay_theme_get_subscription_url')) : ?>
        <a href="<?php echo esc_url(mexplay_theme_get_subscription_url()); ?>" class="mexplay-button">
            <?php esc_html_e('Subscribe Now', 'mexplay-theme'); ?>
        </a>
    <?php else : ?>
        <a href="<?php echo esc_url(site_url('/mexplay-subscription/')); ?>" class="mexplay-button">
            <?php esc_html_e('Subscribe Now', 'mexplay-theme'); ?>
        </a>
    <?php endif; ?>
</div>