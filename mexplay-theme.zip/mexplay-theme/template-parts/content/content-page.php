<?php
/**
 * Template part for displaying page content
 *
 * @package MexPlay_Theme
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class('mexplay-card'); ?>>
    <?php if (!get_post_meta(get_the_ID(), '_wp_page_template', true) == 'template-fullwidth.php') : ?>
        <header class="entry-header">
            <?php the_title('<h1 class="entry-title mexplay-card-title">', '</h1>'); ?>
        </header>
    <?php endif; ?>
    
    <?php if (has_post_thumbnail() && !get_post_meta(get_the_ID(), '_wp_page_template', true) == 'template-fullwidth.php') : ?>
        <div class="post-thumbnail">
            <?php the_post_thumbnail('large'); ?>
        </div>
    <?php endif; ?>
    
    <div class="entry-content">
        <?php
        the_content();
        
        wp_link_pages(array(
            'before' => '<div class="page-links">' . esc_html__('Pages:', 'mexplay-theme'),
            'after'  => '</div>',
        ));
        ?>
    </div>
</article>