/**
 * MexPlay Theme Main JavaScript
 */

(function($) {
    'use strict';
    
    /**
     * Function to check if Font Awesome icons loaded properly
     * If not, it adds a class to trigger the fallback solution
     */
    function checkIconsLoaded() {
        // Always apply the fallback class first to ensure icons show
        $('body').addClass('mexplay-icon-fallback');
        
        // Create a temporary icon element
        var $testIcon = $('<i class="fas fa-user"></i>');
        $testIcon.css({
            'position': 'absolute',
            'visibility': 'hidden',
            'top': '-9999px',
            'left': '-9999px'
        });
        $('body').append($testIcon);
        
        // Set a timeout to check if the icon has been rendered properly
        setTimeout(function() {
            var fontLoaded = false;
            
            // First test: Check if the width is greater than 0 (font loaded)
            if ($testIcon.width() > 0) {
                fontLoaded = true;
            }
            
            // Second test: Check computed style
            var computedStyle = window.getComputedStyle($testIcon[0], ':before');
            if (computedStyle && computedStyle.content && 
                computedStyle.content !== 'none' && 
                computedStyle.content !== '' && 
                computedStyle.content !== '""') {
                fontLoaded = true;
            }
            
            // Third test: Test rendering an actual icon in a visible element
            var $visibleTest = $('<div><i class="fas fa-check"></i></div>');
            $visibleTest.css({
                'position': 'absolute',
                'opacity': '0.01',
                'bottom': '0',
                'left': '0'
            });
            $('body').append($visibleTest);
            
            // Check if the icon has a reasonable dimension
            var $visibleIcon = $visibleTest.find('i');
            if ($visibleIcon.length > 0 && $visibleIcon.width() > 0 && $visibleIcon.height() > 0) {
                fontLoaded = true;
            }
            
            // If font loads properly, we can remove the fallback class
            if (fontLoaded) {
                $('body').removeClass('mexplay-icon-fallback');
                console.log('Font Awesome loaded successfully');
            } else {
                console.log('Font Awesome failed to load, using fallback icons');
                
                // Add additional CSS rules for specific icons
                var additionalFallbacks = document.createElement('style');
                additionalFallbacks.type = 'text/css';
                additionalFallbacks.innerHTML = `
                    /* Double-ensure that the most critical icons have emoji fallbacks */
                    i[class*='fa-user']:before, span[class*='fa-user']:before { content: '👤' !important; }
                    i[class*='fa-lock']:before, span[class*='fa-lock']:before { content: '🔒' !important; }
                    i[class*='fa-sign-out']:before, span[class*='fa-sign-out']:before { content: '🚪' !important; }
                    i[class*='fa-dashboard']:before, span[class*='fa-dashboard']:before,
                    i[class*='fa-tachometer']:before, span[class*='fa-tachometer']:before { content: '📊' !important; }
                    i[class*='fa-credit-card']:before, span[class*='fa-credit-card']:before { content: '💳' !important; }
                    i[class*='fa-check']:before, span[class*='fa-check']:before { content: '✅' !important; }
                    i[class*='fa-times']:before, span[class*='fa-times']:before { content: '❌' !important; }
                `;
                document.head.appendChild(additionalFallbacks);
            }
            
            // Remove the test elements
            $testIcon.remove();
            $visibleTest.remove();
        }, 1000); // Check after 1000ms to give more time for fonts to load
    }
    
    // Document Ready
    $(document).ready(function() {
        // Force the body class for theme styling
        $('body').addClass('mexplay-body');
        
        // Check if Font Awesome icons loaded properly
        checkIconsLoaded();
        
        // Add inline styles to force theme override
        const styleElement = document.createElement('style');
        styleElement.type = 'text/css';
        styleElement.innerHTML = `
            body.mexplay-body {
                background-color: #000000 !important;
                color: #e0e0e0 !important;
                font-family: 'Poppins', sans-serif !important;
            }
            
            body.mexplay-body #page,
            body.mexplay-body #main,
            body.mexplay-body #content,
            body.mexplay-body .site-content,
            body.mexplay-body .content-area,
            body.mexplay-body .entry-content,
            body.mexplay-body .page {
                background-color: #000000 !important;
                color: #e0e0e0 !important;
            }
            
            .site-header,
            .site-footer,
            .ast-header-break-point,
            .site-below-footer-wrap,
            .site-primary-footer-wrap,
            #colophon,
            #masthead,
            .main-header-bar,
            .ast-main-header-bar-alignment,
            .menu-toggle,
            .main-navigation,
            .widget-area,
            .widget,
            .sidebar,
            aside {
                display: none !important;
            }
            
            .mexplay-container * {
                font-family: 'Poppins', sans-serif !important;
            }
            
            .mexplay-title, 
            .mexplay-form-header h2,
            .mexplay-subtitle,
            .mexplay-package-name,
            .mexplay-user-name {
                font-family: 'Montserrat', sans-serif !important;
            }
        `;
        document.head.appendChild(styleElement);
        
        // Home page redirect based on login status
        if (window.location.pathname === '/' || window.location.pathname === '/index.php') {
            if (mexplay_theme_vars.is_user_logged_in) {
                window.location.href = mexplay_theme_vars.dashboard_url;
            } else {
                window.location.href = mexplay_theme_vars.login_url;
            }
        }
        
        // Handle extended login session
        if (mexplay_theme_vars.is_user_logged_in) {
            // Session maintenance - ping every 10 minutes to keep session alive
            setInterval(function() {
                $.ajax({
                    url: mexplay_theme_vars.ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'mexplay_theme_keep_session_alive',
                        nonce: mexplay_theme_vars.nonce
                    }
                });
            }, 600000); // 10 minutes
        }
        
        // Handle restricted content visibility
        if ($('.mexplay-restricted-content').length) {
            $('.mexplay-restricted-content').addClass('mexplay-fade-in');
        }
        
        // Make sure theme compatibility with MexPlay plugin
        $('.mexplay-button').on('mouseenter', function() {
            $(this).css('transform', 'translateY(-3px)');
        }).on('mouseleave', function() {
            $(this).css('transform', 'translateY(0)');
        });
        
        // Handle any Elementor compatibility issues
        if (typeof elementorFrontend !== 'undefined') {
            elementorFrontend.hooks.addAction('frontend/element_ready/global', function() {
                // Force MexPlay styling to elementor elements
                $('.elementor-widget-heading .elementor-heading-title').css('font-family', "'Montserrat', sans-serif");
                $('.elementor-widget-text-editor').css('font-family', "'Poppins', sans-serif");
            });
        }
        
        // Hide page titles
        $('.entry-title, .page-title').hide();
        
        // Fix for Elementor full width sections
        $('.elementor-section-full_width').each(function() {
            $(this).css({
                'min-width': '100vw',
                'left': '50%',
                'margin-left': '-50vw',
                'width': '100vw',
                'max-width': '100vw'
            });
        });
    });
    
})(jQuery);