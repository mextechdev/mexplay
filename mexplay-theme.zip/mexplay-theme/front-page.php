<?php
/**
 * The template for displaying the front page
 *
 * @package MexPlay_Theme
 */

// Redirect based on login status
if (is_user_logged_in()) {
    // Redirect to dashboard if logged in
    wp_redirect(site_url('/mexplay-dashboard/'));
    exit;
} else {
    // Redirect to login if not logged in
    wp_redirect(site_url('/mexplay-login/'));
    exit;
}