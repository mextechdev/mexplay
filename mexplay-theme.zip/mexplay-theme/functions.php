<?php
/**
 * MexPlay Theme functions and definitions
 *
 * @package MexPlay_Theme
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Define theme constants
define('MEXPLAY_THEME_VERSION', '1.0.0');
define('MEXPLAY_THEME_DIR', get_template_directory());
define('MEXPLAY_THEME_URI', get_template_directory_uri() . '/');

/**
 * Theme setup function.
 */
function mexplay_theme_setup() {
    // Add default posts and comments RSS feed links to head.
    add_theme_support('automatic-feed-links');
    
    // Let WordPress manage the document title.
    add_theme_support('title-tag');
    
    // Enable support for Post Thumbnails on posts and pages.
    add_theme_support('post-thumbnails');
    
    // Enable support for HTML5 markup.
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    // Add support for responsive embeds.
    add_theme_support('responsive-embeds');
    
    // Add support for custom logo.
    add_theme_support('custom-logo', array(
        'height'      => 100,
        'width'       => 300,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    
    // Register navigation menus.
    register_nav_menus(array(
        'primary' => esc_html__('Primary Menu', 'mexplay-theme'),
    ));
    
    // Set up the WordPress core custom background feature.
    add_theme_support('custom-background', array(
        'default-color' => '000000',
    ));
    
    // Add support for full and wide align images.
    add_theme_support('align-wide');
    
    // Add support for editor styles.
    add_theme_support('editor-styles');
    
    // Add custom editor font sizes.
    add_theme_support('editor-font-sizes', array(
        array(
            'name'      => esc_html__('Small', 'mexplay-theme'),
            'shortName' => esc_html__('S', 'mexplay-theme'),
            'size'      => 14,
            'slug'      => 'small',
        ),
        array(
            'name'      => esc_html__('Normal', 'mexplay-theme'),
            'shortName' => esc_html__('M', 'mexplay-theme'),
            'size'      => 16,
            'slug'      => 'normal',
        ),
        array(
            'name'      => esc_html__('Large', 'mexplay-theme'),
            'shortName' => esc_html__('L', 'mexplay-theme'),
            'size'      => 20,
            'slug'      => 'large',
        ),
        array(
            'name'      => esc_html__('Huge', 'mexplay-theme'),
            'shortName' => esc_html__('XL', 'mexplay-theme'),
            'size'      => 26,
            'slug'      => 'huge',
        ),
    ));
    
    // Add support for custom color palette.
    add_theme_support('editor-color-palette', array(
        array(
            'name'  => esc_html__('Primary', 'mexplay-theme'),
            'slug'  => 'primary',
            'color' => '#4e8457',
        ),
        array(
            'name'  => esc_html__('Accent', 'mexplay-theme'),
            'slug'  => 'accent',
            'color' => '#d96e28',
        ),
        array(
            'name'  => esc_html__('Background', 'mexplay-theme'),
            'slug'  => 'background',
            'color' => '#000000',
        ),
        array(
            'name'  => esc_html__('Card', 'mexplay-theme'),
            'slug'  => 'card',
            'color' => '#121212',
        ),
        array(
            'name'  => esc_html__('Light Background', 'mexplay-theme'),
            'slug'  => 'light-background',
            'color' => '#1e1e1e',
        ),
        array(
            'name'  => esc_html__('Text', 'mexplay-theme'),
            'slug'  => 'text',
            'color' => '#e0e0e0',
        ),
        array(
            'name'  => esc_html__('Light Text', 'mexplay-theme'),
            'slug'  => 'light-text',
            'color' => '#ffffff',
        ),
        array(
            'name'  => esc_html__('Muted Text', 'mexplay-theme'),
            'slug'  => 'muted-text',
            'color' => '#9e9e9e',
        ),
    ));
}
add_action('after_setup_theme', 'mexplay_theme_setup');

/**
 * Register widget area.
 */
require get_template_directory() . '/inc/widgets.php';

/**
 * Enqueue scripts and styles.
 */
function mexplay_theme_scripts() {
    // Google Fonts
    wp_enqueue_style('mexplay-theme-fonts', 'https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&family=Poppins:wght@300;400;500;600;700&display=swap', array(), null);
    
    // NOTE: We're commenting out Font Awesome loading from the theme
    // to prevent conflicts with the plugin's Font Awesome implementation
    // The plugin will handle all icon loading
    
    // // Font Awesome 6 (with fallback)
    // wp_enqueue_style('font-awesome-6', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), '6.4.0');
    // wp_enqueue_style('font-awesome-5-fallback', 'https://use.fontawesome.com/releases/v5.15.4/css/all.css', array('font-awesome-6'), '5.15.4');
    
    // // Also load Material Icons for additional icon support
    // wp_enqueue_style('material-icons', 'https://fonts.googleapis.com/icon?family=Material+Icons', array(), null);
    
    // // Local fallback for icons in case CDN fails
    // wp_enqueue_style('mexplay-icon-fallback', get_template_directory_uri() . '/assets/css/icon-fallback.css', array('font-awesome-6', 'font-awesome-5-fallback'), MEXPLAY_THEME_VERSION);
    
    // Theme Style
    wp_enqueue_style('mexplay-theme-style', get_stylesheet_uri(), array(), MEXPLAY_THEME_VERSION);
    
    // Theme custom JS
    wp_enqueue_script('mexplay-theme-js', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), MEXPLAY_THEME_VERSION, true);
    
    // Localize script
    wp_localize_script('mexplay-theme-js', 'mexplay_theme_vars', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('mexplay-theme-nonce'),
        'is_user_logged_in' => is_user_logged_in(),
        'dashboard_url' => site_url('/mexplay-dashboard/'),
        'login_url' => site_url('/mexplay-login/'),
    ));
    
    // Add comment reply script
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'mexplay_theme_scripts');

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * WooCommerce compatibility.
 */
if (class_exists('WooCommerce')) {
    require get_template_directory() . '/inc/woocommerce.php';
}

/**
 * Elementor compatibility.
 */
if (did_action('elementor/loaded')) {
    require get_template_directory() . '/inc/elementor.php';
}

/**
 * Add meta box for page restriction.
 */
function mexplay_theme_add_meta_boxes() {
    add_meta_box(
        'mexplay_theme_meta_box',
        __('MexPlay Restriction Settings', 'mexplay-theme'),
        'mexplay_theme_meta_box_callback',
        'page',
        'side',
        'high'
    );
}
add_action('add_meta_boxes', 'mexplay_theme_add_meta_boxes');

/**
 * Meta box callback.
 */
function mexplay_theme_meta_box_callback($post) {
    // Add a nonce field
    wp_nonce_field('mexplay_theme_save_meta_box', 'mexplay_theme_meta_box_nonce');
    
    // Get the current value
    $is_restricted = get_post_meta($post->ID, '_mexplay_restricted', true);
    
    // Output the field
    ?>
    <p>
        <input type="checkbox" id="mexplay_restricted" name="mexplay_restricted" value="1" <?php checked($is_restricted, '1'); ?> />
        <label for="mexplay_restricted"><?php esc_html_e('Restrict to subscribers only', 'mexplay-theme'); ?></label>
    </p>
    <p class="description">
        <?php esc_html_e('Check this box to make this page only accessible to users with an active MexPlay subscription.', 'mexplay-theme'); ?>
    </p>
    <?php
}

/**
 * Save meta box data.
 */
function mexplay_theme_save_meta_box($post_id) {
    // Check if nonce is set
    if (!isset($_POST['mexplay_theme_meta_box_nonce'])) {
        return;
    }
    
    // Verify the nonce
    if (!wp_verify_nonce($_POST['mexplay_theme_meta_box_nonce'], 'mexplay_theme_save_meta_box')) {
        return;
    }
    
    // If auto-saving, do nothing
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    // Check permissions
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    // Save the data
    if (isset($_POST['mexplay_restricted'])) {
        update_post_meta($post_id, '_mexplay_restricted', '1');
    } else {
        delete_post_meta($post_id, '_mexplay_restricted');
    }
}
add_action('save_post', 'mexplay_theme_save_meta_box');

/**
 * Customize login page for front-end only
 */
function mexplay_theme_login_page_customization() {
    // Check if it's the login page
    if (!isset($GLOBALS['pagenow']) || $GLOBALS['pagenow'] !== 'wp-login.php') {
        return;
    }
    
    // Check if the login page is being accessed for admin purposes
    // Skip customization for admin login or password reset
    if (
        (isset($_GET['redirect_to']) && strpos($_GET['redirect_to'], '/wp-admin') !== false) ||
        (isset($_GET['action']) && $_GET['action'] == 'lostpassword') ||
        (isset($_REQUEST['interim-login'])) ||
        (isset($_GET['action']) && $_GET['action'] == 'resetpass')
    ) {
        return;
    }
    
    // Customize the login page for front-end users only
    ?>
    <style type="text/css">
        body.login {
            background-color: #000000;
        }
        
        .login h1 a {
            background-image: url('<?php echo esc_url(get_theme_mod('custom_logo')); ?>');
            background-size: contain;
            width: 320px;
            height: 80px;
            margin-bottom: 20px;
        }
        
        .login form {
            background-color: #121212;
            border: 1px solid rgba(255, 255, 255, 0.05);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            border-radius: 12px;
        }
        
        .login label {
            color: #e0e0e0;
        }
        
        .login input[type="text"],
        .login input[type="password"] {
            background-color: #1e1e1e;
            border: 1px solid #333333;
            border-radius: 8px;
            color: #e0e0e0;
            padding: 15px;
        }
        
        .login input[type="text"]:focus,
        .login input[type="password"]:focus {
            border-color: #4e8457;
            box-shadow: 0 0 0 2px rgba(78, 132, 87, 0.3);
        }
        
        .login .button.button-primary {
            background-color: #4e8457;
            border: none;
            border-radius: 50px;
            box-shadow: 0 0 15px rgba(78, 132, 87, 0.5);
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.3s ease;
            width: 100%;
            padding: 8px;
            height: auto;
            font-weight: 600;
        }
        
        .login .button.button-primary:hover {
            background-color: #d96e28;
            box-shadow: 0 0 15px rgba(217, 110, 40, 0.5), 0 10px 20px rgba(0, 0, 0, 0.3);
            transform: translateY(-3px);
        }
        
        .login #nav a,
        .login #backtoblog a {
            color: #9e9e9e;
        }
        
        .login #nav a:hover,
        .login #backtoblog a:hover {
            color: #4e8457;
        }
        
        .login .message,
        .login .success {
            background-color: #1a1a1a;
            border-left: 4px solid #4e8457;
            color: #e0e0e0;
        }
        
        .login .success {
            border-left-color: #4e8457;
        }
        
        .login #login_error {
            background-color: #1a1a1a;
            border-left: 4px solid #ff5252;
            color: #e0e0e0;
        }
        
        .login #login {
            width: 400px;
            padding: 8% 0 0;
        }
        
        @media screen and (max-width: 768px) {
            .login #login {
                width: 85%;
            }
        }
    </style>
    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelector('.login h1 a').setAttribute('href', '<?php echo esc_url(home_url('/')); ?>');
            document.querySelector('.login h1 a').setAttribute('title', '<?php echo esc_attr(get_bloginfo('name')); ?>');
        });
    </script>
    <?php
}
add_action('login_enqueue_scripts', 'mexplay_theme_login_page_customization');

/**
 * Add preconnect for Google Fonts.
 */
function mexplay_theme_resource_hints($urls, $relation_type) {
    if ('preconnect' === $relation_type) {
        $urls[] = array(
            'href' => 'https://fonts.gstatic.com',
            'crossorigin',
        );
    }
    
    return $urls;
}
add_filter('wp_resource_hints', 'mexplay_theme_resource_hints', 10, 2);

/**
 * Filter the excerpt length.
 */
function mexplay_theme_excerpt_length($length) {
    return 25;
}
add_filter('excerpt_length', 'mexplay_theme_excerpt_length');

/**
 * Filter the excerpt "read more" string.
 */
function mexplay_theme_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'mexplay_theme_excerpt_more');

/**
 * Add classes to body.
 */
function mexplay_theme_body_classes($classes) {
    // Add a class for the dark theme
    $classes[] = 'mexplay-theme';
    $classes[] = 'mexplay-body';
    
    // If using full width template
    if (is_page_template('template-fullwidth.php')) {
        $classes[] = 'mexplay-fullwidth';
    }
    
    // Add a class if user is subscribed
    if (function_exists('mexplay_is_user_subscribed') && mexplay_is_user_subscribed()) {
        $classes[] = 'mexplay-subscribed';
    }
    
    return $classes;
}
add_filter('body_class', 'mexplay_theme_body_classes');

/**
 * Handle login redirects appropriately
 * Ensure that admin logins go to admin dashboard and user logins go to frontend dashboard
 */
function mexplay_theme_login_redirect($redirect_to, $request, $user) {
    // If the user is an admin or trying to access wp-admin, use default behavior
    if (isset($user->roles) && is_array($user->roles)) {
        if (in_array('administrator', $user->roles) || strpos($redirect_to, 'wp-admin') !== false) {
            return $redirect_to; // Go wherever WordPress wants to send them
        } else {
            // Regular users always go to the MexPlay dashboard
            return site_url('/mexplay-dashboard/');
        }
    }
    
    // Default return if something goes wrong
    return $redirect_to;
}
add_filter('login_redirect', 'mexplay_theme_login_redirect', 10, 3);