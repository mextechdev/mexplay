<?php
/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://mextvmedia.com.ng
 * @since      1.0.0
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two hooks for
 * enqueuing the public-facing stylesheet and JavaScript.
 *
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/public
 */
class Mexplay_OTT_Premium_Public {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param    string    $plugin_name       The name of the plugin.
     * @param    string    $version           The version of this plugin.
     */
    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    /**
     * Register the stylesheets for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_styles() {
        // Enqueue Google Fonts first
        wp_enqueue_style('mexplay-google-fonts-poppins', 'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap', array(), null);
        wp_enqueue_style('mexplay-google-fonts-montserrat', 'https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800&display=swap', array(), null);
        
        // Add Font Awesome from multiple CDNs for better reliability
        wp_enqueue_style('fontawesome-6-cdnjs', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), '6.4.0', 'all');
        wp_enqueue_style('fontawesome-6-use', 'https://use.fontawesome.com/releases/v6.4.0/css/all.css', array(), '6.4.0', 'all');
        wp_enqueue_style('fontawesome-6-kit', 'https://kit.fontawesome.com/a076d05399.js', array(), '6.4.0', 'all');
        wp_enqueue_style('fontawesome-5-cdnjs', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css', array(), '5.15.4', 'all');
        wp_enqueue_style('fontawesome-5-use', 'https://use.fontawesome.com/releases/v5.15.4/css/all.css', array(), '5.15.4', 'all');
        
        // Direct inclusion of Font Awesome stylesheet in head
        add_action('wp_head', function() {
            echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />';
            echo '<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>';
        }, 5);
        
        // Add our plugin CSS with high priority (100)
        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/mexplay-ott-premium-public.css', array(), $this->version, 'all');
        
        // Add icon fallback CSS (now contains embedded font data)
        wp_enqueue_style($this->plugin_name . '-icon-fallback', plugin_dir_url(__FILE__) . 'css/icon-fallback.css', array($this->plugin_name), $this->version, 'all');
        
        // Add SVG icon fallback (direct SVG approach, most reliable)
        wp_enqueue_style($this->plugin_name . '-svg-icons', plugin_dir_url(__FILE__) . 'css/mexplay-icons.css', array($this->plugin_name), $this->version, 'all');
        
        // Add inline CSS to ensure our styles have higher specificity
        $custom_css = "
            body.mexplay-body .site-content,
            body.mexplay-body #page,
            body.mexplay-body #content {
                background-color: var(--mexplay-bg-color) !important;
                color: var(--mexplay-text-color) !important;
            }
            
            body.mexplay-body .mexplay-container * {
                font-family: 'Poppins', sans-serif !important;
            }
            
            body.mexplay-body .mexplay-title, 
            body.mexplay-body h1, 
            body.mexplay-body h2, 
            body.mexplay-body h3, 
            body.mexplay-body h4, 
            body.mexplay-body h5, 
            body.mexplay-body h6 {
                font-family: 'Montserrat', sans-serif !important;
            }
        ";
        wp_add_inline_style($this->plugin_name, $custom_css);
    }

    /**
     * Register the JavaScript for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts() {
        wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/mexplay-ott-premium-public.js', array('jquery'), $this->version, false);
        
        // Get Paystack public key
        $test_mode = get_option('mexplay_paystack_test_mode', 'yes');
        $paystack_public_key = '';
        
        if ($test_mode === 'yes') {
            $paystack_public_key = get_option('mexplay_paystack_test_public_key', '');
        } else {
            $paystack_public_key = get_option('mexplay_paystack_live_public_key', '');
        }
        
        // Localize script
        wp_localize_script($this->plugin_name, 'mexplay_vars', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('mexplay-public-nonce'),
            'paystack_public_key' => $paystack_public_key,
            'thank_you_url' => site_url('/mexplay-thank-you/'),
            'login_url' => site_url('/mexplay-login/'),
            'dashboard_url' => site_url('/mexplay-dashboard/'),
            'is_user_logged_in' => is_user_logged_in()
        ));
        
        // Only load Paystack JS on subscription page
        if (is_page('mexplay-subscription')) {
            wp_enqueue_script('paystack', 'https://js.paystack.co/v1/inline.js', array(), null, true);
        }
    }

    /**
     * Start custom session management.
     *
     * @since    1.0.0
     */
    public function start_session() {
        if (!session_id()) {
            session_start();
        }
    }

    /**
     * End session on user logout.
     *
     * @since    1.0.0
     */
    public function end_session() {
        if (session_id()) {
            session_destroy();
        }
        
        // Redirect to login page after logout
        wp_redirect(site_url('/mexplay-login/'));
        exit;
    }

    /**
     * Handle user registration form submission.
     *
     * @since    1.0.0
     */
    public function register_user_handler() {
        if (isset($_POST['mexplay_register_nonce']) && wp_verify_nonce($_POST['mexplay_register_nonce'], 'mexplay_register_action')) {
            
            // Get and sanitize form data
            $full_name = sanitize_text_field($_POST['full_name']);
            $username = sanitize_user($_POST['username']);
            $phone = sanitize_text_field($_POST['phone']);
            $email = sanitize_email($_POST['email']);
            $password = $_POST['password'];
            
            // Basic validation
            $errors = array();
            
            if (empty($full_name)) {
                $errors[] = 'Full name is required.';
            }
            
            if (empty($username)) {
                $errors[] = 'Username is required.';
            } elseif (username_exists($username)) {
                $errors[] = 'Username already exists.';
            }
            
            if (empty($phone)) {
                $errors[] = 'Phone number is required.';
            }
            
            if (empty($email)) {
                $errors[] = 'Email address is required.';
            } elseif (!is_email($email)) {
                $errors[] = 'Invalid email address.';
            } elseif (email_exists($email)) {
                $errors[] = 'Email address already registered.';
            }
            
            if (empty($password)) {
                $errors[] = 'Password is required.';
            } elseif (strlen($password) < 6) {
                $errors[] = 'Password must be at least 6 characters.';
            }
            
            // If there are errors, store them in session and redirect back to registration page
            if (!empty($errors)) {
                $_SESSION['mexplay_registration_errors'] = $errors;
                $_SESSION['mexplay_registration_data'] = array(
                    'full_name' => $full_name,
                    'username' => $username,
                    'phone' => $phone,
                    'email' => $email
                );
                
                wp_redirect(site_url('/mexplay-register/'));
                exit;
            }
            
            // Extract first and last name from full name
            $name_parts = explode(' ', $full_name, 2);
            $first_name = $name_parts[0];
            $last_name = isset($name_parts[1]) ? $name_parts[1] : '';
            
            // Create the user
            $user_id = wp_create_user($username, $password, $email);
            
            if (is_wp_error($user_id)) {
                $_SESSION['mexplay_registration_errors'] = array($user_id->get_error_message());
                $_SESSION['mexplay_registration_data'] = array(
                    'full_name' => $full_name,
                    'username' => $username,
                    'phone' => $phone,
                    'email' => $email
                );
                
                wp_redirect(site_url('/mexplay-register/'));
                exit;
            }
            
            // Update user meta
            update_user_meta($user_id, 'first_name', $first_name);
            update_user_meta($user_id, 'last_name', $last_name);
            update_user_meta($user_id, 'mexplay_user_phone', $phone);
            
            // Log activity
            $user_manager = new Mexplay_OTT_Premium_User();
            $user_manager->log_activity($user_id, 'user_registered', 'User registered successfully.');
            
            // Log the user in
            wp_set_current_user($user_id);
            wp_set_auth_cookie($user_id, true);
            
            // Redirect to subscription page
            wp_redirect(site_url('/mexplay-subscription/'));
            exit;
        }
    }

    /**
     * Handle user login form submission.
     *
     * @since    1.0.0
     */
    public function login_user_handler() {
        // Skip this handler for WordPress admin login requests
        if (
            (isset($_GET['redirect_to']) && strpos($_GET['redirect_to'], '/wp-admin') !== false) ||
            (isset($_REQUEST['interim-login'])) ||
            (isset($_GET['action']) && in_array($_GET['action'], array('lostpassword', 'resetpass')))
        ) {
            return;
        }
        
        // Only process our custom login form submissions
        if (isset($_POST['mexplay_login_nonce']) && wp_verify_nonce($_POST['mexplay_login_nonce'], 'mexplay_login_action')) {
            
            // Get and sanitize form data
            $username = sanitize_user($_POST['username']);
            $password = $_POST['password'];
            $voucher_code = sanitize_text_field($_POST['voucher_code']);
            
            // Basic validation
            $errors = array();
            
            if (empty($username)) {
                $errors[] = 'Username or email is required.';
            }
            
            if (empty($password)) {
                $errors[] = 'Password is required.';
            }
            
            if (empty($voucher_code)) {
                $errors[] = 'Voucher code is required.';
            }
            
            // If there are errors, store them in session and redirect back to login page
            if (!empty($errors)) {
                $_SESSION['mexplay_login_errors'] = $errors;
                $_SESSION['mexplay_login_username'] = $username;
                
                wp_redirect(site_url('/mexplay-login/'));
                exit;
            }
            
            // Check if username is email
            if (is_email($username)) {
                $user = get_user_by('email', $username);
                if ($user) {
                    $username = $user->user_login;
                }
            }
            
            // Authenticate user
            $user = wp_authenticate($username, $password);
            
            if (is_wp_error($user)) {
                $_SESSION['mexplay_login_errors'] = array('Invalid username or password.');
                $_SESSION['mexplay_login_username'] = $username;
                
                wp_redirect(site_url('/mexplay-login/'));
                exit;
            }
            
            // Check if user is suspended
            $is_suspended = get_user_meta($user->ID, 'mexplay_suspended', true);
            if ($is_suspended) {
                $_SESSION['mexplay_login_errors'] = array('Your account is suspended. Please contact the administrator.');
                $_SESSION['mexplay_login_username'] = $username;
                
                wp_redirect(site_url('/mexplay-login/'));
                exit;
            }
            
            // Check if the user is an administrator (allow admins to bypass voucher requirement)
            $is_admin = in_array('administrator', $user->roles);
            
            // Validate voucher (unless user is an admin)
            if (!$is_admin) {
                $voucher_manager = new Mexplay_OTT_Premium_Voucher();
                $voucher_validation = $voucher_manager->validate_voucher($voucher_code, $user->ID);
                
                if (!$voucher_validation['valid']) {
                    $_SESSION['mexplay_login_errors'] = array($voucher_validation['message']);
                    $_SESSION['mexplay_login_username'] = $username;
                    
                    wp_redirect(site_url('/mexplay-login/'));
                    exit;
                }
                
                // Set current user voucher for session
                $_SESSION['mexplay_current_voucher'] = $voucher_code;
            }
            
            // Log activity
            $user_manager = new Mexplay_OTT_Premium_User();
            $user_manager->log_activity($user->ID, 'user_login', 'User logged in successfully.');
            
            // Log the user in
            wp_set_current_user($user->ID);
            wp_set_auth_cookie($user->ID, true);
            
            // Redirect admins to admin dashboard, regular users to front-end dashboard
            if ($is_admin) {
                wp_redirect(admin_url());
            } else {
                wp_redirect(site_url('/mexplay-dashboard/'));
            }
            exit;
        }
    }

    /**
     * Handle subscription package selection.
     *
     * @since    1.0.0
     */
    public function handle_subscription_selection() {
        if (isset($_POST['mexplay_subscription_nonce']) && wp_verify_nonce($_POST['mexplay_subscription_nonce'], 'mexplay_subscription_action')) {
            
            if (!is_user_logged_in()) {
                wp_redirect(site_url('/mexplay-login/'));
                exit;
            }
            
            $package_id = intval($_POST['package_id']);
            
            if (empty($package_id)) {
                $_SESSION['mexplay_subscription_error'] = 'Please select a subscription package.';
                wp_redirect(site_url('/mexplay-subscription/'));
                exit;
            }
            
            global $wpdb;
            $table_name = $wpdb->prefix . 'mexplay_subscription_packages';
            $package = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $package_id));
            
            if (!$package) {
                $_SESSION['mexplay_subscription_error'] = 'Invalid subscription package.';
                wp_redirect(site_url('/mexplay-subscription/'));
                exit;
            }
            
            // Check if this is a free trial package
            if ($package->is_trial) {
                // Check if user has already used a free trial
                $user_id = get_current_user_id();
                $voucher_manager = new Mexplay_OTT_Premium_Voucher();
                $has_used_trial = $voucher_manager->has_used_free_trial($user_id);
                
                if ($has_used_trial && !current_user_can('manage_options')) {
                    $_SESSION['mexplay_subscription_error'] = 'You have already used your free trial. Please select a paid package.';
                    wp_redirect(site_url('/mexplay-subscription/'));
                    exit;
                }
                
                // Generate voucher for free trial
                $subscription_manager = new Mexplay_OTT_Premium_Subscription();
                $result = $subscription_manager->create_free_trial_subscription($user_id, $package_id);
                
                if ($result['success']) {
                    // Set current voucher for session
                    $_SESSION['mexplay_current_voucher'] = $result['voucher_code'];
                    
                    // Send welcome email
                    $email_manager = new Mexplay_OTT_Premium_Email();
                    $user_data = get_userdata($user_id);
                    $email_manager->send_welcome_email($user_data->user_email, $user_data->display_name, $result['voucher_code'], $result['expiry_date'], $package->name);
                    
                    // Redirect to dashboard
                    wp_redirect(site_url('/mexplay-dashboard/'));
                    exit;
                } else {
                    $_SESSION['mexplay_subscription_error'] = $result['message'];
                    wp_redirect(site_url('/mexplay-subscription/'));
                    exit;
                }
            } else {
                // Store package details in session for Paystack payment
                $_SESSION['mexplay_pending_package'] = array(
                    'id' => $package->id,
                    'name' => $package->name,
                    'price' => $package->price,
                    'duration' => $package->duration,
                    'duration_unit' => $package->duration_unit
                );
                
                // Redirect back to subscription page - payment will be handled by JavaScript
                wp_redirect(site_url('/mexplay-subscription/?initiate_payment=1'));
                exit;
            }
        }
    }

    /**
     * Process Paystack payment callback.
     *
     * @since    1.0.0
     */
    public function process_paystack_callback() {
        if (isset($_GET['paystack-reference']) && isset($_GET['trxref'])) {
            $reference = sanitize_text_field($_GET['paystack-reference']);
            
            if (!is_user_logged_in()) {
                wp_redirect(site_url('/mexplay-login/'));
                exit;
            }
            
            // Verify the payment
            $paystack = new Mexplay_OTT_Premium_Paystack();
            $verification = $paystack->verify_transaction($reference);
            
            if ($verification['status'] === 'success') {
                $user_id = get_current_user_id();
                $package_id = isset($_SESSION['mexplay_pending_package']['id']) ? $_SESSION['mexplay_pending_package']['id'] : 0;
                
                if (empty($package_id)) {
                    $_SESSION['mexplay_payment_error'] = 'Invalid package selection.';
                    wp_redirect(site_url('/mexplay-subscription/'));
                    exit;
                }
                
                // Create subscription and voucher
                $subscription_manager = new Mexplay_OTT_Premium_Subscription();
                $result = $subscription_manager->create_paid_subscription(
                    $user_id,
                    $package_id,
                    $verification['amount'] / 100, // Convert from kobo to naira
                    $reference,
                    $verification['transaction_id']
                );
                
                if ($result['success']) {
                    // Clear pending package from session
                    unset($_SESSION['mexplay_pending_package']);
                    
                    // Set success message and voucher code for thank you page
                    $_SESSION['mexplay_payment_success'] = true;
                    $_SESSION['mexplay_voucher_details'] = array(
                        'voucher_code' => $result['voucher_code'],
                        'package_name' => $result['package_name'],
                        'valid_until' => $result['expiry_date'],
                        'amount' => $verification['amount'] / 100
                    );
                    
                    // Set current voucher for session
                    $_SESSION['mexplay_current_voucher'] = $result['voucher_code'];
                    
                    // Send welcome email
                    $email_manager = new Mexplay_OTT_Premium_Email();
                    $user_data = get_userdata($user_id);
                    $email_manager->send_welcome_email($user_data->user_email, $user_data->display_name, $result['voucher_code'], $result['expiry_date'], $result['package_name']);
                    
                    // Redirect to thank you page
                    wp_redirect(site_url('/mexplay-thank-you/'));
                    exit;
                } else {
                    $_SESSION['mexplay_payment_error'] = $result['message'];
                    wp_redirect(site_url('/mexplay-subscription/'));
                    exit;
                }
            } else {
                $_SESSION['mexplay_payment_error'] = 'Payment verification failed: ' . $verification['message'];
                wp_redirect(site_url('/mexplay-subscription/'));
                exit;
            }
        }
    }

    /**
     * AJAX handler for updating user profile.
     *
     * @since    1.0.0
     */
    public function update_profile() {
        // Check nonce for security
        check_ajax_referer('mexplay-public-nonce', 'nonce');
        
        // Check if user is logged in
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'You must be logged in to update your profile.'));
            return;
        }
        
        // Get user ID
        $user_id = get_current_user_id();
        
        // Get and sanitize form data
        $first_name = sanitize_text_field($_POST['first_name']);
        $last_name = sanitize_text_field($_POST['last_name']);
        $phone = sanitize_text_field($_POST['phone']);
        $current_password = isset($_POST['current_password']) ? $_POST['current_password'] : '';
        $new_password = isset($_POST['new_password']) ? $_POST['new_password'] : '';
        $confirm_password = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';
        
        // Update basic info
        update_user_meta($user_id, 'first_name', $first_name);
        update_user_meta($user_id, 'last_name', $last_name);
        update_user_meta($user_id, 'mexplay_user_phone', $phone);
        
        $user_manager = new Mexplay_OTT_Premium_User();
        $user_manager->log_activity($user_id, 'profile_updated', 'User updated their profile.');
        
        // Check if password change is requested
        if (!empty($current_password) && !empty($new_password)) {
            // Verify current password
            $user = get_user_by('id', $user_id);
            if (!wp_check_password($current_password, $user->data->user_pass, $user_id)) {
                wp_send_json_error(array('message' => 'Current password is incorrect.'));
                return;
            }
            
            // Validate new password
            if (strlen($new_password) < 6) {
                wp_send_json_error(array('message' => 'New password must be at least 6 characters.'));
                return;
            }
            
            // Check if passwords match
            if ($new_password !== $confirm_password) {
                wp_send_json_error(array('message' => 'New passwords do not match.'));
                return;
            }
            
            // Update password
            wp_set_password($new_password, $user_id);
            
            // Update auth cookie
            wp_set_auth_cookie($user_id, true);
            
            $user_manager->log_activity($user_id, 'password_changed', 'User changed their password.');
        }
        
        wp_send_json_success(array('message' => 'Profile updated successfully.'));
    }

    /**
     * AJAX handler for initiating subscription renewal.
     *
     * @since    1.0.0
     */
    public function renew_subscription() {
        // Check nonce for security
        check_ajax_referer('mexplay-public-nonce', 'nonce');
        
        // Check if user is logged in
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'You must be logged in to renew your subscription.'));
            return;
        }
        
        $package_id = intval($_POST['package_id']);
        
        if (empty($package_id)) {
            wp_send_json_error(array('message' => 'Please select a subscription package.'));
            return;
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'mexplay_subscription_packages';
        $package = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $package_id));
        
        if (!$package) {
            wp_send_json_error(array('message' => 'Invalid subscription package.'));
            return;
        }
        
        // Store package details in session for Paystack payment
        $_SESSION['mexplay_pending_package'] = array(
            'id' => $package->id,
            'name' => $package->name,
            'price' => $package->price,
            'duration' => $package->duration,
            'duration_unit' => $package->duration_unit
        );
        
        wp_send_json_success(array(
            'message' => 'Package selected for renewal.',
            'package' => array(
                'id' => $package->id,
                'name' => $package->name,
                'price' => $package->price,
                'duration' => $package->duration,
                'duration_unit' => $package->duration_unit,
                'is_trial' => $package->is_trial
            )
        ));
    }

    /**
     * AJAX handler for getting available subscription packages.
     *
     * @since    1.0.0
     */
    public function get_subscription_packages() {
        // Check nonce for security
        check_ajax_referer('mexplay-public-nonce', 'nonce');
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'mexplay_subscription_packages';
        $packages = $wpdb->get_results("SELECT * FROM $table_name WHERE status = 'active' ORDER BY price ASC");
        
        // Format packages for frontend
        $formatted_packages = array();
        foreach ($packages as $package) {
            $formatted_packages[] = array(
                'id' => $package->id,
                'name' => $package->name,
                'description' => $package->description,
                'price' => $package->price,
                'price_formatted' => '₦' . number_format($package->price, 2),
                'duration' => $package->duration,
                'duration_unit' => $package->duration_unit,
                'duration_formatted' => $package->duration . ' ' . ucfirst($package->duration_unit) . 
                                      ($package->duration > 1 && substr($package->duration_unit, -1) !== 's' ? 's' : ''),
                'is_trial' => (bool) $package->is_trial
            );
        }
        
        wp_send_json_success(array('packages' => $formatted_packages));
    }
}

