<?php
/**
 * Thank you page template.
 *
 * @link       https://mexplay.com
 * @since      1.0.0
 *
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/public/partials
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Check if user is logged in
if (!is_user_logged_in()) {
    wp_redirect(site_url('/mexplay-login/'));
    exit;
}

// Get voucher details from session
$success = isset($_SESSION['mexplay_payment_success']) ? $_SESSION['mexplay_payment_success'] : false;
$voucher_details = isset($_SESSION['mexplay_voucher_details']) ? $_SESSION['mexplay_voucher_details'] : array();

// Clear session data
unset($_SESSION['mexplay_payment_success']);
unset($_SESSION['mexplay_voucher_details']);

// If no success data, redirect to dashboard
if (!$success && empty($voucher_details)) {
    wp_redirect(site_url('/mexplay-dashboard/'));
    exit;
}
?>

<div class="mexplay-container">
    <div class="mexplay-thank-you-container mexplay-fade-in">
        <div class="mexplay-thank-you-icon">
            <img src="https://mextvmedia.sirv.com/icons/icons8-checkmark-24.png" width="24" height="24" alt="">
        </div>
        
        <h1 class="mexplay-thank-you-title">Thank You for Your Subscription!</h1>
        
        <p class="mexplay-thank-you-message">
            Your payment has been processed successfully and your voucher has been generated.
            Please save your voucher code for future logins.
        </p>
        
        <div class="mexplay-voucher-details mexplay-slide-in">
            <h2 style="margin-top: 0; color: var(--mexplay-primary-color);">Voucher Details</h2>
            
            <div class="mexplay-voucher-code">
                <?php echo esc_html($voucher_details['voucher_code']); ?>
            </div>
            
            <div class="mexplay-voucher-info">
                <strong>Package:</strong> <?php echo esc_html($voucher_details['package_name']); ?>
            </div>
            
            <div class="mexplay-voucher-info">
                <strong>Valid Until:</strong> <?php echo esc_html(date('F j, Y', strtotime($voucher_details['valid_until']))); ?>
            </div>
            
            <div class="mexplay-voucher-info">
                <strong>Amount Paid:</strong> ₦<?php echo number_format(esc_html($voucher_details['amount']), 2); ?>
            </div>
        </div>
        
        <p style="margin: 20px 0;">
            <strong>Important:</strong> You'll need to enter your voucher code each time you log in. 
            Please make sure to save it somewhere secure.
        </p>
        
        <div style="display: flex; justify-content: center; gap: 20px;">
            <a href="<?php echo esc_url(site_url('/mexplay-login/')); ?>" class="mexplay-button">
                <img src="https://mextvmedia.sirv.com/icons/icons8-sign-in-24.png" width="24" height="24" alt=""> Login Now
            </a>
            
            <a href="<?php echo esc_url(site_url('/mexplay-dashboard/')); ?>" class="mexplay-button accent">
                <img src="https://mextvmedia.sirv.com/icons/icons8-speedometer-24.png" width="24" height="24" alt=""> Go to Dashboard
            </a>
        </div>
    </div>
</div>
