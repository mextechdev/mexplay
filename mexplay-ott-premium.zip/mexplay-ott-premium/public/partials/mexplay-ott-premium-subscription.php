<?php
/**
 * Subscription page template.
 *
 * @link       https://mexplay.com
 * @since      1.0.0
 *
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/public/partials
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Check if user is logged in
if (!is_user_logged_in()) {
    wp_redirect(site_url('/mexplay-login/'));
    exit;
}

// Get user info
$current_user = wp_get_current_user();

// Get any error messages
$error = isset($_SESSION['mexplay_subscription_error']) ? $_SESSION['mexplay_subscription_error'] : '';
$payment_error = isset($_SESSION['mexplay_payment_error']) ? $_SESSION['mexplay_payment_error'] : '';

// Clear session error data
unset($_SESSION['mexplay_subscription_error']);
unset($_SESSION['mexplay_payment_error']);

// Get subscription packages
global $wpdb;
$table_name = $wpdb->prefix . 'mexplay_subscription_packages';
$packages = $wpdb->get_results("SELECT * FROM $table_name WHERE status = 'active' ORDER BY price ASC");

// Check if user has already used a free trial
$user_id = get_current_user_id();
$voucher_manager = new Mexplay_OTT_Premium_Voucher();
$has_used_trial = $voucher_manager->has_used_free_trial($user_id);
$is_admin = current_user_can('manage_options');
?>

<div class="mexplay-container mexplay-fade-in">
    <h1 class="mexplay-title">Choose Your Subscription</h1>
    
    <?php if (!empty($error)): ?>
        <div class="mexplay-alert error"><?php echo esc_html($error); ?></div>
    <?php endif; ?>
    
    <?php if (!empty($payment_error)): ?>
        <div class="mexplay-alert error">
            <strong>Payment Error:</strong> <?php echo esc_html($payment_error); ?>
        </div>
    <?php endif; ?>
    
    <p>Welcome, <strong><?php echo esc_html($current_user->display_name); ?></strong>! Please select a subscription package to access premium content.</p>
    
    <div class="mexplay-packages-container">
        <?php if (empty($packages)): ?>
            <div class="mexplay-alert info">No subscription packages available at this time. Please check back later.</div>
        <?php else: ?>
            <?php foreach ($packages as $package): ?>
                <?php 
                // Skip trial packages if user has already used one and is not admin
                if ($package->is_trial && $has_used_trial && !$is_admin) {
                    continue;
                }
                ?>
                <div class="mexplay-package-card <?php echo $package->is_trial ? 'trial' : ''; ?>">
                    <div class="mexplay-package-header <?php echo $package->is_trial ? 'trial' : ''; ?>">
                        <h3 class="mexplay-package-name"><?php echo esc_html($package->name); ?></h3>
                        <div class="mexplay-package-price">₦<?php echo number_format(esc_html($package->price), 2); ?></div>
                        <div class="mexplay-package-duration">
                            <?php 
                                echo esc_html($package->duration) . ' ' . 
                                     esc_html(ucfirst($package->duration_unit)) . 
                                     ($package->duration > 1 && substr($package->duration_unit, -1) !== 's' ? 's' : '');
                            ?>
                        </div>
                        <?php if ($package->is_trial): ?>
                            <div class="mexplay-package-badge">Free Trial</div>
                        <?php endif; ?>
                    </div>
                    <div class="mexplay-package-body">
                        <div class="mexplay-package-description">
                            <?php echo !empty($package->description) ? esc_html($package->description) : 'No description available.'; ?>
                        </div>
                        <button type="button" class="mexplay-button full-width mexplay-package-select" data-package-id="<?php echo esc_attr($package->id); ?>">
                            <i class="fas fa-check-circle"></i> Select
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    
    <div id="mexplay-subscription-form" style="margin-top: 30px;">
        <div class="mexplay-form">
            <div class="mexplay-form-header">
                <h2><i class="fas fa-shopping-cart" style="color: #d96e28;"></i> Complete Your Subscription</h2>
            </div>
            
            <form method="post" action="">
                <?php wp_nonce_field('mexplay_subscription_action', 'mexplay_subscription_nonce'); ?>
                
                <input type="hidden" id="package_id" name="package_id" value="">
                <input type="hidden" id="mexplay-user-email" value="<?php echo esc_attr($current_user->user_email); ?>">
                <input type="hidden" id="mexplay-user-name" value="<?php echo esc_attr($current_user->display_name); ?>">
                <input type="hidden" id="mexplay-user-phone" value="<?php echo esc_attr(get_user_meta($current_user->ID, 'mexplay_user_phone', true)); ?>">
                
                <p>Please click the button below to complete your subscription.</p>
                
                <div class="mexplay-form-footer">
                    <a href="<?php echo esc_url(site_url('/mexplay-dashboard/')); ?>" class="mexplay-button" style="background-color: #6c757d;">
                        <i class="fas fa-arrow-left"></i> Cancel
                    </a>
                    <button type="button" id="mexplay-paystack-button" class="mexplay-button accent">
                        <i class="fas fa-credit-card"></i> Complete Subscription
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
