<?php
/**
 * Login form template.
 *
 * @link       https://mexplay.com
 * @since      1.0.0
 *
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/public/partials
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Check if user is already logged in
if (is_user_logged_in()) {
    wp_redirect(site_url('/mexplay-dashboard/'));
    exit;
}

// Get any error messages
$errors = isset($_SESSION['mexplay_login_errors']) ? $_SESSION['mexplay_login_errors'] : array();
$username = isset($_SESSION['mexplay_login_username']) ? $_SESSION['mexplay_login_username'] : '';

// Clear session data
unset($_SESSION['mexplay_login_errors']);
unset($_SESSION['mexplay_login_username']);
?>

<script>
    // Add mexplay-body class directly for more reliable styling
    document.body.classList.add('mexplay-body');
</script>

<div class="mexplay-container mexplay-fade-in">
    <div class="mexplay-row" style="display: flex; justify-content: center;">
        <div class="mexplay-col" style="max-width: 500px; width: 100%;">
            <div class="mexplay-form mexplay-slide-in">
                <div class="mexplay-form-header">
                    <h2><img src="https://mextvmedia.sirv.com/icons/icons8-sign-in-24.png" width="24" height="24" alt=""> Login to MexPlay</h2>
                </div>
                
                <?php if (!empty($errors)): ?>
                    <div class="mexplay-alert error">
                        <ul style="margin: 0; padding-left: 20px;">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo esc_html($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form method="post" action="">
                    <?php wp_nonce_field('mexplay_login_action', 'mexplay_login_nonce'); ?>
                    
                    <div class="mexplay-form-group">
                        <label for="username"><img src="https://mextvmedia.sirv.com/icons/icons8-user-24.png" width="24" height="24" alt=""> Username or Email</label>
                        <input type="text" id="username" name="username" value="<?php echo esc_attr($username); ?>" required>
                    </div>
                    
                    <div class="mexplay-form-group">
                        <label for="password"><img src="https://mextvmedia.sirv.com/icons/icons8-lock-24.png" width="24" height="24" alt=""> Password</label>
                        <div style="position: relative;">
                            <input type="password" id="password" name="password" required>
                            <span class="mexplay-password-toggle" style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); cursor: pointer;">
                                <img src="https://mextvmedia.sirv.com/icons/icons8-eye-24.png" width="24" height="24" alt="">
                            </span>
                        </div>
                    </div>
                    
                    <div class="mexplay-form-group">
                        <label for="voucher_code"><img src="https://mextvmedia.sirv.com/icons/icons8-ticket-24.png" width="24" height="24" alt=""> Voucher Code</label>
                        <input type="text" id="voucher_code" name="voucher_code" required>
                        <p class="description" style="font-size: 12px; color: #666; margin-top: 5px;">
                            Enter your purchased voucher code to access premium content.
                        </p>
                    </div>
                    
                    <div class="mexplay-form-footer">
                        <button type="submit" class="mexplay-button full-width">
                            <img src="https://mextvmedia.sirv.com/icons/icons8-sign-in-24.png" width="24" height="24" alt=""> Log In
                        </button>
                    </div>
                </form>
                
                <div class="mexplay-form-help">
                    Don't have an account? <a href="<?php echo esc_url(site_url('/mexplay-register/')); ?>">Register</a>
                    <?php if(current_user_can('manage_options') || current_user_can('administrator')): ?>
                    <br><small><a href="<?php echo esc_url(admin_url()); ?>">Access Admin Dashboard</a></small>
                    <?php endif; ?>
                    <br><small><a href="<?php echo esc_url(wp_login_url()); ?>?redirect_to=<?php echo esc_url(admin_url()); ?>">Admin Login</a></small>
                </div>
            </div>
        </div>
    </div>
</div>
