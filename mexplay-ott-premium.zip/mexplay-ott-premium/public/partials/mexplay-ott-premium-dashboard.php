<?php
/**
 * User dashboard template.
 *
 * @link       https://mexplay.com
 * @since      1.0.0
 *
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/public/partials
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Check if user is logged in
if (!is_user_logged_in()) {
    wp_redirect(site_url('/mexplay-login/'));
    exit;
}

// Get user info
$current_user = wp_get_current_user();
$user_id = $current_user->ID;
$first_name = get_user_meta($user_id, 'first_name', true);
$last_name = get_user_meta($user_id, 'last_name', true);
$phone = get_user_meta($user_id, 'mexplay_user_phone', true);

// Get subscription and voucher details
global $wpdb;
$table_vouchers = $wpdb->prefix . 'mexplay_vouchers';
$table_packages = $wpdb->prefix . 'mexplay_subscription_packages';

// Get current voucher code from session or find the most recent one
$current_voucher_code = isset($_SESSION['mexplay_current_voucher']) ? $_SESSION['mexplay_current_voucher'] : '';

if (empty($current_voucher_code)) {
    // Get the most recent active voucher
    $voucher = $wpdb->get_row($wpdb->prepare("
        SELECT v.*, p.name as package_name, p.description as package_description, p.is_trial
        FROM $table_vouchers v
        JOIN $table_packages p ON v.package_id = p.id
        WHERE v.user_id = %d
        ORDER BY v.created_at DESC
        LIMIT 1
    ", $user_id));
    
    if ($voucher) {
        $current_voucher_code = $voucher->voucher_code;
        $_SESSION['mexplay_current_voucher'] = $current_voucher_code;
    }
} else {
    // Get details for the current voucher from session
    $voucher = $wpdb->get_row($wpdb->prepare("
        SELECT v.*, p.name as package_name, p.description as package_description, p.is_trial
        FROM $table_vouchers v
        JOIN $table_packages p ON v.package_id = p.id
        WHERE v.voucher_code = %s AND v.user_id = %d
    ", $current_voucher_code, $user_id));
}

// Get all packages for subscription renewal
$packages = $wpdb->get_results("SELECT * FROM $table_packages WHERE status = 'active' ORDER BY price ASC");

// Check if user has already used a free trial
$voucher_manager = new Mexplay_OTT_Premium_Voucher();
$has_used_trial = $voucher_manager->has_used_free_trial($user_id);
$is_admin = current_user_can('manage_options');

// Determine subscription status
$subscription_status = 'inactive';
$status_class = 'expired';
$expires_in_days = 0;

if ($voucher) {
    if ($voucher->status === 'active' && strtotime($voucher->valid_until) >= time()) {
        $subscription_status = 'active';
        $status_class = $voucher->is_trial ? 'trial' : 'active';
        $expires_in_days = ceil((strtotime($voucher->valid_until) - time()) / (60 * 60 * 24));
    } else {
        $subscription_status = 'expired';
    }
}

// Get subscription history
$table_subscriptions = $wpdb->prefix . 'mexplay_user_subscriptions';
$subscription_history = $wpdb->get_results($wpdb->prepare("
    SELECT s.*, p.name as package_name, v.voucher_code, v.valid_until
    FROM $table_subscriptions s
    JOIN $table_packages p ON s.package_id = p.id
    JOIN $table_vouchers v ON s.voucher_id = v.id
    WHERE s.user_id = %d
    ORDER BY s.created_at DESC
    LIMIT 10
", $user_id));

// Get active tab
$active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'dashboard';
?>

<div class="mexplay-container mexplay-fade-in">
    <div class="mexplay-dashboard">
        <!-- Sidebar -->
        <div class="mexplay-dashboard-sidebar">
            <div class="mexplay-dashboard-sidebar-header">
                <div class="mexplay-user-avatar">
                    <img src="https://mextvmedia.sirv.com/icons/icons8-user-24.png" width="24" height="24" alt="">
                </div>
                <h2 class="mexplay-user-name"><?php echo esc_html($current_user->display_name); ?></h2>
            </div>
            
            <ul class="mexplay-dashboard-menu">
                <li class="mexplay-dashboard-menu-item">
                    <a href="<?php echo esc_url(add_query_arg('tab', 'dashboard')); ?>" class="<?php echo $active_tab === 'dashboard' ? 'active' : ''; ?>">
                        <img src="https://mextvmedia.sirv.com/icons/icons8-speedometer-24.png" width="24" height="24" alt=""> Dashboard
                    </a>
                </li>
                <li class="mexplay-dashboard-menu-item">
                    <a href="<?php echo esc_url(add_query_arg('tab', 'profile')); ?>" class="<?php echo $active_tab === 'profile' ? 'active' : ''; ?>">
                        <img src="https://mextvmedia.sirv.com/icons/icons8-user-24%20(1).png" width="24" height="24" alt=""> My Profile
                    </a>
                </li>
                <li class="mexplay-dashboard-menu-item">
                    <a href="<?php echo esc_url(add_query_arg('tab', 'subscriptions')); ?>" class="<?php echo $active_tab === 'subscriptions' ? 'active' : ''; ?>">
                        <img src="https://mextvmedia.sirv.com/icons/icons8-ticket-24.png" width="24" height="24" alt=""> Subscription
                    </a>
                </li>
                <li class="mexplay-dashboard-menu-item">
                    <a href="<?php echo esc_url(add_query_arg('tab', 'history')); ?>" class="<?php echo $active_tab === 'history' ? 'active' : ''; ?>">
                        <img src="https://mextvmedia.sirv.com/icons/icons8-history-24.png" width="24" height="24" alt=""> Payment History
                    </a>
                </li>
                <li class="mexplay-dashboard-menu-item">
                    <a href="/live-tv" id="mexplay-live-tv-btn">
                        <img src="https://mextvmedia.sirv.com/icons/icons8-tv-24.png" width="24" height="24" alt=""> Live TV
                    </a>
                </li>
                <li class="mexplay-dashboard-menu-item">
                    <a href="/support" id="mexplay-support-btn">
                        <img src="https://mextvmedia.sirv.com/icons/icons8-headset-24.png" width="24" height="24" alt=""> Support
                    </a>
                </li>
                <li class="mexplay-dashboard-menu-item">
                    <a href="<?php echo esc_url(wp_logout_url(site_url('/mexplay-login/'))); ?>">
                        <img src="https://mextvmedia.sirv.com/icons/icons8-logout-24.png" width="24" height="24" alt=""> Logout
                    </a>
                </li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="mexplay-dashboard-content">
            <?php if ($active_tab === 'dashboard'): ?>
                <!-- Dashboard Tab -->
                <div class="mexplay-dashboard-card">
                    <div class="mexplay-dashboard-card-header">
                        <h2><img src="https://mextvmedia.sirv.com/icons/icons8-speedometer-24.png" width="24" height="24" alt=""> Dashboard Overview</h2>
                    </div>
                    <div class="mexplay-dashboard-card-body">
                        <div class="mexplay-subscription-details">
                            <div class="mexplay-subscription-detail">
                                <div class="mexplay-subscription-detail-label">Current Package</div>
                                <div class="mexplay-subscription-detail-value">
                                    <?php echo $voucher ? esc_html($voucher->package_name) : 'No active package'; ?>
                                </div>
                            </div>
                            
                            <div class="mexplay-subscription-detail">
                                <div class="mexplay-subscription-detail-label">Status</div>
                                <div class="mexplay-subscription-detail-value">
                                    <span class="mexplay-subscription-status <?php echo esc_attr($status_class); ?>">
                                        <?php echo ucfirst(esc_html($subscription_status)); ?>
                                    </span>
                                </div>
                            </div>
                            
                            <div class="mexplay-subscription-detail">
                                <div class="mexplay-subscription-detail-label">Voucher Code</div>
                                <div class="mexplay-subscription-detail-value">
                                    <?php echo $voucher ? esc_html($voucher->voucher_code) : 'N/A'; ?>
                                </div>
                            </div>
                            
                            <div class="mexplay-subscription-detail">
                                <div class="mexplay-subscription-detail-label">Expires In</div>
                                <div class="mexplay-subscription-detail-value">
                                    <?php 
                                    if ($subscription_status === 'active') {
                                        echo esc_html($expires_in_days) . ' days';
                                    } else {
                                        echo 'Expired';
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                        
                        <?php if ($subscription_status !== 'active'): ?>
                            <div style="margin-top: 20px;">
                                <div class="mexplay-alert warning">
                                    <strong>Attention:</strong> Your subscription has expired. Please renew to continue enjoying our premium content.
                                </div>
                                <a href="<?php echo esc_url(site_url('/mexplay-subscription/')); ?>" class="mexplay-button accent" style="margin-top: 15px;">
                                    <img src="https://mextvmedia.sirv.com/icons/icons8-sync-24.png" width="24" height="24" alt=""> Renew Subscription
                                </a>
                            </div>
                        <?php else: ?>
                            <div style="margin-top: 20px;">
                                <h3 style="color: var(--mexplay-primary-color); margin-bottom: 15px;">Quick Links</h3>
                                <div style="display: flex; flex-wrap: wrap; gap: 10px;">
                                    <a href="#" class="mexplay-button" id="mexplay-movies-btn">
                                        <img src="https://mextvmedia.sirv.com/icons/icons8-film-24.png" width="24" height="24" alt=""> Browse Movies
                                    </a>
                                    <a href="#" class="mexplay-button" id="mexplay-series-btn">
                                        <img src="https://mextvmedia.sirv.com/icons/icons8-tv-24.png" width="24" height="24" alt=""> TV Series
                                    </a>
                                    <a href="#" class="mexplay-button" id="mexplay-live-btn">
                                        <i class="fas fa-broadcast-tower"></i> Live Channels
                                    </a>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="mexplay-dashboard-card">
                    <div class="mexplay-dashboard-card-header">
                        <h2><img src="https://mextvmedia.sirv.com/icons/icons8-star-24.png" width="24" height="24" alt=""> Recommended for You</h2>
                    </div>
                    <div class="mexplay-dashboard-card-body">
                        <?php if ($subscription_status === 'active'): ?>
                            <p>Your personalized recommendations will appear here. Stay tuned!</p>
                        <?php else: ?>
                            <div class="mexplay-alert info">
                                <i class="fas fa-info-circle"></i> Renew your subscription to see personalized recommendations.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            
            <?php elseif ($active_tab === 'profile'): ?>
                <!-- Profile Tab -->
                <div class="mexplay-dashboard-card">
                    <div class="mexplay-dashboard-card-header">
                        <h2><img src="https://mextvmedia.sirv.com/icons/icons8-user-24%20(1).png" width="24" height="24" alt=""> My Profile</h2>
                    </div>
                    <div class="mexplay-dashboard-card-body">
                        <div id="profile-update-status" class="mexplay-alert" style="display: none;"></div>
                        
                        <form id="mexplay-profile-form">
                            <div class="mexplay-profile-form">
                                <div class="mexplay-profile-form-col">
                                    <div class="mexplay-form-group">
                                        <label for="first_name"><i class="fas fa-user"></i> First Name</label>
                                        <input type="text" id="first_name" name="first_name" value="<?php echo esc_attr($first_name); ?>">
                                    </div>
                                    
                                    <div class="mexplay-form-group">
                                        <label for="last_name"><img src="https://mextvmedia.sirv.com/icons/icons8-user-24.png" width="24" height="24" alt=""> Last Name</label>
                                        <input type="text" id="last_name" name="last_name" value="<?php echo esc_attr($last_name); ?>">
                                    </div>
                                    
                                    <div class="mexplay-form-group">
                                        <label for="phone"><img src="https://mextvmedia.sirv.com/icons/icons8-phone-24.png" width="24" height="24" alt=""> Phone Number</label>
                                        <input type="text" id="phone" name="phone" value="<?php echo esc_attr($phone); ?>">
                                    </div>
                                    
                                    <div class="mexplay-form-group">
                                        <label for="email"><img src="https://mextvmedia.sirv.com/icons/icons8-envelope-24.png" width="24" height="24" alt=""> Email Address</label>
                                        <input type="email" id="email" value="<?php echo esc_attr($current_user->user_email); ?>" disabled>
                                        <p class="description" style="font-size: 12px; color: #666; margin-top: 5px;">
                                            Email cannot be changed. Please contact support for assistance.
                                        </p>
                                    </div>
                                </div>
                                
                                <div class="mexplay-profile-form-col">
                                    <h3 style="color: var(--mexplay-primary-color); margin-top: 0;">Change Password</h3>
                                    
                                    <div class="mexplay-form-group">
                                        <label for="current_password"><img src="https://mextvmedia.sirv.com/icons/icons8-lock-24.png" width="24" height="24" alt=""> Current Password</label>
                                        <div style="position: relative;">
                                            <input type="password" id="current_password" name="current_password">
                                            <span class="mexplay-password-toggle" style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); cursor: pointer;">
                                                <img src="https://mextvmedia.sirv.com/icons/icons8-eye-24.png" width="24" height="24" alt="">
                                            </span>
                                        </div>
                                    </div>
                                    
                                    <div class="mexplay-form-group">
                                        <label for="new_password"><img src="https://mextvmedia.sirv.com/icons/icons8-key-24.png" width="24" height="24" alt=""> New Password</label>
                                        <div style="position: relative;">
                                            <input type="password" id="new_password" name="new_password">
                                            <span class="mexplay-password-toggle" style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); cursor: pointer;">
                                                <img src="https://mextvmedia.sirv.com/icons/icons8-eye-24.png" width="24" height="24" alt="">
                                            </span>
                                        </div>
                                    </div>
                                    
                                    <div class="mexplay-form-group">
                                        <label for="confirm_password"><img src="https://mextvmedia.sirv.com/icons/icons8-checkmark-24.png" width="24" height="24" alt=""> Confirm New Password</label>
                                        <div style="position: relative;">
                                            <input type="password" id="confirm_password" name="confirm_password">
                                            <span class="mexplay-password-toggle" style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); cursor: pointer;">
                                                <img src="https://mextvmedia.sirv.com/icons/icons8-eye-24.png" width="24" height="24" alt="">
                                            </span>
                                        </div>
                                    </div>
                                    
                                    <p class="description" style="font-size: 12px; color: #666; margin-top: 5px;">
                                        Leave password fields empty if you don't want to change your password.
                                    </p>
                                </div>
                            </div>
                            
                            <div style="margin-top: 20px;">
                                <button type="submit" class="mexplay-button">
                                    <img src="https://mextvmedia.sirv.com/icons/icons8-save-24.png" width="24" height="24" alt=""> Update Profile
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            
            <?php elseif ($active_tab === 'subscriptions'): ?>
                <!-- Subscription Tab -->
                <div class="mexplay-dashboard-card">
                    <div class="mexplay-dashboard-card-header">
                        <h2><img src="https://mextvmedia.sirv.com/icons/icons8-ticket-24.png" width="24" height="24" alt=""> My Subscription</h2>
                    </div>
                    <div class="mexplay-dashboard-card-body">
                        <?php if ($voucher): ?>
                            <div class="mexplay-subscription-details">
                                <div class="mexplay-subscription-detail">
                                    <div class="mexplay-subscription-detail-label">Package</div>
                                    <div class="mexplay-subscription-detail-value">
                                        <?php echo esc_html($voucher->package_name); ?>
                                    </div>
                                </div>
                                
                                <div class="mexplay-subscription-detail">
                                    <div class="mexplay-subscription-detail-label">Type</div>
                                    <div class="mexplay-subscription-detail-value">
                                        <?php echo $voucher->is_trial ? 'Free Trial' : 'Paid'; ?>
                                    </div>
                                </div>
                                
                                <div class="mexplay-subscription-detail">
                                    <div class="mexplay-subscription-detail-label">Voucher Code</div>
                                    <div class="mexplay-subscription-detail-value">
                                        <?php echo esc_html($voucher->voucher_code); ?>
                                    </div>
                                </div>
                                
                                <div class="mexplay-subscription-detail">
                                    <div class="mexplay-subscription-detail-label">Status</div>
                                    <div class="mexplay-subscription-detail-value">
                                        <span class="mexplay-subscription-status <?php echo esc_attr($status_class); ?>">
                                            <?php echo ucfirst(esc_html($subscription_status)); ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            
                            <div style="margin-top: 20px;">
                                <div class="mexplay-subscription-detail" style="width: 100%;">
                                    <div class="mexplay-subscription-detail-label">Description</div>
                                    <div class="mexplay-subscription-detail-value" style="text-align: left;">
                                        <?php echo !empty($voucher->package_description) ? esc_html($voucher->package_description) : 'No description available.'; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div style="margin-top: 20px;">
                                <div class="mexplay-subscription-detail" style="width: 100%;">
                                    <div class="mexplay-subscription-detail-label">Valid Period</div>
                                    <div class="mexplay-subscription-detail-value" style="text-align: left;">
                                        From: <?php echo esc_html(date('F j, Y', strtotime($voucher->valid_from))); ?><br>
                                        To: <?php echo esc_html(date('F j, Y', strtotime($voucher->valid_until))); ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div style="margin-top: 30px;">
                                <?php if ($subscription_status === 'active'): ?>
                                    <div class="mexplay-alert success">
                                        <img src="https://mextvmedia.sirv.com/icons/icons8-checkmark-24.png" width="24" height="24" alt=""> Your subscription is active. You can enjoy all our premium content.
                                    </div>
                                <?php else: ?>
                                    <div class="mexplay-alert warning">
                                        <img src="https://mextvmedia.sirv.com/icons/icons8-exclamation-24.png" width="24" height="24" alt=""> Your subscription has expired. Please renew to continue accessing premium content.
                                    </div>
                                <?php endif; ?>
                                
                                <button type="button" class="mexplay-button accent mexplay-renew-button" style="margin-top: 15px;">
                                    <img src="https://mextvmedia.sirv.com/icons/icons8-sync-24.png" width="24" height="24" alt=""> Renew Subscription
                                </button>
                            </div>
                        <?php else: ?>
                            <div class="mexplay-alert info">
                                <img src="https://mextvmedia.sirv.com/icons/icons8-info-24.png" width="24" height="24" alt=""> You don't have any active subscriptions.
                            </div>
                            
                            <a href="<?php echo esc_url(site_url('/mexplay-subscription/')); ?>" class="mexplay-button accent" style="margin-top: 15px;">
                                <img src="https://mextvmedia.sirv.com/icons/icons8-cart-24.png" width="24" height="24" alt=""> Subscribe Now
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            
            <?php elseif ($active_tab === 'history'): ?>
                <!-- Payment History Tab -->
                <div class="mexplay-dashboard-card">
                    <div class="mexplay-dashboard-card-header">
                        <h2><img src="https://mextvmedia.sirv.com/icons/icons8-time-24.png" width="24" height="24" alt=""> Payment History</h2>
                    </div>
                    <div class="mexplay-dashboard-card-body">
                        <?php if (empty($subscription_history)): ?>
                            <div class="mexplay-alert info">
                                <img src="https://mextvmedia.sirv.com/icons/icons8-info-24.png" width="24" height="24" alt=""> No payment history available.
                            </div>
                        <?php else: ?>
                            <div class="mexplay-table-responsive">
                                <table class="mexplay-table">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Package</th>
                                            <th>Voucher Code</th>
                                            <th>Amount</th>
                                            <th>Payment Status</th>
                                            <th>Expiry Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($subscription_history as $item): ?>
                                            <tr>
                                                <td><?php echo esc_html(date('M j, Y', strtotime($item->created_at))); ?></td>
                                                <td><?php echo esc_html($item->package_name); ?></td>
                                                <td><?php echo esc_html($item->voucher_code); ?></td>
                                                <td>₦<?php echo number_format(esc_html($item->payment_amount), 2); ?></td>
                                                <td>
                                                    <span class="mexplay-subscription-status <?php echo esc_attr($item->payment_status); ?>">
                                                        <?php echo ucfirst(esc_html($item->payment_status)); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo esc_html(date('M j, Y', strtotime($item->valid_until))); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Renew Subscription Modal -->
<div id="mexplay-renew-subscription-modal" class="mexplay-modal-overlay" style="display: none;">
    <div class="mexplay-modal" style="max-width: 800px;">
        <div class="mexplay-modal-header">
            <h3><img src="https://mextvmedia.sirv.com/icons/icons8-sync-24.png" width="24" height="24" alt=""> Renew Your Subscription</h3>
            <span class="mexplay-modal-close">&times;</span>
        </div>
        <div class="mexplay-modal-body">
            <p>Please select a subscription package to renew your membership:</p>
            
            <div id="mexplay-renew-packages" class="mexplay-packages-container">
                <div class="mexplay-loader"></div>
                <p>Loading available packages...</p>
            </div>
        </div>
    </div>
</div>

<!-- Script for Live TV button functionality -->
<script>
    jQuery(document).ready(function($) {
        $('#mexplay-live-tv-btn, #mexplay-support-btn, #mexplay-movies-btn, #mexplay-series-btn, #mexplay-live-btn').on('click', function(e) {
            e.preventDefault();
            alert('This feature will be available soon!');
        });
    });
</script>
