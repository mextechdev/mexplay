<?php
/**
 * Registration form template.
 *
 * @link       https://mexplay.com
 * @since      1.0.0
 *
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/public/partials
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Check if user is already logged in
if (is_user_logged_in()) {
    wp_redirect(site_url('/mexplay-dashboard/'));
    exit;
}

// Get any error messages
$errors = isset($_SESSION['mexplay_registration_errors']) ? $_SESSION['mexplay_registration_errors'] : array();
$form_data = isset($_SESSION['mexplay_registration_data']) ? $_SESSION['mexplay_registration_data'] : array();

// Clear session data
unset($_SESSION['mexplay_registration_errors']);
unset($_SESSION['mexplay_registration_data']);
?>

<script>
    // Add mexplay-body class directly for more reliable styling
    document.body.classList.add('mexplay-body');
</script>

<div class="mexplay-container mexplay-fade-in">
    <div class="mexplay-row" style="display: flex; justify-content: center;">
        <div class="mexplay-col" style="max-width: 600px; width: 100%;">
            <div class="mexplay-form mexplay-slide-in">
                <div class="mexplay-form-header">
                    <h2><img src="https://mextvmedia.sirv.com/icons/icons8-user-24.png" width="24" height="24" alt=""> Create Your MexPlay Account</h2>
                </div>
                
                <?php if (!empty($errors)): ?>
                    <div class="mexplay-alert error">
                        <ul style="margin: 0; padding-left: 20px;">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo esc_html($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form method="post" action="">
                    <?php wp_nonce_field('mexplay_register_action', 'mexplay_register_nonce'); ?>
                    
                    <div class="mexplay-form-group">
                        <label for="full_name"><img src="https://mextvmedia.sirv.com/icons/icons8-user-24.png" width="24" height="24" alt=""> Full Name</label>
                        <input type="text" id="full_name" name="full_name" value="<?php echo isset($form_data['full_name']) ? esc_attr($form_data['full_name']) : ''; ?>" required>
                    </div>
                    
                    <div class="mexplay-form-group">
                        <label for="username"><img src="https://mextvmedia.sirv.com/icons/icons8-user-tag-24.png" width="24" height="24" alt=""> Username</label>
                        <input type="text" id="username" name="username" value="<?php echo isset($form_data['username']) ? esc_attr($form_data['username']) : ''; ?>" required>
                    </div>
                    
                    <div class="mexplay-form-group">
                        <label for="phone"><img src="https://mextvmedia.sirv.com/icons/icons8-phone-24.png" width="24" height="24" alt=""> Phone Number</label>
                        <input type="tel" id="phone" name="phone" value="<?php echo isset($form_data['phone']) ? esc_attr($form_data['phone']) : ''; ?>" required>
                    </div>
                    
                    <div class="mexplay-form-group">
                        <label for="email"><img src="https://mextvmedia.sirv.com/icons/icons8-envelope-24.png" width="24" height="24" alt=""> Email Address</label>
                        <input type="email" id="email" name="email" value="<?php echo isset($form_data['email']) ? esc_attr($form_data['email']) : ''; ?>" required>
                    </div>
                    
                    <div class="mexplay-form-group">
                        <label for="password"><img src="https://mextvmedia.sirv.com/icons/icons8-lock-24.png" width="24" height="24" alt=""> Password</label>
                        <div style="position: relative;">
                            <input type="password" id="password" name="password" required>
                            <span class="mexplay-password-toggle" style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); cursor: pointer;">
                                <img src="https://mextvmedia.sirv.com/icons/icons8-eye-24.png" width="24" height="24" alt="">
                            </span>
                        </div>
                        <p class="description" style="font-size: 12px; color: #666; margin-top: 5px;">
                            Password must be at least 6 characters long.
                        </p>
                    </div>
                    
                    <div class="mexplay-form-footer">
                        <button type="submit" class="mexplay-button full-width">
                            <img src="https://mextvmedia.sirv.com/icons/icons8-user-24.png" width="24" height="24" alt=""> Register
                        </button>
                    </div>
                </form>
                
                <div class="mexplay-form-help">
                    Already have an account? <a href="<?php echo esc_url(site_url('/mexplay-login/')); ?>">Login</a>
                </div>
            </div>
        </div>
    </div>
</div>
