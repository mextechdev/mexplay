(function( $ ) {
    'use strict';

    /**
     * All public-facing functionality for the plugin.
     */
    
    /**
     * Function to check if icons are loaded properly
     * Adds appropriate fallback classes if needed
     * Enhanced with multiple detection methods and fallbacks
     */
    // Helper function to replace Font Awesome icons with SVG versions
    function replaceIconsWithSVG() {
        // Map of FA classes to SVG paths
        const iconMap = {
            'fa-user': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"></path></svg>`,
            'fa-dashboard': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z"></path></svg>`,
            'fa-credit-card': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M20 4H4c-1.11 0-1.99.89-1.99 2L2 18c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z"></path></svg>`,
            'fa-ticket': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M20 6h-2.18c.11-.31.18-.65.18-1 0-1.66-1.34-3-3-3-1.05 0-1.96.54-2.5 1.35l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2z"></path></svg>`,
            'fa-sign-out': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z"></path></svg>`,
            'fa-play': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M8 5v14l11-7z"></path></svg>`,
            'fa-comments': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM6 9h12v2H6V9zm8 5H6v-2h8v2zm4-6H6V6h12v2z"></path></svg>`,
            'fa-video': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4z"></path></svg>`,
            'fa-eye': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"></path></svg>`,
            'fa-eye-slash': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7zM2 4.27l2.28 2.28.46.46C3.08 8.3 1.78 10.02 1 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3 2 4.27zM7.53 9.8l1.55 1.55c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3 .22 0 .44-.03.65-.08l1.55 1.55c-.67.33-1.41.53-2.2.53-2.76 0-5-2.24-5-5 0-.79.2-1.53.53-2.2zm4.31-.78l3.15 3.15.02-.16c0-1.66-1.34-3-3-3l-.17.01z"></path></svg>`,
            'fa-save': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"></path></svg>`,
            'fa-spinner': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6 0 1.01-.25 1.97-.7 2.8l1.46 1.46C19.54 15.03 20 13.57 20 12c0-4.42-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6 0-1.01.25-1.97.7-2.8L5.24 7.74C4.46 8.97 4 10.43 4 12c0 4.42 3.58 8 8 8v3l4-4-4-4v3z"></path></svg>`,
            'fa-check-circle': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"></path></svg>`
        };
        
        // Find all Font Awesome icons and replace
        $('.fa, .fas, .far, .fab').each(function() {
            const $icon = $(this);
            let iconReplaced = false;
            
            // Check each class on the element
            $.each(this.classList, function(index, className) {
                if (iconMap[className]) {
                    // Create SVG element
                    const svgHtml = `<span class="mexplay-svg-icon ${className}">${iconMap[className]}</span>`;
                    $icon.after(svgHtml);
                    iconReplaced = true;
                }
            });
            
            // If we've replaced this icon, hide the original
            if (iconReplaced) {
                $icon.css('display', 'none');
            }
        });
    }
    
    function checkIconsLoaded() {
        // Create multiple test icon elements with different classes
        var $testIconFAS = $('<i class="fas fa-user"></i>');
        var $testIconFA = $('<i class="fa fa-user"></i>');
        var $testContainer = $('<div id="mexplay-icon-test"></div>');
        
        $testContainer.css({
            'position': 'absolute',
            'visibility': 'hidden',
            'top': '-9999px',
            'left': '-9999px'
        });
        
        $testContainer.append($testIconFAS).append($testIconFA);
        $('body').append($testContainer);
        
        // Pre-emptively add the icon-fallback class and remove it if icons work
        $('body').addClass('mexplay-ott-premium-icon-fallback');
        
        // Load FontAwesome from multiple CDNs directly in JavaScript as a backup
        function loadFontAwesomeFallback() {
            var cdnUrls = [
                'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
                'https://use.fontawesome.com/releases/v6.4.0/css/all.css',
                'https://ka-f.fontawesome.com/releases/v6.4.0/css/free.min.css'
            ];
            
            // Try loading from each CDN
            cdnUrls.forEach(function(url, index) {
                var link = document.createElement('link');
                link.rel = 'stylesheet';
                link.href = url;
                link.id = 'mexplay-fa-fallback-' + index;
                document.head.appendChild(link);
            });
        }
        
        // Create a more accurate FontAwesome detection
        function testFontAwesome() {
            var fontLoaded = false;
            
            // Test methods - width detection
            if (($testIconFAS.width() > 0 && $testIconFAS.height() > 0) || 
                ($testIconFA.width() > 0 && $testIconFA.height() > 0)) {
                fontLoaded = true;
            }
            
            // Test with computed style for pseudo-elements
            try {
                var computedStyleFAS = window.getComputedStyle($testIconFAS[0], ':before');
                var computedStyleFA = window.getComputedStyle($testIconFA[0], ':before');
                
                if ((computedStyleFAS && computedStyleFAS.content && 
                     computedStyleFAS.content !== 'none' && computedStyleFAS.content !== '') ||
                    (computedStyleFA && computedStyleFA.content && 
                     computedStyleFA.content !== 'none' && computedStyleFA.content !== '')) {
                    fontLoaded = true;
                }
            } catch (e) {
                console.log('Error testing FontAwesome:', e);
            }
            
            return fontLoaded;
        }
        
        // Try loading the fallback first
        loadFontAwesomeFallback();
        
        // Give sufficient time for fonts to load (multiple checks with increasing timeouts)
        var checkAttempts = 0;
        var maxAttempts = 3;
        
        function checkIcons() {
            checkAttempts++;
            console.log('Checking icons, attempt ' + checkAttempts);
            
            if (testFontAwesome()) {
                // Font Awesome loaded successfully!
                console.log('FontAwesome loaded successfully');
                $('body').removeClass('mexplay-ott-premium-icon-fallback');
                $testContainer.remove();
                return;
            }
            
            // If we've tried multiple times and still failed, add the svg fallback first
            if (checkAttempts >= maxAttempts) {
                console.log('All FontAwesome loading attempts failed, using SVG and emoji fallbacks');
                $('body').addClass('mexplay-ott-premium-svg-fallback');
                
                // Also add emoji fallback as the absolute last resort
                $('body').addClass('mexplay-ott-premium-emoji-fallback');
                
                // Replace FontAwesome icons with SVG elements
                replaceIconsWithSVG();
                
                $testContainer.remove();
                return;
            }
            
            // Try again with increasing timeout
            setTimeout(checkIcons, 500 * checkAttempts);
        }
        
        // Start the checking process
        setTimeout(checkIcons, 500);
    }
    
    $(document).ready(function() {
        // Force the body class to have mexplay-body
        $('body').addClass('mexplay-body');
        
        // Check if Font Awesome icons loaded properly
        checkIconsLoaded();
        
        // Add inline styles to force theme override
        const styleElement = document.createElement('style');
        styleElement.type = 'text/css';
        styleElement.innerHTML = `
            body.mexplay-body {
                background-color: #000000 !important;
                color: #e0e0e0 !important;
                font-family: 'Poppins', sans-serif !important;
            }
            
            body.mexplay-body #page,
            body.mexplay-body #main,
            body.mexplay-body #content,
            body.mexplay-body .site-content,
            body.mexplay-body .content-area,
            body.mexplay-body .entry-content,
            body.mexplay-body .page {
                background-color: #000000 !important;
                color: #e0e0e0 !important;
            }
            
            .mexplay-container * {
                font-family: 'Poppins', sans-serif !important;
            }
            
            .mexplay-title, 
            .mexplay-form-header h2,
            .mexplay-subtitle,
            .mexplay-package-name,
            .mexplay-user-name {
                font-family: 'Montserrat', sans-serif !important;
            }
        `;
        document.head.appendChild(styleElement);
        
        // Initialize tabs
        $('.mexplay-tab').on('click', function() {
            const tabId = $(this).data('tab');
            
            $('.mexplay-tab').removeClass('active');
            $(this).addClass('active');
            
            $('.mexplay-tab-content').removeClass('active');
            $('#' + tabId).addClass('active');
        });
        
        // Password visibility toggle
        $('.mexplay-password-toggle').on('click', function() {
            const inputField = $(this).siblings('input');
            const icon = $(this).find('i');
            
            if (inputField.attr('type') === 'password') {
                inputField.attr('type', 'text');
                icon.removeClass('fa-eye').addClass('fa-eye-slash');
            } else {
                inputField.attr('type', 'password');
                icon.removeClass('fa-eye-slash').addClass('fa-eye');
            }
        });
        
        // Subscription package selection
        $('.mexplay-package-select').on('click', function() {
            const packageId = $(this).data('package-id');
            $('#package_id').val(packageId);
            
            // Highlight selected package
            $('.mexplay-package-card').removeClass('selected');
            $(this).closest('.mexplay-package-card').addClass('selected');
            
            // Scroll to subscription form
            $('html, body').animate({
                scrollTop: $('#mexplay-subscription-form').offset().top - 50
            }, 500);
        });
        
        // Profile update form submission
        $('#mexplay-profile-form').on('submit', function(e) {
            e.preventDefault();
            
            const form = $(this);
            const submitBtn = form.find('button[type="submit"]');
            const statusMessage = $('#profile-update-status');
            
            submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Updating...');
            
            $.ajax({
                url: mexplay_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'mexplay_update_profile',
                    first_name: form.find('#first_name').val(),
                    last_name: form.find('#last_name').val(),
                    phone: form.find('#phone').val(),
                    current_password: form.find('#current_password').val(),
                    new_password: form.find('#new_password').val(),
                    confirm_password: form.find('#confirm_password').val(),
                    nonce: mexplay_vars.nonce
                },
                success: function(response) {
                    if (response.success) {
                        statusMessage.removeClass('error').addClass('success').html(response.data.message).show();
                        
                        // Clear password fields
                        form.find('#current_password, #new_password, #confirm_password').val('');
                    } else {
                        statusMessage.removeClass('success').addClass('error').html(response.data.message).show();
                    }
                    
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save"></i> Update Profile');
                    
                    // Hide status message after 5 seconds
                    setTimeout(function() {
                        statusMessage.fadeOut();
                    }, 5000);
                },
                error: function() {
                    statusMessage.removeClass('success').addClass('error').html('An error occurred. Please try again.').show();
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save"></i> Update Profile');
                }
            });
        });
        
        // Renew subscription
        $('.mexplay-renew-button').on('click', function() {
            // Show packages in modal
            $('#mexplay-renew-subscription-modal').fadeIn();
            
            // Load packages via AJAX
            $.ajax({
                url: mexplay_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'mexplay_get_subscription_packages',
                    nonce: mexplay_vars.nonce
                },
                success: function(response) {
                    if (response.success && response.data.packages) {
                        const packagesContainer = $('#mexplay-renew-packages');
                        packagesContainer.empty();
                        
                        $.each(response.data.packages, function(index, package) {
                            const packageCard = $(`
                                <div class="mexplay-package-card ${package.is_trial ? 'trial' : ''}">
                                    <div class="mexplay-package-header ${package.is_trial ? 'trial' : ''}">
                                        <h3 class="mexplay-package-name">${package.name}</h3>
                                        <div class="mexplay-package-price">${package.price_formatted}</div>
                                        <div class="mexplay-package-duration">${package.duration_formatted}</div>
                                        ${package.is_trial ? '<div class="mexplay-package-badge">Free Trial</div>' : ''}
                                    </div>
                                    <div class="mexplay-package-body">
                                        <div class="mexplay-package-description">${package.description || 'No description available.'}</div>
                                        <button type="button" class="mexplay-button full-width mexplay-select-renewal-package" data-package-id="${package.id}">
                                            <i class="fas fa-check-circle"></i> Select
                                        </button>
                                    </div>
                                </div>
                            `);
                            packagesContainer.append(packageCard);
                        });
                        
                        // Handle package selection for renewal
                        $('.mexplay-select-renewal-package').on('click', function() {
                            const packageId = $(this).data('package-id');
                            selectRenewalPackage(packageId);
                        });
                    } else {
                        $('#mexplay-renew-packages').html('<p>No packages available at this time.</p>');
                    }
                },
                error: function() {
                    $('#mexplay-renew-packages').html('<p class="error">Failed to load subscription packages. Please try again.</p>');
                }
            });
        });
        
        // Close renewal modal
        $('.mexplay-modal-close, .mexplay-close-modal').on('click', function() {
            $('.mexplay-modal-overlay').fadeOut();
        });
        
        // Close modal when clicking outside of it
        $('.mexplay-modal-overlay').on('click', function(e) {
            if ($(e.target).hasClass('mexplay-modal-overlay')) {
                $(this).fadeOut();
            }
        });
        
        // Function to select renewal package
        function selectRenewalPackage(packageId) {
            $.ajax({
                url: mexplay_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'mexplay_renew_subscription',
                    package_id: packageId,
                    nonce: mexplay_vars.nonce
                },
                success: function(response) {
                    if (response.success) {
                        const packageData = response.data.package;
                        
                        // Check if this is a free trial package
                        if (packageData.is_trial) {
                            // For free trial, redirect to dashboard directly
                            window.location.href = mexplay_vars.dashboard_url;
                        } else {
                            // For paid package, initiate Paystack payment
                            initializePaystack(packageData);
                        }
                    } else {
                        alert(response.data.message);
                    }
                },
                error: function() {
                    alert('An error occurred. Please try again.');
                }
            });
        }
        
        // Handle Paystack payment initialization
        if ($('#mexplay-paystack-button').length > 0) {
            $('#mexplay-paystack-button').on('click', function(e) {
                e.preventDefault();
                
                const packageId = $('#package_id').val();
                
                if (!packageId) {
                    alert('Please select a subscription package.');
                    return;
                }
                
                $.ajax({
                    url: mexplay_vars.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'mexplay_get_subscription_packages',
                        nonce: mexplay_vars.nonce
                    },
                    success: function(response) {
                        if (response.success && response.data.packages) {
                            // Find the selected package
                            const selectedPackage = response.data.packages.find(pkg => pkg.id === parseInt(packageId));
                            
                            if (selectedPackage) {
                                // For free trial, submit the form directly
                                if (selectedPackage.is_trial) {
                                    $('#mexplay-subscription-form').submit();
                                } else {
                                    // For paid package, initiate Paystack payment
                                    initializePaystack(selectedPackage);
                                }
                            } else {
                                alert('Selected package not found. Please try again.');
                            }
                        } else {
                            alert('Failed to retrieve package details. Please try again.');
                        }
                    },
                    error: function() {
                        alert('An error occurred. Please try again.');
                    }
                });
            });
        }
        
        // Check if payment should be initiated automatically (after redirect)
        if ($('#mexplay-subscription-form').length > 0 && window.location.href.includes('initiate_payment=1')) {
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.get('initiate_payment') === '1') {
                // Get package ID from session via AJAX
                $.ajax({
                    url: mexplay_vars.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'mexplay_get_subscription_packages',
                        nonce: mexplay_vars.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            // Find the ID of the first package (just for visual selection)
                            if (response.data.packages && response.data.packages.length > 0) {
                                // Automatically trigger payment
                                setTimeout(function() {
                                    $('#mexplay-paystack-button').trigger('click');
                                }, 1000);
                            }
                        }
                    }
                });
            }
        }
        
        // Initialize Paystack payment
        function initializePaystack(packageData) {
            // Close any open modals
            $('.mexplay-modal-overlay').fadeOut();
            
            // Get current user email from the page or data attribute
            let userEmail = '';
            if ($('#mexplay-user-email').length > 0) {
                userEmail = $('#mexplay-user-email').val() || $('#mexplay-user-email').text() || $('#mexplay-user-email').data('email');
            }
            
            // Get current user data
            let userName = $('#mexplay-user-name').text() || '';
            let phone = $('#mexplay-user-phone').text() || '';
            
            // Generate a reference
            const reference = 'MEXPLAY_' + Math.floor((Math.random() * 1000000000) + 1) + '_' + new Date().getTime();
            
            // Initialize Paystack
            if (typeof PaystackPop !== 'undefined') {
                const handler = PaystackPop.setup({
                    key: mexplay_vars.paystack_public_key,
                    email: userEmail,
                    amount: packageData.price * 100, // Convert to kobo (Paystack uses the smallest currency unit)
                    currency: 'NGN',
                    ref: reference,
                    metadata: {
                        custom_fields: [
                            {
                                display_name: "Package Name",
                                variable_name: "package_name",
                                value: packageData.name
                            },
                            {
                                display_name: "Package ID",
                                variable_name: "package_id",
                                value: packageData.id
                            }
                        ]
                    },
                    callback: function(response) {
                        // Redirect to callback URL with reference
                        window.location.href = window.location.href + 
                            (window.location.href.includes('?') ? '&' : '?') + 
                            'paystack-reference=' + response.reference + 
                            '&trxref=' + response.trxref;
                    },
                    onClose: function() {
                        // User closed payment modal
                        console.log('Payment window closed');
                    }
                });
                
                handler.openIframe();
            } else {
                alert('Payment gateway not available. Please try again later.');
            }
        }
    });

})( jQuery );

