<?php
/**
 * The plugin bootstrap file
 *
 * @link              https://mextvmedia.com.ng
 * @since             1.0.0
 * @package           Mexplay_OTT_Premium
 *
 * @wordpress-plugin
 * Plugin Name:       MexPlay OTT Premium
 * Plugin URI:        https://mextvmedia.com.ng
 * Description:       A premium advanced subscription voucher based membership plugin for OTT platforms with Paystack payment integration.
 * Version:           1.0.0
 * Author:            MexTech Limited
 * Author URI:        https://mextvmedia.com.ng
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       mexplay-ott-premium
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * Currently plugin version.
 */
define('MEXPLAY_OTT_PREMIUM_VERSION', '1.0.0');
define('MEXPLAY_OTT_PREMIUM_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MEXPLAY_OTT_PREMIUM_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * The code that runs during plugin activation.
 */
function activate_mexplay_ott_premium() {
    require_once plugin_dir_path(__FILE__) . 'includes/class-mexplay-ott-premium-activator.php';
    Mexplay_OTT_Premium_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 */
function deactivate_mexplay_ott_premium() {
    require_once plugin_dir_path(__FILE__) . 'includes/class-mexplay-ott-premium-deactivator.php';
    Mexplay_OTT_Premium_Deactivator::deactivate();
}

register_activation_hook(__FILE__, 'activate_mexplay_ott_premium');
register_deactivation_hook(__FILE__, 'deactivate_mexplay_ott_premium');

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path(__FILE__) . 'includes/class-mexplay-ott-premium.php';

/**
 * Include the SVG icons helper.
 */
require plugin_dir_path(__FILE__) . 'public/svg-icons.php';

/**
 * Helper function to get SVG icon - can be used directly in templates.
 * 
 * @since    1.0.0
 * @param    string    $icon_name    The name of the icon to get.
 * @param    string    $class        Additional classes to add to the icon.
 * @param    int       $size         The size of the icon in pixels.
 * @return   string    The SVG icon.
 */
function mexplay_icon($icon_name, $class = '', $size = 24) {
    return mexplay_get_icon($icon_name, $class, $size);
}

/**
 * Applies automatic icon replacement for Font Awesome icons. 
 * This function automatically wraps Font Awesome icon classes with SVG icons.
 *
 * @since    1.0.0
 * @param    string    $content    The content to process.
 * @return   string    The processed content.
 */
function mexplay_process_fontawesome_icons($content) {
    // Map of Font Awesome classes to icon names
    $icon_map = array(
        'fa-users' => 'users',
        'fa-user' => 'user',
        'fa-play-circle' => 'play-circle',
        'fa-ticket-alt' => 'ticket-alt',
        'fa-money-bill-wave' => 'money-bill-wave',
        'fa-tags' => 'tags',
        'fa-history' => 'history',
        'fa-list-alt' => 'list-alt',
        'fa-info-circle' => 'info-circle',
    );
    
    // Regular expression to find Font Awesome icons
    $pattern = '/<i class="(fas?|fab)\s+(fa-[a-z-]+)"><\/i>/i';
    
    return preg_replace_callback($pattern, function($matches) use ($icon_map) {
        $icon_class = $matches[2];
        if (isset($icon_map[$icon_class])) {
            return mexplay_get_icon($icon_map[$icon_class]);
        }
        return $matches[0]; // Return original if no match
    }, $content);
}

// Automatically fix FontAwesome icons in WordPress output
add_filter('the_content', 'mexplay_process_fontawesome_icons');

/**
 * Begins execution of the plugin.
 *
 * @since    1.0.0
 */
function run_mexplay_ott_premium() {
    $plugin = new Mexplay_OTT_Premium();
    $plugin->run();
}

run_mexplay_ott_premium();
