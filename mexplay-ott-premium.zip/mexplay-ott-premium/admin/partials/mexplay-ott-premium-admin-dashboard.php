<?php
/**
 * Admin dashboard page of the plugin.
 *
 * @link       https://mextvmedia.com.ng
 * @since      1.0.0
 *
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/admin/partials
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Get stats for the dashboard
global $wpdb;

// Total users with mexplay subscription
$total_users = $wpdb->get_var("
    SELECT COUNT(DISTINCT user_id) 
    FROM {$wpdb->prefix}mexplay_user_subscriptions
");

// Active subscriptions
$active_subscriptions = $wpdb->get_var("
    SELECT COUNT(*) 
    FROM {$wpdb->prefix}mexplay_vouchers 
    WHERE status = 'active' AND valid_until >= NOW()
");

// Total revenue
$total_revenue = $wpdb->get_var("
    SELECT SUM(payment_amount) 
    FROM {$wpdb->prefix}mexplay_user_subscriptions 
    WHERE payment_status = 'success'
");

// Active vouchers
$active_vouchers = $wpdb->get_var("
    SELECT COUNT(*) 
    FROM {$wpdb->prefix}mexplay_vouchers 
    WHERE status = 'active' AND valid_until >= NOW()
");

// Recent subscriptions
$recent_subscriptions = $wpdb->get_results("
    SELECT s.*, u.display_name, p.name as package_name, v.voucher_code, v.valid_until
    FROM {$wpdb->prefix}mexplay_user_subscriptions s
    JOIN {$wpdb->prefix}users u ON s.user_id = u.ID
    JOIN {$wpdb->prefix}mexplay_subscription_packages p ON s.package_id = p.id
    JOIN {$wpdb->prefix}mexplay_vouchers v ON s.voucher_id = v.id
    ORDER BY s.created_at DESC
    LIMIT 10
");

// Recent activity logs
$recent_logs = $wpdb->get_results("
    SELECT l.*, u.display_name
    FROM {$wpdb->prefix}mexplay_activity_logs l
    LEFT JOIN {$wpdb->prefix}users u ON l.user_id = u.ID
    ORDER BY l.created_at DESC
    LIMIT 10
");

?>

<div class="mexplay-admin-wrapper">
    <div class="mexplay-admin-header">
        <h1><?php echo mexplay_icon('play-circle', 'mexplay-header-icon', 28); ?> MexPlay OTT Dashboard</h1>
        <p>Manage your subscription-based OTT platform</p>
    </div>
    
    <div id="mexplay-alerts"></div>
    
    <div class="mexplay-admin-content">
        <div class="mexplay-stats-container">
            <div class="mexplay-stat-card users">
                <?php echo mexplay_icon('users', 'mexplay-stat-icon', 32); ?>
                <div class="stat-value"><?php echo $total_users ? esc_html($total_users) : '0'; ?></div>
                <div class="stat-label">Total Subscribers</div>
            </div>
            
            <div class="mexplay-stat-card subscriptions">
                <?php echo mexplay_icon('ticket-alt', 'mexplay-stat-icon', 32); ?>
                <div class="stat-value"><?php echo $active_subscriptions ? esc_html($active_subscriptions) : '0'; ?></div>
                <div class="stat-label">Active Subscriptions</div>
            </div>
            
            <div class="mexplay-stat-card revenue">
                <?php echo mexplay_icon('money-bill-wave', 'mexplay-stat-icon', 32); ?>
                <div class="stat-value"><?php echo $total_revenue ? '₦' . number_format(esc_html($total_revenue), 2) : '₦0.00'; ?></div>
                <div class="stat-label">Total Revenue</div>
            </div>
            
            <div class="mexplay-stat-card vouchers">
                <?php echo mexplay_icon('tags', 'mexplay-stat-icon', 32); ?>
                <div class="stat-value"><?php echo $active_vouchers ? esc_html($active_vouchers) : '0'; ?></div>
                <div class="stat-label">Active Vouchers</div>
            </div>
        </div>
        
        <div class="mexplay-card">
            <div class="mexplay-card-header">
                <h2><?php echo mexplay_icon('history', 'mexplay-card-icon', 24); ?> Recent Subscriptions</h2>
            </div>
            <div class="mexplay-card-body">
                <table class="mexplay-table">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Package</th>
                            <th>Voucher Code</th>
                            <th>Amount</th>
                            <th>Payment Status</th>
                            <th>Expiry Date</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($recent_subscriptions)): ?>
                            <tr>
                                <td colspan="7">No subscription data available.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($recent_subscriptions as $subscription): ?>
                                <tr>
                                    <td><?php echo esc_html($subscription->display_name); ?></td>
                                    <td><?php echo esc_html($subscription->package_name); ?></td>
                                    <td><?php echo esc_html($subscription->voucher_code); ?></td>
                                    <td>₦<?php echo esc_html(number_format($subscription->payment_amount, 2)); ?></td>
                                    <td>
                                        <span class="mexplay-badge <?php echo esc_attr($subscription->payment_status); ?>">
                                            <?php echo esc_html(ucfirst($subscription->payment_status)); ?>
                                        </span>
                                    </td>
                                    <td><?php echo esc_html(date('M j, Y', strtotime($subscription->valid_until))); ?></td>
                                    <td><?php echo esc_html(date('M j, Y', strtotime($subscription->created_at))); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php if (!empty($recent_subscriptions)): ?>
                <div class="mexplay-card-footer">
                    <a href="<?php echo esc_url(admin_url('admin.php?page=mexplay-user-management')); ?>" class="mexplay-button secondary">
                        <?php echo mexplay_icon('users', 'mexplay-button-icon', 16); ?> View All Users
                    </a>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="mexplay-card">
            <div class="mexplay-card-header">
                <h2><?php echo mexplay_icon('list-alt', 'mexplay-card-icon', 24); ?> Recent Activity Logs</h2>
            </div>
            <div class="mexplay-card-body">
                <table class="mexplay-table">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Action</th>
                            <th>Description</th>
                            <th>IP Address</th>
                            <th>Date & Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($recent_logs)): ?>
                            <tr>
                                <td colspan="5">No activity logs available.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($recent_logs as $log): ?>
                                <tr>
                                    <td><?php echo $log->user_id ? esc_html($log->display_name) : 'Guest'; ?></td>
                                    <td><?php echo esc_html($log->action); ?></td>
                                    <td><?php echo esc_html($log->description); ?></td>
                                    <td><?php echo esc_html($log->ip_address); ?></td>
                                    <td><?php echo esc_html(date('M j, Y g:i a', strtotime($log->created_at))); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="mexplay-card">
            <div class="mexplay-card-header">
                <h2><?php echo mexplay_icon('info-circle', 'mexplay-card-icon', 24); ?> Plugin Information</h2>
            </div>
            <div class="mexplay-card-body">
                <p><strong>MexPlay OTT</strong> is a comprehensive solution for creating subscription-based OTT platforms with WordPress.</p>
                <p>Version: <?php echo MEXPLAY_OTT_PREMIUM_VERSION; ?></p>
                
                <h3 class="mexplay-section-title">Available Shortcodes</h3>
                <table class="mexplay-table">
                    <thead>
                        <tr>
                            <th>Shortcode</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><code>[mexplay_login]</code></td>
                            <td>Displays the login form for users with voucher code field</td>
                        </tr>
                        <tr>
                            <td><code>[mexplay_register]</code></td>
                            <td>Displays the registration form for new users</td>
                        </tr>
                        <tr>
                            <td><code>[mexplay_subscription]</code></td>
                            <td>Displays available subscription packages for users to choose from</td>
                        </tr>
                        <tr>
                            <td><code>[mexplay_dashboard]</code></td>
                            <td>Displays the user dashboard with profile details, voucher information, and subscription status</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
