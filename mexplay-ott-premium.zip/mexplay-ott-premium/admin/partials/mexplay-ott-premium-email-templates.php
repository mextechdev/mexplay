<?php
/**
 * Email templates and settings page.
 *
 * @link       https://mexplay.com
 * @since      1.0.0
 *
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/admin/partials
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Get saved template and settings
$email_header = get_option('mexplay_email_template_header', '<div style="background-color:#000000; color:#ffffff; padding:20px; text-align:center;"><h1 style="color:#d96e28;">MexPlay OTT</h1></div>');
$email_footer = get_option('mexplay_email_template_footer', '<div style="background-color:#000000; color:#ffffff; padding:20px; text-align:center;"><p>&copy; ' . date('Y') . ' MexTv Media Inc, All Rights Reserved.</p></div>');
$welcome_subject = get_option('mexplay_welcome_email_subject', 'Welcome to MexPlay OTT');
$welcome_body = get_option('mexplay_welcome_email_body', '<p>Hello {user_name},</p><p>Welcome to MexPlay OTT! Thank you for registering.</p><p>Your subscription is now active.</p><p>Voucher Code: {voucher_code}</p><p>Valid Until: {expiry_date}</p><p>Enjoy your premium content!</p>');
$expiry_subject = get_option('mexplay_expiry_email_subject', 'Your MexPlay OTT Subscription is Expiring Soon');
$expiry_body = get_option('mexplay_expiry_email_body', '<p>Hello {user_name},</p><p>Your subscription is about to expire on {expiry_date}.</p><p>To continue enjoying our premium contents, please renew your subscription.</p><p>Thank you for being a valued subscriber!</p>');

$smtp_host = get_option('mexplay_smtp_host', '');
$smtp_port = get_option('mexplay_smtp_port', '587');
$smtp_username = get_option('mexplay_smtp_username', '');
$smtp_password = get_option('mexplay_smtp_password', '');
$smtp_from_email = get_option('mexplay_smtp_from_email', get_option('admin_email'));
$smtp_from_name = get_option('mexplay_smtp_from_name', get_option('blogname'));
$smtp_encryption = get_option('mexplay_smtp_encryption', 'tls');

?>

<div class="mexplay-admin-wrapper">
    <div class="mexplay-admin-header">
        <h1><img src="https://mextvmedia.sirv.com/icons/icons8-envelope-24.png" width="24" height="24" alt=""> Email Templates & Settings</h1>
        <p>Customize email templates and configure SMTP settings</p>
    </div>
    
    <div id="mexplay-alerts"></div>
    
    <div class="mexplay-admin-content">
        <div class="mexplay-tabs">
            <div class="mexplay-tab active" data-tab="email-templates">Email Templates</div>
            <div class="mexplay-tab" data-tab="smtp-settings">SMTP Settings</div>
            <div class="mexplay-tab" data-tab="test-email">Test Email</div>
        </div>
        
        <form id="mexplay-email-templates-form">
            <!-- Email Templates Tab -->
            <div id="email-templates" class="mexplay-tab-content active">
                <div class="mexplay-card">
                    <div class="mexplay-card-header">
                        <h2><img src="https://mextvmedia.sirv.com/icons/icons8-edit-24.png" width="24" height="24" alt=""> Common Header & Footer</h2>
                    </div>
                    <div class="mexplay-card-body">
                        <div class="mexplay-form-group">
                            <label for="email_header">Email Header:</label>
                            <textarea id="email_header" name="email_header" rows="5"><?php echo esc_textarea($email_header); ?></textarea>
                            <p class="description">This HTML will appear at the top of all emails.</p>
                        </div>
                        
                        <div class="mexplay-form-group">
                            <label for="email_footer">Email Footer:</label>
                            <textarea id="email_footer" name="email_footer" rows="5"><?php echo esc_textarea($email_footer); ?></textarea>
                            <p class="description">This HTML will appear at the bottom of all emails.</p>
                        </div>
                    </div>
                </div>
                
                <div class="mexplay-card">
                    <div class="mexplay-card-header">
                        <h2><img src="https://mextvmedia.sirv.com/icons/icons8-beam-24.png" width="24" height="24" alt=""> Welcome Email</h2>
                    </div>
                    <div class="mexplay-card-body">
                        <div class="mexplay-form-group">
                            <label for="welcome_subject">Subject:</label>
                            <input type="text" id="welcome_subject" name="welcome_subject" value="<?php echo esc_attr($welcome_subject); ?>">
                        </div>
                        
                        <div class="mexplay-form-group">
                            <label for="welcome_body">Body:</label>
                            <textarea id="welcome_body" name="welcome_body" rows="8"><?php echo esc_textarea($welcome_body); ?></textarea>
                            <p class="description">
                                Available placeholders: {user_name}, {voucher_code}, {expiry_date}, {package_name}, {site_name}
                            </p>
                        </div>
                    </div>
                </div>
                
                <div class="mexplay-card">
                    <div class="mexplay-card-header">
                        <h2><img src="https://mextvmedia.sirv.com/icons/icons8-hourglass-24.png" width="24" height="24" alt=""> Subscription Expiry Email</h2>
                    </div>
                    <div class="mexplay-card-body">
                        <div class="mexplay-form-group">
                            <label for="expiry_subject">Subject:</label>
                            <input type="text" id="expiry_subject" name="expiry_subject" value="<?php echo esc_attr($expiry_subject); ?>">
                        </div>
                        
                        <div class="mexplay-form-group">
                            <label for="expiry_body">Body:</label>
                            <textarea id="expiry_body" name="expiry_body" rows="8"><?php echo esc_textarea($expiry_body); ?></textarea>
                            <p class="description">
                                Available placeholders: {user_name}, {voucher_code}, {expiry_date}, {package_name}, {site_name}, {login_url}
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- SMTP Settings Tab -->
            <div id="smtp-settings" class="mexplay-tab-content">
                <div class="mexplay-card">
                    <div class="mexplay-card-header">
                        <h2><img src="https://mextvmedia.sirv.com/icons/icons8-server-24.png" width="24" height="24" alt=""> SMTP Server Configuration</h2>
                    </div>
                    <div class="mexplay-card-body">
                        <div class="mexplay-form-group">
                            <label for="smtp_host">SMTP Host:</label>
                            <input type="text" id="smtp_host" name="smtp_host" value="<?php echo esc_attr($smtp_host); ?>" placeholder="e.g., smtp.gmail.com">
                        </div>
                        
                        <div class="mexplay-form-group">
                            <label for="smtp_port">SMTP Port:</label>
                            <input type="number" id="smtp_port" name="smtp_port" value="<?php echo esc_attr($smtp_port); ?>" placeholder="e.g., 587">
                            <p class="description">Common ports: 25, 465 (SSL), 587 (TLS)</p>
                        </div>
                        
                        <div class="mexplay-form-group">
                            <label for="smtp_encryption">Encryption:</label>
                            <select id="smtp_encryption" name="smtp_encryption">
                                <option value="none" <?php selected($smtp_encryption, 'none'); ?>>None</option>
                                <option value="ssl" <?php selected($smtp_encryption, 'ssl'); ?>>SSL</option>
                                <option value="tls" <?php selected($smtp_encryption, 'tls'); ?>>TLS</option>
                            </select>
                        </div>
                        
                        <div class="mexplay-form-group">
                            <label for="smtp_username">SMTP Username:</label>
                            <input type="text" id="smtp_username" name="smtp_username" value="<?php echo esc_attr($smtp_username); ?>" placeholder="Usually your email address">
                        </div>
                        
                        <div class="mexplay-form-group">
                            <label for="smtp_password">SMTP Password:</label>
                            <div style="display: flex; align-items: center;">
                                <input type="password" id="smtp_password" name="smtp_password" value="<?php echo esc_attr($smtp_password); ?>" style="flex: 1;">
                                <span class="mexplay-toggle-password" data-target="#smtp_password" style="margin-left: 10px; cursor: pointer;">
                                    <i class="fas fa-eye"></i>
                                </span>
                            </div>
                            <p class="description">For Gmail, you may need to use an app password.</p>
                        </div>
                        
                        <div class="mexplay-form-group">
                            <label for="smtp_from_email">From Email:</label>
                            <input type="email" id="smtp_from_email" name="smtp_from_email" value="<?php echo esc_attr($smtp_from_email); ?>">
                        </div>
                        
                        <div class="mexplay-form-group">
                            <label for="smtp_from_name">From Name:</label>
                            <input type="text" id="smtp_from_name" name="smtp_from_name" value="<?php echo esc_attr($smtp_from_name); ?>">
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Test Email Tab -->
            <div id="test-email" class="mexplay-tab-content">
                <div class="mexplay-card">
                    <div class="mexplay-card-header">
                        <h2><img src="https://mextvmedia.sirv.com/icons/icons8-paper-plane-24.png" width="24" height="24" alt=""> Send Test Email</h2>
                    </div>
                    <div class="mexplay-card-body">
                        <p>Send a test email to verify your email settings are working correctly.</p>
                        
                        <div class="mexplay-form-group">
                            <label for="test_email">Send to Email:</label>
                            <input type="email" id="test_email" name="test_email" value="<?php echo esc_attr(get_option('admin_email')); ?>">
                        </div>
                        
                        <button type="button" id="mexplay-test-email-btn" class="mexplay-button primary">
                            <i class="fas fa-paper-plane"></i> Send Test Email
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="mexplay-form-actions">
                <button type="submit" class="mexplay-button primary">
                    <img src="https://mextvmedia.sirv.com/icons/icons8-save-24.png" width="24" height="24" alt=""> Save Settings
                </button>
            </div>
        </form>
    </div>
</div>
