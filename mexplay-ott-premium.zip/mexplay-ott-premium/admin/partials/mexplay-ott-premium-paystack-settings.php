<?php
/**
 * Paystack payment gateway settings page.
 *
 * @link       https://mexplay.com
 * @since      1.0.0
 *
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/admin/partials
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Get saved settings
$test_mode = get_option('mexplay_paystack_test_mode', 'yes');
$test_secret_key = get_option('mexplay_paystack_test_secret_key', '');
$test_public_key = get_option('mexplay_paystack_test_public_key', '');
$live_secret_key = get_option('mexplay_paystack_live_secret_key', '');
$live_public_key = get_option('mexplay_paystack_live_public_key', '');

// Generate the webhook URL
$webhook_url = rest_url('mexplay/v1/paystack-webhook');

?>

<div class="mexplay-admin-wrapper">
    <div class="mexplay-admin-header">
        <h1><img src="https://mextvmedia.sirv.com/icons/icons8-credit-card-24.png" width="24" height="24" alt=""> Paystack Settings</h1>
        <p>Configure your Paystack payment gateway integration</p>
    </div>
    
    <div id="mexplay-alerts"></div>
    
    <div class="mexplay-admin-content">
        <div class="mexplay-card">
            <div class="mexplay-card-header">
                <h2><img src="https://mextvmedia.sirv.com/icons/icons8-info-24.png" width="24" height="24" alt=""> Paystack Integration Guide</h2>
            </div>
            <div class="mexplay-card-body">
                <p>Follow these steps to set up your Paystack integration:</p>
                
                <ol>
                    <li>
                        <a href="https://dashboard.paystack.com/#/signup" target="_blank">Create a Paystack account</a> if you don't have one already.
                    </li>
                    <li>
                        Log in to your Paystack Dashboard to get your API keys.
                    </li>
                    <li>
                        Configure your webhook URL in your Paystack Dashboard to: <code class="mexplay-code"><?php echo esc_url($webhook_url); ?></code>
                    </li>
                    <li>
                        Enter your API keys below and save your settings.
                    </li>
                </ol>
                
                <div class="mexplay-alert info">
                    <strong>Important:</strong> For testing purposes, you can use Paystack's test cards found in their <a href="https://paystack.com/docs/payments/test-payments" target="_blank">documentation</a>.
                </div>
            </div>
        </div>
        
        <form id="mexplay-paystack-settings-form">
            <div class="mexplay-card">
                <div class="mexplay-card-header">
                    <h2><img src="https://mextvmedia.sirv.com/icons/icons8-cog-24.png" width="24" height="24" alt=""> API Configuration</h2>
                </div>
                <div class="mexplay-card-body">
                    <div class="mexplay-form-group">
                        <label>
                            <input type="checkbox" id="test_mode" name="test_mode" <?php checked($test_mode, 'yes'); ?>>
                            Enable Test Mode
                        </label>
                        <p class="description">Check this to use Paystack's test environment (recommended during development).</p>
                    </div>
                    
                    <div class="mexplay-form-group">
                        <h3 class="mexplay-section-title">Test API Keys</h3>
                        <p class="description">Used when test mode is enabled.</p>
                    </div>
                    
                    <div class="mexplay-form-group">
                        <label for="test_secret_key">Test Secret Key:</label>
                        <div style="display: flex; align-items: center;">
                            <input type="password" id="test_secret_key" name="test_secret_key" value="<?php echo esc_attr($test_secret_key); ?>" style="flex: 1;">
                            <span class="mexplay-toggle-password" data-target="#test_secret_key" style="margin-left: 10px; cursor: pointer;">
                                <i class="fas fa-eye"></i>
                            </span>
                        </div>
                    </div>
                    
                    <div class="mexplay-form-group">
                        <label for="test_public_key">Test Public Key:</label>
                        <input type="text" id="test_public_key" name="test_public_key" value="<?php echo esc_attr($test_public_key); ?>">
                    </div>
                    
                    <div class="mexplay-form-group">
                        <h3 class="mexplay-section-title">Live API Keys</h3>
                        <p class="description">Used in production when test mode is disabled.</p>
                    </div>
                    
                    <div class="mexplay-form-group">
                        <label for="live_secret_key">Live Secret Key:</label>
                        <div style="display: flex; align-items: center;">
                            <input type="password" id="live_secret_key" name="live_secret_key" value="<?php echo esc_attr($live_secret_key); ?>" style="flex: 1;">
                            <span class="mexplay-toggle-password" data-target="#live_secret_key" style="margin-left: 10px; cursor: pointer;">
                                <i class="fas fa-eye"></i>
                            </span>
                        </div>
                    </div>
                    
                    <div class="mexplay-form-group">
                        <label for="live_public_key">Live Public Key:</label>
                        <input type="text" id="live_public_key" name="live_public_key" value="<?php echo esc_attr($live_public_key); ?>">
                    </div>
                </div>
                <div class="mexplay-card-footer">
                    <button type="submit" class="mexplay-button primary">
                        <img src="https://mextvmedia.sirv.com/icons/icons8-save-24.png" width="24" height="24" alt=""> Save Settings
                    </button>
                </div>
            </div>
        </form>
        
        <div class="mexplay-card">
            <div class="mexplay-card-header">
                <h2><img src="https://mextvmedia.sirv.com/icons/icons8-clipboard-list-24.png" width="24" height="24" alt=""> Webhook Configuration</h2>
            </div>
            <div class="mexplay-card-body">
                <p>To receive payment notifications, add this webhook URL to your Paystack dashboard:</p>
                
                <div class="mexplay-form-group">
                    <label>Webhook URL:</label>
                    <div class="mexplay-input-with-copy">
                        <input type="text" value="<?php echo esc_url($webhook_url); ?>" readonly>
                        <button type="button" class="mexplay-button mexplay-copy-button" data-clipboard-text="<?php echo esc_url($webhook_url); ?>">
                            <i class="fas fa-copy"></i>
                        </button>
                    </div>
                </div>
                
                <div class="mexplay-alert warning">
                    <strong>Note:</strong> Your webhook URL must be publicly accessible for Paystack to send payment notifications.
                </div>
                
                <p>Webhook events to enable in your Paystack dashboard:</p>
                <ul>
                    <li><code>charge.success</code> - Triggered when a payment is successful</li>
                    <li><code>subscription.create</code> - Triggered when a subscription is created</li>
                    <li><code>subscription.disable</code> - Triggered when a subscription is disabled</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Copy webhook URL to clipboard
    $('.mexplay-copy-button').on('click', function() {
        const text = $(this).data('clipboard-text');
        const tempInput = $('<input>');
        $('body').append(tempInput);
        tempInput.val(text).select();
        document.execCommand('copy');
        tempInput.remove();
        
        $(this).html('<img src="https://mextvmedia.sirv.com/icons/icons8-checkmark-24.png" width="24" height="24" alt="">');
        setTimeout(() => {
            $(this).html('<img src="https://mextvmedia.sirv.com/icons/icons8-copy-24.png" width="24" height="24" alt="">');
        }, 2000);
    });
});
</script>
