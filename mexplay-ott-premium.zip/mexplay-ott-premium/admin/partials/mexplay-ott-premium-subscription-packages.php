<?php
/**
 * Subscription packages management page.
 *
 * @link       https://mexplay.com
 * @since      1.0.0
 *
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/admin/partials
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Get all subscription packages
global $wpdb;
$table_name = $wpdb->prefix . 'mexplay_subscription_packages';
$packages = $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC");

?>

<div class="mexplay-admin-wrapper">
    <div class="mexplay-admin-header">
        <h1><img src="https://mextvmedia.sirv.com/icons/icons8-box-open-24.png" width="24" height="24" alt=""> Subscription Packages</h1>
        <p>Manage your subscription packages</p>
    </div>
    
    <div id="mexplay-alerts"></div>
    
    <div class="mexplay-admin-content">
        <div class="mexplay-card">
            <div class="mexplay-card-header">
                <h2><img src="https://mextvmedia.sirv.com/icons/icons8-plus-24.png" width="24" height="24" alt=""> Add New Package</h2>
            </div>
            <div class="mexplay-card-body">
                <form id="mexplay-add-package-form">
                    <div class="mexplay-form-group">
                        <label for="package_name">Package Name:</label>
                        <input type="text" id="package_name" name="package_name" required>
                    </div>
                    
                    <div class="mexplay-form-group">
                        <label for="package_description">Description:</label>
                        <textarea id="package_description" name="package_description"></textarea>
                    </div>
                    
                    <div class="mexplay-form-group">
                        <label for="package_price">Price (₦):</label>
                        <input type="number" id="package_price" name="package_price" min="0" step="0.01" required>
                    </div>
                    
                    <div class="mexplay-form-group">
                        <label for="package_duration">Duration:</label>
                        <div style="display: flex; gap: 10px;">
                            <input type="number" id="package_duration" name="package_duration" min="1" required style="flex: 1;">
                            <select id="package_duration_unit" name="package_duration_unit" style="flex: 1;">
                                <option value="days">Days</option>
                                <option value="weeks">Weeks</option>
                                <option value="months">Months</option>
                                <option value="years">Years</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="mexplay-form-group">
                        <label>
                            <input type="checkbox" id="package_is_trial" name="package_is_trial">
                            This is a free trial package
                        </label>
                    </div>
                    
                    <button type="submit" class="mexplay-button primary">
                        <img src="https://mextvmedia.sirv.com/icons/icons8-plus-24.png" width="24" height="24" alt=""> Add Package
                    </button>
                </form>
            </div>
        </div>
        
        <div class="mexplay-card">
            <div class="mexplay-card-header">
                <h2><img src="https://mextvmedia.sirv.com/icons/icons8-list-24.png" width="24" height="24" alt=""> Existing Packages</h2>
            </div>
            <div class="mexplay-card-body">
                <table class="mexplay-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Price</th>
                            <th>Duration</th>
                            <th>Type</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($packages)): ?>
                            <tr>
                                <td colspan="8">No subscription packages found. Create your first package above.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($packages as $package): ?>
                                <tr>
                                    <td><?php echo esc_html($package->name); ?></td>
                                    <td><?php echo esc_html($package->description); ?></td>
                                    <td>₦<?php echo esc_html(number_format($package->price, 2)); ?></td>
                                    <td>
                                        <?php 
                                            echo esc_html($package->duration) . ' ' . 
                                                 esc_html(ucfirst($package->duration_unit)) . 
                                                 ($package->duration > 1 && substr($package->duration_unit, -1) !== 's' ? 's' : '');
                                        ?>
                                    </td>
                                    <td>
                                        <span class="mexplay-badge <?php echo $package->is_trial ? 'trial' : 'active'; ?>">
                                            <?php echo $package->is_trial ? 'Free Trial' : 'Paid'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="mexplay-badge <?php echo $package->status === 'active' ? 'active' : 'inactive'; ?>">
                                            <?php echo ucfirst(esc_html($package->status)); ?>
                                        </span>
                                    </td>
                                    <td><?php echo esc_html(date('M j, Y', strtotime($package->created_at))); ?></td>
                                    <td>
                                        <button class="mexplay-button mexplay-edit-package" 
                                                data-id="<?php echo esc_attr($package->id); ?>"
                                                data-name="<?php echo esc_attr($package->name); ?>"
                                                data-description="<?php echo esc_attr($package->description); ?>"
                                                data-price="<?php echo esc_attr($package->price); ?>"
                                                data-duration="<?php echo esc_attr($package->duration); ?>"
                                                data-duration-unit="<?php echo esc_attr($package->duration_unit); ?>"
                                                data-is-trial="<?php echo esc_attr($package->is_trial); ?>"
                                                data-status="<?php echo esc_attr($package->status); ?>">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="mexplay-button danger mexplay-delete-package" data-id="<?php echo esc_attr($package->id); ?>">
                                            <img src="https://mextvmedia.sirv.com/icons/icons8-trash-24.png" width="24" height="24" alt="">
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Edit Package Modal -->
<div id="mexplay-edit-package-modal" class="mexplay-modal-overlay">
    <div class="mexplay-modal">
        <div class="mexplay-modal-header">
            <h3><img src="https://mextvmedia.sirv.com/icons/icons8-edit-24.png" width="24" height="24" alt=""> Edit Package</h3>
            <span class="mexplay-modal-close">&times;</span>
        </div>
        <div class="mexplay-modal-body">
            <form id="mexplay-edit-package-form">
                <input type="hidden" id="edit_package_id" name="edit_package_id">
                
                <div class="mexplay-form-group">
                    <label for="edit_package_name">Package Name:</label>
                    <input type="text" id="edit_package_name" name="edit_package_name" required>
                </div>
                
                <div class="mexplay-form-group">
                    <label for="edit_package_description">Description:</label>
                    <textarea id="edit_package_description" name="edit_package_description"></textarea>
                </div>
                
                <div class="mexplay-form-group">
                    <label for="edit_package_price">Price (₦):</label>
                    <input type="number" id="edit_package_price" name="edit_package_price" min="0" step="0.01" required>
                </div>
                
                <div class="mexplay-form-group">
                    <label for="edit_package_duration">Duration:</label>
                    <div style="display: flex; gap: 10px;">
                        <input type="number" id="edit_package_duration" name="edit_package_duration" min="1" required style="flex: 1;">
                        <select id="edit_package_duration_unit" name="edit_package_duration_unit" style="flex: 1;">
                            <option value="days">Days</option>
                            <option value="weeks">Weeks</option>
                            <option value="months">Months</option>
                            <option value="years">Years</option>
                        </select>
                    </div>
                </div>
                
                <div class="mexplay-form-group">
                    <label>
                        <input type="checkbox" id="edit_package_is_trial" name="edit_package_is_trial">
                        This is a free trial package
                    </label>
                </div>
                
                <div class="mexplay-form-group">
                    <label for="edit_package_status">Status:</label>
                    <select id="edit_package_status" name="edit_package_status">
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
                
                <div class="mexplay-modal-footer">
                    <button type="button" class="mexplay-button mexplay-close-modal">Cancel</button>
                    <button type="submit" class="mexplay-button primary">
                        <img src="https://mextvmedia.sirv.com/icons/icons8-save-24.png" width="24" height="24" alt=""> Update Package
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
