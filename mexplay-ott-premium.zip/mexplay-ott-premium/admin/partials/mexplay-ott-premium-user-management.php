<?php
/**
 * User management page.
 *
 * @link       https://mexplay.com
 * @since      1.0.0
 *
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/admin/partials
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Get all users with subscription data
global $wpdb;

// Prepare the user query
$users_per_page = 20;
$current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
$offset = ($current_page - 1) * $users_per_page;

$search_term = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
$search_clause = '';

if (!empty($search_term)) {
    $search_clause = $wpdb->prepare(
        "AND (u.display_name LIKE %s OR u.user_email LIKE %s OR um_phone.meta_value LIKE %s)",
        '%' . $wpdb->esc_like($search_term) . '%',
        '%' . $wpdb->esc_like($search_term) . '%',
        '%' . $wpdb->esc_like($search_term) . '%'
    );
}

// Get subscription packages for assign package dropdown
$table_packages = $wpdb->prefix . 'mexplay_subscription_packages';
$packages = $wpdb->get_results("SELECT * FROM $table_packages WHERE status = 'active' ORDER BY name ASC");

// Get users with their subscription details
$query = $wpdb->prepare("
    SELECT u.ID, u.user_login, u.display_name, u.user_email, u.user_registered,
           um_phone.meta_value as phone,
           um_suspended.meta_value as suspended,
           v.voucher_code, v.valid_from, v.valid_until, v.status as voucher_status,
           p.name as package_name, p.is_trial, p.id as package_id,
           (SELECT COUNT(*) FROM {$wpdb->prefix}mexplay_user_subscriptions WHERE user_id = u.ID) as subscriptions_count
    FROM {$wpdb->prefix}users u
    LEFT JOIN {$wpdb->prefix}usermeta um_phone ON u.ID = um_phone.user_id AND um_phone.meta_key = 'mexplay_user_phone'
    LEFT JOIN {$wpdb->prefix}usermeta um_suspended ON u.ID = um_suspended.user_id AND um_suspended.meta_key = 'mexplay_suspended'
    LEFT JOIN (
        SELECT user_id, voucher_code, valid_from, valid_until, status, package_id
        FROM {$wpdb->prefix}mexplay_vouchers
        WHERE (user_id, created_at) IN (
            SELECT user_id, MAX(created_at)
            FROM {$wpdb->prefix}mexplay_vouchers
            GROUP BY user_id
        )
    ) v ON u.ID = v.user_id
    LEFT JOIN {$wpdb->prefix}mexplay_subscription_packages p ON v.package_id = p.id
    WHERE 1=1 {$search_clause}
    ORDER BY u.user_registered DESC
    LIMIT %d OFFSET %d
", $users_per_page, $offset);

$users = $wpdb->get_results($query);

// Count total users for pagination
$count_query = "
    SELECT COUNT(DISTINCT u.ID)
    FROM {$wpdb->prefix}users u
    LEFT JOIN {$wpdb->prefix}usermeta um_phone ON u.ID = um_phone.user_id AND um_phone.meta_key = 'mexplay_user_phone'
    WHERE 1=1 {$search_clause}
";
$total_users = $wpdb->get_var($count_query);
$total_pages = ceil($total_users / $users_per_page);

?>

<div class="mexplay-admin-wrapper">
    <div class="mexplay-admin-header">
        <h1><img src="https://mextvmedia.sirv.com/icons/icons8-users-24.png" width="24" height="24" alt=""> User Management</h1>
        <p>Manage your subscribers and their subscriptions</p>
    </div>
    
    <div id="mexplay-alerts"></div>
    
    <div class="mexplay-admin-content">
        <div class="mexplay-card">
            <div class="mexplay-card-header">
                <h2><img src="https://mextvmedia.sirv.com/icons/icons8-search-24.png" width="24" height="24" alt=""> Search Users</h2>
            </div>
            <div class="mexplay-card-body">
                <form method="get" action="<?php echo esc_url(admin_url('admin.php')); ?>">
                    <input type="hidden" name="page" value="mexplay-user-management">
                    <div class="mexplay-form-group" style="display: flex; gap: 10px;">
                        <input type="text" name="s" value="<?php echo esc_attr($search_term); ?>" placeholder="Search by name, email or phone..." style="flex: 1;">
                        <button type="submit" class="mexplay-button primary">
                            <img src="https://mextvmedia.sirv.com/icons/icons8-search-24.png" width="24" height="24" alt=""> Search
                        </button>
                        <?php if (!empty($search_term)): ?>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=mexplay-user-management')); ?>" class="mexplay-button">
                                <img src="https://mextvmedia.sirv.com/icons/icons8-time-24.png" width="24" height="24" alt=""> Clear
                            </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="mexplay-card">
            <div class="mexplay-card-header">
                <h2><img src="https://mextvmedia.sirv.com/icons/icons8-users-24.png" width="24" height="24" alt=""> Subscribers</h2>
            </div>
            <div class="mexplay-card-body">
                <?php if (empty($users)): ?>
                    <p>No users found. <?php echo !empty($search_term) ? 'Try a different search term.' : ''; ?></p>
                <?php else: ?>
                    <table class="mexplay-table">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Current Package</th>
                                <th>Voucher Code</th>
                                <th>Expiry Date</th>
                                <th>Status</th>
                                <th>Registered</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td>
                                        <?php echo esc_html($user->display_name); ?>
                                        <?php if (!empty($user->suspended)): ?>
                                            <span class="mexplay-badge inactive">Suspended</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo esc_html($user->user_email); ?></td>
                                    <td><?php echo !empty($user->phone) ? esc_html($user->phone) : '-'; ?></td>
                                    <td>
                                        <?php if (!empty($user->package_name)): ?>
                                            <?php echo esc_html($user->package_name); ?>
                                            <?php if ($user->is_trial): ?>
                                                <span class="mexplay-badge trial">Free Trial</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <em>No package</em>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo !empty($user->voucher_code) ? esc_html($user->voucher_code) : '-'; ?></td>
                                    <td>
                                        <?php if (!empty($user->valid_until)): ?>
                                            <?php 
                                                $expiry_date = strtotime($user->valid_until);
                                                $now = time();
                                                $is_expired = $expiry_date < $now;
                                                echo esc_html(date('M j, Y', $expiry_date));
                                                echo $is_expired ? ' <span class="mexplay-badge inactive">Expired</span>' : '';
                                            ?>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($user->voucher_status)): ?>
                                            <span class="mexplay-badge <?php echo esc_attr($user->voucher_status); ?>">
                                                <?php echo ucfirst(esc_html($user->voucher_status)); ?>
                                            </span>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo esc_html(date('M j, Y', strtotime($user->user_registered))); ?></td>
                                    <td>
                                        <div class="mexplay-action-buttons">
                                            <button class="mexplay-button mexplay-user-action" 
                                                    data-action="edit" 
                                                    data-user-id="<?php echo esc_attr($user->ID); ?>"
                                                    data-first-name="<?php echo esc_attr(get_user_meta($user->ID, 'first_name', true)); ?>"
                                                    data-last-name="<?php echo esc_attr(get_user_meta($user->ID, 'last_name', true)); ?>"
                                                    data-email="<?php echo esc_attr($user->user_email); ?>"
                                                    data-phone="<?php echo esc_attr($user->phone); ?>">
                                                <img src="https://mextvmedia.sirv.com/icons/icons8-edit-24.png" width="24" height="24" alt="">
                                            </button>

                                            <button class="mexplay-button mexplay-user-action" 
                                                    data-action="assign" 
                                                    data-user-id="<?php echo esc_attr($user->ID); ?>"
                                                    data-username="<?php echo esc_attr($user->display_name); ?>">
                                                <img src="https://mextvmedia.sirv.com/icons/icons8-box-24.png" width="24" height="24" alt="">
                                            </button>

                                            <button class="mexplay-button <?php echo empty($user->suspended) ? 'danger' : 'success'; ?> mexplay-user-action" 
                                                    data-action="suspend" 
                                                    data-user-id="<?php echo esc_attr($user->ID); ?>"
                                                    data-suspended="<?php echo !empty($user->suspended) ? '1' : '0'; ?>">
                                                <i class="fas <?php echo empty($user->suspended) ? 'fa-ban' : 'fa-check-circle'; ?>"></i>
                                            </button>

                                            <button class="mexplay-button warning mexplay-user-action" 
                                                    data-action="reset" 
                                                    data-user-id="<?php echo esc_attr($user->ID); ?>">
                                                <img src="https://mextvmedia.sirv.com/icons/icons8-key-24.png" width="24" height="24" alt="">
                                            </button>

                                            <button class="mexplay-button danger mexplay-user-action" 
                                                    data-action="delete" 
                                                    data-user-id="<?php echo esc_attr($user->ID); ?>">
                                                <img src="https://mextvmedia.sirv.com/icons/icons8-trash-24.png" width="24" height="24" alt="">
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <?php if ($total_pages > 1): ?>
                        <div class="mexplay-pagination">
                            <?php
                                $pagination_links = paginate_links(array(
                                    'base' => add_query_arg('paged', '%#%'),
                                    'format' => '',
                                    'prev_text' => '&laquo;',
                                    'next_text' => '&raquo;',
                                    'total' => $total_pages,
                                    'current' => $current_page,
                                ));
                                echo $pagination_links;
                            ?>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Edit User Modal -->
<div id="mexplay-edit-user-modal" class="mexplay-modal-overlay">
    <div class="mexplay-modal">
        <div class="mexplay-modal-header">
            <h3><img src="https://mextvmedia.sirv.com/icons/icons8-edit-24.png" width="24" height="24" alt=""> Edit User</h3>
            <span class="mexplay-modal-close">&times;</span>
        </div>
        <div class="mexplay-modal-body">
            <form id="mexplay-edit-user-form">
                <input type="hidden" id="edit_user_id" name="edit_user_id">
                
                <div class="mexplay-form-group">
                    <label for="edit_first_name">First Name:</label>
                    <input type="text" id="edit_first_name" name="edit_first_name">
                </div>
                
                <div class="mexplay-form-group">
                    <label for="edit_last_name">Last Name:</label>
                    <input type="text" id="edit_last_name" name="edit_last_name">
                </div>
                
                <div class="mexplay-form-group">
                    <label for="edit_email">Email:</label>
                    <input type="email" id="edit_email" name="edit_email" required>
                </div>
                
                <div class="mexplay-form-group">
                    <label for="edit_phone">Phone Number:</label>
                    <input type="text" id="edit_phone" name="edit_phone">
                </div>
                
                <div class="mexplay-modal-footer">
                    <button type="button" class="mexplay-button mexplay-close-modal">Cancel</button>
                    <button type="submit" class="mexplay-button primary">
                        <img src="https://mextvmedia.sirv.com/icons/icons8-save-24.png" width="24" height="24" alt=""> Update User
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Assign Package Modal -->
<div id="mexplay-assign-package-modal" class="mexplay-modal-overlay">
    <div class="mexplay-modal">
        <div class="mexplay-modal-header">
            <h3><img src="https://mextvmedia.sirv.com/icons/icons8-box-24.png" width="24" height="24" alt=""> Assign Package</h3>
            <span class="mexplay-modal-close">&times;</span>
        </div>
        <div class="mexplay-modal-body">
            <form id="mexplay-assign-package-form">
                <input type="hidden" id="assign_user_id" name="assign_user_id">
                
                <p>Assign a subscription package to <strong id="assign_user_name"></strong>.</p>
                
                <div class="mexplay-form-group">
                    <label for="assign_package_id">Subscription Package:</label>
                    <select id="assign_package_id" name="assign_package_id" required>
                        <option value="">Select a package</option>
                        <?php foreach ($packages as $package): ?>
                            <option value="<?php echo esc_attr($package->id); ?>">
                                <?php echo esc_html($package->name); ?> 
                                (<?php echo $package->is_trial ? 'Free Trial' : '₦' . number_format($package->price, 2); ?> - 
                                <?php echo esc_html($package->duration) . ' ' . 
                                          esc_html(ucfirst($package->duration_unit)) . 
                                          ($package->duration > 1 && substr($package->duration_unit, -1) !== 's' ? 's' : ''); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="mexplay-modal-footer">
                    <button type="button" class="mexplay-button mexplay-close-modal">Cancel</button>
                    <button type="submit" class="mexplay-button primary">
                        <img src="https://mextvmedia.sirv.com/icons/icons8-checkmark-24.png" width="24" height="24" alt=""> Assign Package
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
