<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @since      1.0.0
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two hooks for
 * enqueuing the admin-specific stylesheet and JavaScript.
 *
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/admin
 */
class Mexplay_OTT_Premium_Admin {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param    string    $plugin_name       The name of this plugin.
     * @param    string    $version           The version of this plugin.
     */
    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_styles() {
        // Enqueue Google Fonts first
        wp_enqueue_style('mexplay-google-fonts-poppins', 'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap', array(), null);
        wp_enqueue_style('mexplay-google-fonts-montserrat', 'https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap', array(), null);
        
        // Add Font Awesome
        wp_enqueue_style('fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css', array(), '5.15.4', 'all');
        
        // Add our plugin CSS with high priority and time() to prevent caching
        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/mexplay-ott-premium-admin.css', array(), time(), 'all');
        
        // Add inline CSS to ensure our styles have higher specificity
        $custom_css = "
            .mexplay-admin-wrapper,
            .mexplay-admin-wrapper * {
                font-family: 'Poppins', sans-serif !important;
            }
            
            .mexplay-admin-header h1,
            .mexplay-admin-wrapper h2,
            .mexplay-admin-wrapper h3,
            .mexplay-admin-wrapper h4,
            .mexplay-admin-wrapper h5,
            .mexplay-admin-wrapper h6 {
                font-family: 'Montserrat', sans-serif !important;
            }
            
            #adminmenu .toplevel_page_mexplay-ott-premium .wp-menu-image {
                background-color: var(--mexplay-primary-color) !important;
            }
        ";
        wp_add_inline_style($this->plugin_name, $custom_css);
    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts() {
        wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/mexplay-ott-premium-admin.js', array('jquery'), $this->version, false);
        
        // Pass admin ajax URL to JavaScript
        wp_localize_script($this->plugin_name, 'mexplay_admin_vars', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('mexplay-admin-nonce')
        ));
    }

    /**
     * Add menu items to the WordPress admin area.
     *
     * @since    1.0.0
     */
    public function add_admin_menu() {
        // Main menu item
        add_menu_page(
            __('MexPlay OTT Premium', 'mexplay-ott-premium'),
            __('MexPlay OTT', 'mexplay-ott-premium'),
            'manage_options',
            'mexplay-ott-premium',
            array($this, 'display_admin_dashboard'),
            'dashicons-playlist-video',
            26
        );
        
        // Dashboard submenu
        add_submenu_page(
            'mexplay-ott-premium',
            __('Dashboard', 'mexplay-ott-premium'),
            __('Dashboard', 'mexplay-ott-premium'),
            'manage_options',
            'mexplay-ott-premium',
            array($this, 'display_admin_dashboard')
        );
        
        // Subscription Packages submenu
        add_submenu_page(
            'mexplay-ott-premium',
            __('Subscription Packages', 'mexplay-ott-premium'),
            __('Subscription Packages', 'mexplay-ott-premium'),
            'manage_options',
            'mexplay-subscription-packages',
            array($this, 'display_subscription_packages')
        );
        
        // User Management submenu
        add_submenu_page(
            'mexplay-ott-premium',
            __('User Management', 'mexplay-ott-premium'),
            __('User Management', 'mexplay-ott-premium'),
            'manage_options',
            'mexplay-user-management',
            array($this, 'display_user_management')
        );
        
        // Email Templates submenu
        add_submenu_page(
            'mexplay-ott-premium',
            __('Email Templates', 'mexplay-ott-premium'),
            __('Email Templates', 'mexplay-ott-premium'),
            'manage_options',
            'mexplay-email-templates',
            array($this, 'display_email_templates')
        );
        
        // Paystack Settings submenu
        add_submenu_page(
            'mexplay-ott-premium',
            __('Paystack Settings', 'mexplay-ott-premium'),
            __('Paystack Settings', 'mexplay-ott-premium'),
            'manage_options',
            'mexplay-paystack-settings',
            array($this, 'display_paystack_settings')
        );
    }
    
    /**
     * Display admin dashboard page.
     *
     * @since    1.0.0
     */
    public function display_admin_dashboard() {
        require_once plugin_dir_path(__FILE__) . 'partials/mexplay-ott-premium-admin-dashboard.php';
    }
    
    /**
     * Display subscription packages page.
     *
     * @since    1.0.0
     */
    public function display_subscription_packages() {
        require_once plugin_dir_path(__FILE__) . 'partials/mexplay-ott-premium-subscription-packages.php';
    }
    
    /**
     * Display user management page.
     *
     * @since    1.0.0
     */
    public function display_user_management() {
        require_once plugin_dir_path(__FILE__) . 'partials/mexplay-ott-premium-user-management.php';
    }
    
    /**
     * Display email templates page.
     *
     * @since    1.0.0
     */
    public function display_email_templates() {
        require_once plugin_dir_path(__FILE__) . 'partials/mexplay-ott-premium-email-templates.php';
    }
    
    /**
     * Display Paystack settings page.
     *
     * @since    1.0.0
     */
    public function display_paystack_settings() {
        require_once plugin_dir_path(__FILE__) . 'partials/mexplay-ott-premium-paystack-settings.php';
    }
    
    /**
     * Register Paystack webhook endpoint.
     *
     * @since    1.0.0
     */
    public function register_paystack_webhook_endpoint() {
        register_rest_route('mexplay/v1', '/paystack-webhook', array(
            'methods' => 'POST',
            'callback' => array($this, 'process_paystack_webhook'),
            'permission_callback' => '__return_true',
        ));
    }
    
    /**
     * Process Paystack webhook data.
     *
     * @since    1.0.0
     * @param    WP_REST_Request $request The request object.
     * @return   WP_REST_Response
     */
    public function process_paystack_webhook($request) {
        $paystack_instance = new Mexplay_OTT_Premium_Paystack();
        $result = $paystack_instance->process_webhook($request);
        
        if ($result['success']) {
            return new WP_REST_Response(array('status' => 'success'), 200);
        } else {
            return new WP_REST_Response(array('status' => 'error', 'message' => $result['message']), 400);
        }
    }
    
    /**
     * AJAX handler for adding subscription package.
     *
     * @since    1.0.0
     */
    public function add_subscription_package() {
        // Check nonce for security
        check_ajax_referer('mexplay-admin-nonce', 'nonce');
        
        // Check if user has permission
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'You do not have permission to perform this action.'));
            return;
        }
        
        // Get and sanitize form data
        $name = sanitize_text_field($_POST['name']);
        $description = sanitize_textarea_field($_POST['description']);
        $price = floatval($_POST['price']);
        $duration = intval($_POST['duration']);
        $duration_unit = sanitize_text_field($_POST['duration_unit']);
        $is_trial = isset($_POST['is_trial']) ? 1 : 0;
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'mexplay_subscription_packages';
        
        $result = $wpdb->insert(
            $table_name,
            array(
                'name' => $name,
                'description' => $description,
                'price' => $price,
                'duration' => $duration,
                'duration_unit' => $duration_unit,
                'is_trial' => $is_trial,
                'status' => 'active',
                'created_at' => current_time('mysql')
            ),
            array('%s', '%s', '%f', '%d', '%s', '%d', '%s', '%s')
        );
        
        if ($result) {
            wp_send_json_success(array('message' => 'Subscription package added successfully.'));
        } else {
            wp_send_json_error(array('message' => 'Failed to add subscription package.'));
        }
    }
    
    /**
     * AJAX handler for editing subscription package.
     *
     * @since    1.0.0
     */
    public function edit_subscription_package() {
        // Check nonce for security
        check_ajax_referer('mexplay-admin-nonce', 'nonce');
        
        // Check if user has permission
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'You do not have permission to perform this action.'));
            return;
        }
        
        // Get and sanitize form data
        $id = intval($_POST['id']);
        $name = sanitize_text_field($_POST['name']);
        $description = sanitize_textarea_field($_POST['description']);
        $price = floatval($_POST['price']);
        $duration = intval($_POST['duration']);
        $duration_unit = sanitize_text_field($_POST['duration_unit']);
        $is_trial = isset($_POST['is_trial']) ? 1 : 0;
        $status = sanitize_text_field($_POST['status']);
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'mexplay_subscription_packages';
        
        $result = $wpdb->update(
            $table_name,
            array(
                'name' => $name,
                'description' => $description,
                'price' => $price,
                'duration' => $duration,
                'duration_unit' => $duration_unit,
                'is_trial' => $is_trial,
                'status' => $status
            ),
            array('id' => $id),
            array('%s', '%s', '%f', '%d', '%s', '%d', '%s'),
            array('%d')
        );
        
        if ($result !== false) {
            wp_send_json_success(array('message' => 'Subscription package updated successfully.'));
        } else {
            wp_send_json_error(array('message' => 'Failed to update subscription package.'));
        }
    }
    
    /**
     * AJAX handler for deleting subscription package.
     *
     * @since    1.0.0
     */
    public function delete_subscription_package() {
        // Check nonce for security
        check_ajax_referer('mexplay-admin-nonce', 'nonce');
        
        // Check if user has permission
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'You do not have permission to perform this action.'));
            return;
        }
        
        // Get and sanitize package ID
        $id = intval($_POST['id']);
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'mexplay_subscription_packages';
        
        $result = $wpdb->delete(
            $table_name,
            array('id' => $id),
            array('%d')
        );
        
        if ($result) {
            wp_send_json_success(array('message' => 'Subscription package deleted successfully.'));
        } else {
            wp_send_json_error(array('message' => 'Failed to delete subscription package.'));
        }
    }
    
    /**
     * AJAX handler for managing users.
     *
     * @since    1.0.0
     */
    public function manage_user() {
        // Check nonce for security
        check_ajax_referer('mexplay-admin-nonce', 'nonce');
        
        // Check if user has permission
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'You do not have permission to perform this action.'));
            return;
        }
        
        $action = sanitize_text_field($_POST['user_action']);
        $user_id = intval($_POST['user_id']);
        
        if (!$user_id) {
            wp_send_json_error(array('message' => 'Invalid user ID.'));
            return;
        }
        
        $user_manager = new Mexplay_OTT_Premium_User();
        
        switch ($action) {
            case 'edit':
                $first_name = sanitize_text_field($_POST['first_name']);
                $last_name = sanitize_text_field($_POST['last_name']);
                $email = sanitize_email($_POST['email']);
                $phone = sanitize_text_field($_POST['phone']);
                
                $update_result = $user_manager->update_user_data($user_id, $first_name, $last_name, $email, $phone);
                
                if ($update_result['success']) {
                    wp_send_json_success(array('message' => 'User updated successfully.'));
                } else {
                    wp_send_json_error(array('message' => $update_result['message']));
                }
                break;
                
            case 'assign_package':
                $package_id = intval($_POST['package_id']);
                
                $result = $user_manager->assign_package_to_user($user_id, $package_id);
                
                if ($result['success']) {
                    wp_send_json_success(array('message' => 'Package assigned successfully.'));
                } else {
                    wp_send_json_error(array('message' => $result['message']));
                }
                break;
                
            case 'suspend':
                $suspended = intval($_POST['suspended']);
                
                // Update user meta to mark as suspended
                update_user_meta($user_id, 'mexplay_suspended', $suspended);
                
                if ($suspended) {
                    wp_send_json_success(array('message' => 'User suspended successfully.'));
                } else {
                    wp_send_json_success(array('message' => 'User unsuspended successfully.'));
                }
                break;
                
            case 'reset_password':
                $new_password = wp_generate_password(12, true, false);
                wp_set_password($new_password, $user_id);
                
                $user_data = get_userdata($user_id);
                $email_manager = new Mexplay_OTT_Premium_Email();
                $email_manager->send_password_reset_email($user_data->user_email, $user_data->display_name, $new_password);
                
                wp_send_json_success(array('message' => 'Password reset and sent to user.'));
                break;
                
            case 'delete':
                if (wp_delete_user($user_id)) {
                    wp_send_json_success(array('message' => 'User deleted successfully.'));
                } else {
                    wp_send_json_error(array('message' => 'Failed to delete user.'));
                }
                break;
                
            default:
                wp_send_json_error(array('message' => 'Invalid action.'));
                break;
        }
    }
    
    /**
     * AJAX handler for testing email.
     *
     * @since    1.0.0
     */
    public function test_email() {
        // Check nonce for security
        check_ajax_referer('mexplay-admin-nonce', 'nonce');
        
        // Check if user has permission
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'You do not have permission to perform this action.'));
            return;
        }
        
        $to = sanitize_email($_POST['test_email']);
        
        if (!is_email($to)) {
            wp_send_json_error(array('message' => 'Invalid email address.'));
            return;
        }
        
        $subject = 'MexPlay OTT Premium - Test Email';
        $header = get_option('mexplay_email_template_header');
        $footer = get_option('mexplay_email_template_footer');
        $body = "This is a test email from your MexPlay OTT Premium plugin. If you received this email, your email settings are configured correctly.";
        
        $message = $header . '<div style="padding: 20px;">' . $body . '</div>' . $footer;
        
        $email_manager = new Mexplay_OTT_Premium_Email();
        $result = $email_manager->send_email($to, $subject, $message);
        
        if ($result) {
            wp_send_json_success(array('message' => 'Test email sent successfully.'));
        } else {
            wp_send_json_error(array('message' => 'Failed to send test email. Please check your SMTP settings.'));
        }
    }
    
    /**
     * AJAX handler for saving email template.
     *
     * @since    1.0.0
     */
    public function save_email_template() {
        // Check nonce for security
        check_ajax_referer('mexplay-admin-nonce', 'nonce');
        
        // Check if user has permission
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'You do not have permission to perform this action.'));
            return;
        }
        
        // Get and sanitize form data
        $header = wp_kses_post($_POST['email_header']);
        $footer = wp_kses_post($_POST['email_footer']);
        $welcome_subject = sanitize_text_field($_POST['welcome_subject']);
        $welcome_body = wp_kses_post($_POST['welcome_body']);
        $expiry_subject = sanitize_text_field($_POST['expiry_subject']);
        $expiry_body = wp_kses_post($_POST['expiry_body']);
        
        // SMTP settings
        $smtp_host = sanitize_text_field($_POST['smtp_host']);
        $smtp_port = intval($_POST['smtp_port']);
        $smtp_username = sanitize_text_field($_POST['smtp_username']);
        $smtp_password = $_POST['smtp_password']; // Note: We're not sanitizing password to preserve special characters
        $smtp_from_email = sanitize_email($_POST['smtp_from_email']);
        $smtp_from_name = sanitize_text_field($_POST['smtp_from_name']);
        $smtp_encryption = sanitize_text_field($_POST['smtp_encryption']);
        
        // Update options
        update_option('mexplay_email_template_header', $header);
        update_option('mexplay_email_template_footer', $footer);
        update_option('mexplay_welcome_email_subject', $welcome_subject);
        update_option('mexplay_welcome_email_body', $welcome_body);
        update_option('mexplay_expiry_email_subject', $expiry_subject);
        update_option('mexplay_expiry_email_body', $expiry_body);
        
        update_option('mexplay_smtp_host', $smtp_host);
        update_option('mexplay_smtp_port', $smtp_port);
        update_option('mexplay_smtp_username', $smtp_username);
        update_option('mexplay_smtp_password', $smtp_password);
        update_option('mexplay_smtp_from_email', $smtp_from_email);
        update_option('mexplay_smtp_from_name', $smtp_from_name);
        update_option('mexplay_smtp_encryption', $smtp_encryption);
        
        wp_send_json_success(array('message' => 'Email templates and settings saved successfully.'));
    }
    
    /**
     * AJAX handler for saving Paystack settings.
     *
     * @since    1.0.0
     */
    public function save_paystack_settings() {
        // Check nonce for security
        check_ajax_referer('mexplay-admin-nonce', 'nonce');
        
        // Check if user has permission
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'You do not have permission to perform this action.'));
            return;
        }
        
        // Get and sanitize form data
        $test_mode = isset($_POST['test_mode']) ? 'yes' : 'no';
        $test_secret_key = sanitize_text_field($_POST['test_secret_key']);
        $test_public_key = sanitize_text_field($_POST['test_public_key']);
        $live_secret_key = sanitize_text_field($_POST['live_secret_key']);
        $live_public_key = sanitize_text_field($_POST['live_public_key']);
        
        // Update options
        update_option('mexplay_paystack_test_mode', $test_mode);
        update_option('mexplay_paystack_test_secret_key', $test_secret_key);
        update_option('mexplay_paystack_test_public_key', $test_public_key);
        update_option('mexplay_paystack_live_secret_key', $live_secret_key);
        update_option('mexplay_paystack_live_public_key', $live_public_key);
        
        wp_send_json_success(array('message' => 'Paystack settings saved successfully.'));
    }
}
