(function( $ ) {
    'use strict';

    /**
     * All admin functionality for the plugin.
     */
    $(document).ready(function() {
        
        // Initialize tabs
        $('.mexplay-tab').on('click', function() {
            const tabId = $(this).data('tab');
            
            $('.mexplay-tab').removeClass('active');
            $(this).addClass('active');
            
            $('.mexplay-tab-content').removeClass('active');
            $('#' + tabId).addClass('active');
        });
        
        // Initialize modals
        $('.mexplay-open-modal').on('click', function() {
            const modalId = $(this).data('modal');
            $('#' + modalId).show();
        });
        
        $('.mexplay-modal-close, .mexplay-close-modal').on('click', function() {
            $('.mexplay-modal-overlay').hide();
        });
        
        // Close modal when clicking outside of it
        $('.mexplay-modal-overlay').on('click', function(e) {
            if ($(e.target).hasClass('mexplay-modal-overlay')) {
                $(this).hide();
            }
        });
        
        // Add subscription package
        $('#mexplay-add-package-form').on('submit', function(e) {
            e.preventDefault();
            
            const form = $(this);
            const submitBtn = form.find('button[type="submit"]');
            submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Processing...');
            
            $.ajax({
                url: mexplay_admin_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'mexplay_add_subscription_package',
                    name: form.find('#package_name').val(),
                    description: form.find('#package_description').val(),
                    price: form.find('#package_price').val(),
                    duration: form.find('#package_duration').val(),
                    duration_unit: form.find('#package_duration_unit').val(),
                    is_trial: form.find('#package_is_trial').is(':checked') ? 1 : 0,
                    nonce: mexplay_admin_vars.nonce
                },
                success: function(response) {
                    if (response.success) {
                        showAlert('success', response.data.message);
                        form[0].reset();
                        setTimeout(function() {
                            location.reload();
                        }, 1500);
                    } else {
                        showAlert('error', response.data.message);
                    }
                    submitBtn.prop('disabled', false).html('<i class="fas fa-plus"></i> Add Package');
                },
                error: function() {
                    showAlert('error', 'An unexpected error occurred. Please try again.');
                    submitBtn.prop('disabled', false).html('<i class="fas fa-plus"></i> Add Package');
                }
            });
        });
        
        // Edit subscription package
        $('.mexplay-edit-package').on('click', function() {
            const id = $(this).data('id');
            const name = $(this).data('name');
            const description = $(this).data('description');
            const price = $(this).data('price');
            const duration = $(this).data('duration');
            const durationUnit = $(this).data('duration-unit');
            const isTrial = $(this).data('is-trial');
            const status = $(this).data('status');
            
            const modal = $('#mexplay-edit-package-modal');
            
            modal.find('#edit_package_id').val(id);
            modal.find('#edit_package_name').val(name);
            modal.find('#edit_package_description').val(description);
            modal.find('#edit_package_price').val(price);
            modal.find('#edit_package_duration').val(duration);
            modal.find('#edit_package_duration_unit').val(durationUnit);
            modal.find('#edit_package_is_trial').prop('checked', isTrial === 1);
            modal.find('#edit_package_status').val(status);
            
            modal.show();
        });
        
        // Handle edit package form submission
        $('#mexplay-edit-package-form').on('submit', function(e) {
            e.preventDefault();
            
            const form = $(this);
            const submitBtn = form.find('button[type="submit"]');
            submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Updating...');
            
            $.ajax({
                url: mexplay_admin_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'mexplay_edit_subscription_package',
                    id: form.find('#edit_package_id').val(),
                    name: form.find('#edit_package_name').val(),
                    description: form.find('#edit_package_description').val(),
                    price: form.find('#edit_package_price').val(),
                    duration: form.find('#edit_package_duration').val(),
                    duration_unit: form.find('#edit_package_duration_unit').val(),
                    is_trial: form.find('#edit_package_is_trial').is(':checked') ? 1 : 0,
                    status: form.find('#edit_package_status').val(),
                    nonce: mexplay_admin_vars.nonce
                },
                success: function(response) {
                    if (response.success) {
                        showAlert('success', response.data.message);
                        setTimeout(function() {
                            location.reload();
                        }, 1500);
                    } else {
                        showAlert('error', response.data.message);
                    }
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save"></i> Update Package');
                },
                error: function() {
                    showAlert('error', 'An unexpected error occurred. Please try again.');
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save"></i> Update Package');
                }
            });
        });
        
        // Delete subscription package
        $('.mexplay-delete-package').on('click', function() {
            if (confirm('Are you sure you want to delete this package? This action cannot be undone.')) {
                const id = $(this).data('id');
                const row = $(this).closest('tr');
                
                $.ajax({
                    url: mexplay_admin_vars.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'mexplay_delete_subscription_package',
                        id: id,
                        nonce: mexplay_admin_vars.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            showAlert('success', response.data.message);
                            row.fadeOut(400, function() {
                                $(this).remove();
                            });
                        } else {
                            showAlert('error', response.data.message);
                        }
                    },
                    error: function() {
                        showAlert('error', 'An unexpected error occurred. Please try again.');
                    }
                });
            }
        });
        
        // User management actions
        $('.mexplay-user-action').on('click', function() {
            const action = $(this).data('action');
            const userId = $(this).data('user-id');
            
            if (action === 'edit') {
                // Populate edit user modal
                const modal = $('#mexplay-edit-user-modal');
                
                modal.find('#edit_user_id').val(userId);
                modal.find('#edit_first_name').val($(this).data('first-name'));
                modal.find('#edit_last_name').val($(this).data('last-name'));
                modal.find('#edit_email').val($(this).data('email'));
                modal.find('#edit_phone').val($(this).data('phone'));
                
                modal.show();
            } else if (action === 'assign') {
                // Populate assign package modal
                const modal = $('#mexplay-assign-package-modal');
                
                modal.find('#assign_user_id').val(userId);
                modal.find('#assign_user_name').text($(this).data('username'));
                
                modal.show();
            } else if (action === 'suspend') {
                const suspended = $(this).data('suspended');
                const confirmMessage = suspended ? 'Are you sure you want to unsuspend this user?' : 'Are you sure you want to suspend this user?';
                
                if (confirm(confirmMessage)) {
                    $.ajax({
                        url: mexplay_admin_vars.ajax_url,
                        type: 'POST',
                        data: {
                            action: 'mexplay_manage_user',
                            user_action: 'suspend',
                            user_id: userId,
                            suspended: suspended ? 0 : 1,
                            nonce: mexplay_admin_vars.nonce
                        },
                        success: function(response) {
                            if (response.success) {
                                showAlert('success', response.data.message);
                                setTimeout(function() {
                                    location.reload();
                                }, 1500);
                            } else {
                                showAlert('error', response.data.message);
                            }
                        },
                        error: function() {
                            showAlert('error', 'An unexpected error occurred. Please try again.');
                        }
                    });
                }
            } else if (action === 'reset') {
                if (confirm('Are you sure you want to reset this user\'s password? A new password will be generated and sent to the user.')) {
                    $.ajax({
                        url: mexplay_admin_vars.ajax_url,
                        type: 'POST',
                        data: {
                            action: 'mexplay_manage_user',
                            user_action: 'reset_password',
                            user_id: userId,
                            nonce: mexplay_admin_vars.nonce
                        },
                        success: function(response) {
                            if (response.success) {
                                showAlert('success', response.data.message);
                            } else {
                                showAlert('error', response.data.message);
                            }
                        },
                        error: function() {
                            showAlert('error', 'An unexpected error occurred. Please try again.');
                        }
                    });
                }
            } else if (action === 'delete') {
                if (confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
                    $.ajax({
                        url: mexplay_admin_vars.ajax_url,
                        type: 'POST',
                        data: {
                            action: 'mexplay_manage_user',
                            user_action: 'delete',
                            user_id: userId,
                            nonce: mexplay_admin_vars.nonce
                        },
                        success: function(response) {
                            if (response.success) {
                                showAlert('success', response.data.message);
                                setTimeout(function() {
                                    location.reload();
                                }, 1500);
                            } else {
                                showAlert('error', response.data.message);
                            }
                        },
                        error: function() {
                            showAlert('error', 'An unexpected error occurred. Please try again.');
                        }
                    });
                }
            }
        });
        
        // Edit user form submission
        $('#mexplay-edit-user-form').on('submit', function(e) {
            e.preventDefault();
            
            const form = $(this);
            const submitBtn = form.find('button[type="submit"]');
            submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Updating...');
            
            $.ajax({
                url: mexplay_admin_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'mexplay_manage_user',
                    user_action: 'edit',
                    user_id: form.find('#edit_user_id').val(),
                    first_name: form.find('#edit_first_name').val(),
                    last_name: form.find('#edit_last_name').val(),
                    email: form.find('#edit_email').val(),
                    phone: form.find('#edit_phone').val(),
                    nonce: mexplay_admin_vars.nonce
                },
                success: function(response) {
                    if (response.success) {
                        showAlert('success', response.data.message);
                        setTimeout(function() {
                            location.reload();
                        }, 1500);
                    } else {
                        showAlert('error', response.data.message);
                    }
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save"></i> Update User');
                },
                error: function() {
                    showAlert('error', 'An unexpected error occurred. Please try again.');
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save"></i> Update User');
                }
            });
        });
        
        // Assign package form submission
        $('#mexplay-assign-package-form').on('submit', function(e) {
            e.preventDefault();
            
            const form = $(this);
            const submitBtn = form.find('button[type="submit"]');
            submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Assigning...');
            
            $.ajax({
                url: mexplay_admin_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'mexplay_manage_user',
                    user_action: 'assign_package',
                    user_id: form.find('#assign_user_id').val(),
                    package_id: form.find('#assign_package_id').val(),
                    nonce: mexplay_admin_vars.nonce
                },
                success: function(response) {
                    if (response.success) {
                        showAlert('success', response.data.message);
                        setTimeout(function() {
                            location.reload();
                        }, 1500);
                    } else {
                        showAlert('error', response.data.message);
                    }
                    submitBtn.prop('disabled', false).html('<i class="fas fa-check"></i> Assign Package');
                },
                error: function() {
                    showAlert('error', 'An unexpected error occurred. Please try again.');
                    submitBtn.prop('disabled', false).html('<i class="fas fa-check"></i> Assign Package');
                }
            });
        });
        
        // Email templates form submission
        $('#mexplay-email-templates-form').on('submit', function(e) {
            e.preventDefault();
            
            const form = $(this);
            const submitBtn = form.find('button[type="submit"]');
            submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Saving...');
            
            $.ajax({
                url: mexplay_admin_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'mexplay_save_email_template',
                    email_header: form.find('#email_header').val(),
                    email_footer: form.find('#email_footer').val(),
                    welcome_subject: form.find('#welcome_subject').val(),
                    welcome_body: form.find('#welcome_body').val(),
                    expiry_subject: form.find('#expiry_subject').val(),
                    expiry_body: form.find('#expiry_body').val(),
                    smtp_host: form.find('#smtp_host').val(),
                    smtp_port: form.find('#smtp_port').val(),
                    smtp_username: form.find('#smtp_username').val(),
                    smtp_password: form.find('#smtp_password').val(),
                    smtp_from_email: form.find('#smtp_from_email').val(),
                    smtp_from_name: form.find('#smtp_from_name').val(),
                    smtp_encryption: form.find('#smtp_encryption').val(),
                    nonce: mexplay_admin_vars.nonce
                },
                success: function(response) {
                    if (response.success) {
                        showAlert('success', response.data.message);
                    } else {
                        showAlert('error', response.data.message);
                    }
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save"></i> Save Settings');
                },
                error: function() {
                    showAlert('error', 'An unexpected error occurred. Please try again.');
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save"></i> Save Settings');
                }
            });
        });
        
        // Test email
        $('#mexplay-test-email-btn').on('click', function() {
            const testEmail = $('#test_email').val();
            
            if (!testEmail) {
                showAlert('error', 'Please enter an email address for testing.');
                return;
            }
            
            const button = $(this);
            button.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Sending...');
            
            $.ajax({
                url: mexplay_admin_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'mexplay_test_email',
                    test_email: testEmail,
                    nonce: mexplay_admin_vars.nonce
                },
                success: function(response) {
                    if (response.success) {
                        showAlert('success', response.data.message);
                    } else {
                        showAlert('error', response.data.message);
                    }
                    button.prop('disabled', false).html('<i class="fas fa-paper-plane"></i> Send Test Email');
                },
                error: function() {
                    showAlert('error', 'An unexpected error occurred. Please try again.');
                    button.prop('disabled', false).html('<i class="fas fa-paper-plane"></i> Send Test Email');
                }
            });
        });
        
        // Paystack settings form submission
        $('#mexplay-paystack-settings-form').on('submit', function(e) {
            e.preventDefault();
            
            const form = $(this);
            const submitBtn = form.find('button[type="submit"]');
            submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Saving...');
            
            $.ajax({
                url: mexplay_admin_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'mexplay_save_paystack_settings',
                    test_mode: form.find('#test_mode').is(':checked') ? 'yes' : 'no',
                    test_secret_key: form.find('#test_secret_key').val(),
                    test_public_key: form.find('#test_public_key').val(),
                    live_secret_key: form.find('#live_secret_key').val(),
                    live_public_key: form.find('#live_public_key').val(),
                    nonce: mexplay_admin_vars.nonce
                },
                success: function(response) {
                    if (response.success) {
                        showAlert('success', response.data.message);
                    } else {
                        showAlert('error', response.data.message);
                    }
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save"></i> Save Settings');
                },
                error: function() {
                    showAlert('error', 'An unexpected error occurred. Please try again.');
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save"></i> Save Settings');
                }
            });
        });
        
        // Toggle password visibility
        $('.mexplay-toggle-password').on('click', function() {
            const input = $($(this).data('target'));
            const icon = $(this).find('i');
            
            if (input.attr('type') === 'password') {
                input.attr('type', 'text');
                icon.removeClass('fa-eye').addClass('fa-eye-slash');
            } else {
                input.attr('type', 'password');
                icon.removeClass('fa-eye-slash').addClass('fa-eye');
            }
        });
        
        // Helper function to show alerts
        function showAlert(type, message) {
            const alertBox = $('<div class="mexplay-alert ' + type + ' slide-in">' + message + '</div>');
            $('#mexplay-alerts').append(alertBox);
            
            setTimeout(function() {
                alertBox.fadeOut(400, function() {
                    $(this).remove();
                });
            }, 3000);
        }
    });

})( jQuery );
