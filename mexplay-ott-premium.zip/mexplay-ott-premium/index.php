<?php
/**
 * MexPlay OTT Premium Plugin Demo
 *
 * This is a demo page for the MexPlay OTT Premium WordPress plugin.
 * In a real WordPress installation, the plugin would be installed and activated through the WordPress admin dashboard.
 */

// Simulate WordPress environment variables
define('ABSPATH', __DIR__ . '/');
define('WP_CONTENT_DIR', __DIR__ . '/');
define('WP_PLUGIN_DIR', __DIR__ . '/');
define('MEXPLAY_OTT_PREMIUM_PLUGIN_DIR', __DIR__ . '/');

// Plugin Information
$plugin_name = 'MexPlay OTT Premium';
$version = '1.0.0';
$author = 'MexTech Limited';
$website = 'https://mextvmedia.com.ng';

// Available shortcodes
$shortcodes = array(
    '[mexplay_login]' => 'Login Form',
    '[mexplay_register]' => 'Registration Form',
    '[mexplay_subscription]' => 'Subscription Packages',
    '[mexplay_dashboard]' => 'User Dashboard'
);

// Main plugin file
$main_file = 'mexplay-ott-premium.php';

// Plugin structure
$plugin_structure = array(
    'admin/' => 'Admin dashboard and settings',
    'includes/' => 'Core plugin functionality',
    'public/' => 'Public-facing components'
);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $plugin_name; ?> Demo</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            margin: 0;
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 1000px;
            margin: 0 auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        header {
            background-color: #4e8457;
            color: white;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 30px;
        }
        h1, h2, h3 {
            color: #4e8457;
        }
        header h1 {
            color: white;
            margin: 0;
        }
        .accent {
            color: #d96e28;
        }
        .button {
            display: inline-block;
            background-color: #4e8457;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            margin-right: 10px;
            margin-bottom: 10px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        .button:hover {
            background-color: #3a6343;
        }
        .button.accent {
            background-color: #d96e28;
            color: white;
        }
        .button.accent:hover {
            background-color: #b15621;
        }
        .feature-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }
        .feature-card {
            border: 1px solid #e0e0e0;
            border-radius: 5px;
            padding: 20px;
            background-color: #fafafa;
            transition: all 0.3s ease;
        }
        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        code {
            background-color: #f4f4f4;
            padding: 2px 5px;
            border-radius: 3px;
            font-family: 'Courier New', Courier, monospace;
        }
        .shortcode-list, .structure-list {
            list-style-type: none;
            padding: 0;
        }
        .shortcode-list li, .structure-list li {
            padding: 10px;
            margin-bottom: 10px;
            background-color: #f9f9f9;
            border-left: 3px solid #4e8457;
            border-radius: 3px;
        }
        footer {
            margin-top: 30px;
            text-align: center;
            color: #666;
            font-size: 14px;
        }
        .logo {
            font-size: 24px;
            font-weight: bold;
            display: flex;
            align-items: center;
        }
        .logo span {
            color: #d96e28;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <div class="logo">
                <span>Mex</span>Play OTT Premium
            </div>
            <p>A premium WordPress plugin for OTT subscription management with Paystack integration</p>
        </header>

        <section>
            <h2>Plugin Overview</h2>
            <p>
                The <span class="accent">MexPlay OTT Premium</span> plugin provides a complete solution for managing premium content subscriptions.
                With features like Paystack payment integration, voucher-based membership, and custom user dashboards, this plugin
                offers everything needed for a premium OTT (Over-The-Top) platform.
            </p>
            
            <div class="feature-list">
                <div class="feature-card">
                    <h3>🔐 Content Restriction</h3>
                    <p>Control access to premium content based on user subscription status. Only subscribers with valid memberships can access restricted content.</p>
                </div>
                
                <div class="feature-card">
                    <h3>💳 Paystack Integration</h3>
                    <p>Process payments securely using the Paystack payment gateway. Handle subscriptions, renewals, and payment verification effortlessly.</p>
                </div>
                
                <div class="feature-card">
                    <h3>🎟︄1�7 Voucher System</h3>
                    <p>Generate unique voucher codes for subscriptions. Users can use these vouchers to access premium content without re-entering payment details.</p>
                </div>
                
                <div class="feature-card">
                    <h3>👤 User Management</h3>
                    <p>Comprehensive user management system with subscription tracking, activity logs, and account management features.</p>
                </div>
                
                <div class="feature-card">
                    <h3>📧 Email Notifications</h3>
                    <p>Automated email system for welcome messages, subscription reminders, and other important notifications to keep users engaged.</p>
                </div>
                
                <div class="feature-card">
                    <h3>📱 Responsive Design</h3>
                    <p>All user interfaces are designed to work flawlessly on both desktop and mobile devices, providing a seamless experience.</p>
                </div>
                
                <div class="feature-card">
                    <h3>🗃︄1�7 Database Integration</h3>
                    <p>Fully integrated with a robust database system for storing subscription packages, user data, vouchers, and activity logs.</p>
                </div>
            </div>
        </section>

        <section>
            <h2>Available Shortcodes</h2>
            <p>The plugin provides the following shortcodes for easy integration into your WordPress pages:</p>
            
            <ul class="shortcode-list">
                <?php foreach ($shortcodes as $code => $description): ?>
                <li><code><?php echo $code; ?></code> - <?php echo $description; ?></li>
                <?php endforeach; ?>
            </ul>
        </section>

        <section>
            <h2>Plugin Structure</h2>
            <p>The plugin follows WordPress best practices with a well-organized structure:</p>
            
            <ul class="structure-list">
                <?php foreach ($plugin_structure as $directory => $description): ?>
                <li><strong><?php echo $directory; ?></strong> - <?php echo $description; ?></li>
                <?php endforeach; ?>
            </ul>
        </section>

        <section>
            <h2>Installation in WordPress</h2>
            <p>
                In a real WordPress environment, you would install this plugin by uploading the ZIP file through the
                WordPress plugin installer or by extracting it to the <code>wp-content/plugins/</code> directory.
            </p>
            <p>
                After installation, activate the plugin from the WordPress dashboard and configure it through the
                provided admin panel.
            </p>
            <div>
                <a href="mexplay-ott-premium.zip" class="button accent" download>Download Plugin ZIP</a>
                <a href="https://mexplay.com" class="button">Visit Website</a>
            </div>
        </section>

        <footer>
            <p>&copy; <?php echo date('Y'); ?> <?php echo $author; ?>. All rights reserved.</p>
            <p>Version: <?php echo $version; ?></p>
        </footer>
    </div>
</body>
</html>