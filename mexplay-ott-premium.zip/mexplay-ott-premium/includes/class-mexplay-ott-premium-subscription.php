<?php
/**
 * Subscription management.
 *
 * @link       https://mexplay.com
 * @since      1.0.0
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/includes
 */

/**
 * Subscription management.
 *
 * This class handles subscription creation, management, and renewal.
 *
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/includes
 */
class Mexplay_OTT_Premium_Subscription {

    /**
     * Create a free trial subscription.
     *
     * @since    1.0.0
     * @param    int      $user_id       The user ID.
     * @param    int      $package_id    The subscription package ID.
     * @return   array    Creation result with subscription details.
     */
    public function create_free_trial_subscription($user_id, $package_id) {
        global $wpdb;
        
        // Check if package exists and is a trial package
        $table_packages = $wpdb->prefix . 'mexplay_subscription_packages';
        $package = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_packages WHERE id = %d", $package_id));
        
        if (!$package) {
            return array(
                'success' => false,
                'message' => 'Invalid subscription package.'
            );
        }
        
        if ($package->is_trial != 1) {
            return array(
                'success' => false,
                'message' => 'The selected package is not a free trial package.'
            );
        }
        
        // Check if user has already used a free trial (except for admins)
        if (!current_user_can('manage_options')) {
            $voucher_manager = new Mexplay_OTT_Premium_Voucher();
            $has_used_trial = $voucher_manager->has_used_free_trial($user_id);
            
            if ($has_used_trial) {
                return array(
                    'success' => false,
                    'message' => 'You have already used your free trial. Please select a paid package.'
                );
            }
        }
        
        // Create voucher
        $voucher_manager = new Mexplay_OTT_Premium_Voucher();
        $voucher_result = $voucher_manager->create_voucher($user_id, $package_id);
        
        if (!$voucher_result['success']) {
            return array(
                'success' => false,
                'message' => $voucher_result['message']
            );
        }
        
        // Create subscription record
        $table_subscriptions = $wpdb->prefix . 'mexplay_user_subscriptions';
        
        $wpdb->insert(
            $table_subscriptions,
            array(
                'user_id' => $user_id,
                'package_id' => $package_id,
                'voucher_id' => $voucher_result['voucher_id'],
                'payment_status' => 'free_trial',
                'payment_amount' => 0,
                'transaction_reference' => 'free_trial_' . time(),
                'created_at' => current_time('mysql')
            ),
            array('%d', '%d', '%d', '%s', '%f', '%s', '%s')
        );
        
        // Log activity
        $user_manager = new Mexplay_OTT_Premium_User();
        $user_manager->log_activity(
            $user_id,
            'free_trial_activated',
            "Free trial subscription activated for package: {$package->name}"
        );
        
        return array(
            'success' => true,
            'subscription_id' => $wpdb->insert_id,
            'voucher_id' => $voucher_result['voucher_id'],
            'voucher_code' => $voucher_result['voucher_code'],
            'expiry_date' => $voucher_result['valid_until'],
            'package_name' => $package->name
        );
    }

    /**
     * Create a paid subscription after successful payment.
     *
     * @since    1.0.0
     * @param    int      $user_id           The user ID.
     * @param    int      $package_id        The subscription package ID.
     * @param    float    $payment_amount    The payment amount.
     * @param    string   $payment_ref       Payment reference.
     * @param    string   $transaction_id    Transaction ID.
     * @return   array    Creation result with subscription details.
     */
    public function create_paid_subscription($user_id, $package_id, $payment_amount, $payment_ref, $transaction_id = '') {
        global $wpdb;
        
        // Check if package exists
        $table_packages = $wpdb->prefix . 'mexplay_subscription_packages';
        $package = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_packages WHERE id = %d", $package_id));
        
        if (!$package) {
            return array(
                'success' => false,
                'message' => 'Invalid subscription package.'
            );
        }
        
        // Create voucher
        $voucher_manager = new Mexplay_OTT_Premium_Voucher();
        $voucher_result = $voucher_manager->create_voucher($user_id, $package_id, $payment_ref);
        
        if (!$voucher_result['success']) {
            return array(
                'success' => false,
                'message' => $voucher_result['message']
            );
        }
        
        // Create subscription record
        $table_subscriptions = $wpdb->prefix . 'mexplay_user_subscriptions';
        
        $wpdb->insert(
            $table_subscriptions,
            array(
                'user_id' => $user_id,
                'package_id' => $package_id,
                'voucher_id' => $voucher_result['voucher_id'],
                'payment_id' => $transaction_id,
                'payment_status' => 'success',
                'payment_amount' => $payment_amount,
                'transaction_reference' => $payment_ref,
                'payment_date' => current_time('mysql'),
                'created_at' => current_time('mysql')
            ),
            array('%d', '%d', '%d', '%s', '%s', '%f', '%s', '%s', '%s')
        );
        
        // Log activity
        $user_manager = new Mexplay_OTT_Premium_User();
        $user_manager->log_activity(
            $user_id,
            'subscription_purchased',
            "Subscription purchased for package: {$package->name}. Payment reference: {$payment_ref}"
        );
        
        return array(
            'success' => true,
            'subscription_id' => $wpdb->insert_id,
            'voucher_id' => $voucher_result['voucher_id'],
            'voucher_code' => $voucher_result['voucher_code'],
            'expiry_date' => $voucher_result['valid_until'],
            'package_name' => $package->name
        );
    }

    /**
     * Renew an existing subscription.
     *
     * @since    1.0.0
     * @param    int      $user_id           The user ID.
     * @param    int      $package_id        The subscription package ID.
     * @param    float    $payment_amount    The payment amount.
     * @param    string   $payment_ref       Payment reference.
     * @param    string   $transaction_id    Transaction ID.
     * @return   array    Renewal result with subscription details.
     */
    public function renew_subscription($user_id, $package_id, $payment_amount, $payment_ref, $transaction_id = '') {
        // Deactivate existing active vouchers
        global $wpdb;
        $table_vouchers = $wpdb->prefix . 'mexplay_vouchers';
        
        $wpdb->update(
            $table_vouchers,
            array(
                'status' => 'renewed',
                'updated_at' => current_time('mysql')
            ),
            array(
                'user_id' => $user_id,
                'status' => 'active'
            ),
            array('%s', '%s'),
            array('%d', '%s')
        );
        
        // Create new subscription
        return $this->create_paid_subscription($user_id, $package_id, $payment_amount, $payment_ref, $transaction_id);
    }

    /**
     * Cancel a subscription (deactivate voucher).
     *
     * @since    1.0.0
     * @param    int      $user_id      The user ID.
     * @param    string   $reason       Reason for cancellation.
     * @return   bool     True if cancellation was successful, false otherwise.
     */
    public function cancel_subscription($user_id, $reason = 'User requested cancellation') {
        global $wpdb;
        $table_vouchers = $wpdb->prefix . 'mexplay_vouchers';
        
        // Get active vouchers for the user
        $active_vouchers = $wpdb->get_results($wpdb->prepare("
            SELECT id, voucher_code FROM $table_vouchers 
            WHERE user_id = %d AND status = 'active'
        ", $user_id));
        
        if (empty($active_vouchers)) {
            return false; // No active vouchers to cancel
        }
        
        $voucher_manager = new Mexplay_OTT_Premium_Voucher();
        $success = true;
        
        foreach ($active_vouchers as $voucher) {
            $result = $voucher_manager->deactivate_voucher($voucher->id, $reason);
            if (!$result) {
                $success = false; // At least one voucher failed to deactivate
            }
        }
        
        // Log activity
        $user_manager = new Mexplay_OTT_Premium_User();
        $user_manager->log_activity(
            $user_id,
            'subscription_cancelled',
            "Subscription cancelled. Reason: {$reason}"
        );
        
        return $success;
    }

    /**
     * Get all available subscription packages.
     *
     * @since    1.0.0
     * @param    bool     $active_only   Only return active packages.
     * @return   array    List of subscription packages.
     */
    public function get_subscription_packages($active_only = true) {
        global $wpdb;
        $table_packages = $wpdb->prefix . 'mexplay_subscription_packages';
        
        $where_clause = $active_only ? "WHERE status = 'active'" : "";
        
        $packages = $wpdb->get_results("
            SELECT * FROM $table_packages 
            $where_clause
            ORDER BY price ASC
        ");
        
        return $packages;
    }

    /**
     * Get subscription analytics data.
     *
     * @since    1.0.0
     * @param    string   $period     Time period: 'today', 'week', 'month', 'year', 'all'.
     * @return   array    Subscription analytics data.
     */
    public function get_subscription_analytics($period = 'all') {
        global $wpdb;
        $table_subscriptions = $wpdb->prefix . 'mexplay_user_subscriptions';
        
        // Set date range based on period
        $date_clause = '';
        $current_time = current_time('mysql');
        
        switch ($period) {
            case 'today':
                $date_clause = $wpdb->prepare("AND DATE(created_at) = DATE(%s)", $current_time);
                break;
            case 'week':
                $date_clause = $wpdb->prepare("AND created_at >= DATE_SUB(%s, INTERVAL 7 DAY)", $current_time);
                break;
            case 'month':
                $date_clause = $wpdb->prepare("AND created_at >= DATE_SUB(%s, INTERVAL 30 DAY)", $current_time);
                break;
            case 'year':
                $date_clause = $wpdb->prepare("AND created_at >= DATE_SUB(%s, INTERVAL 1 YEAR)", $current_time);
                break;
            default:
                $date_clause = '';
                break;
        }
        
        // Get total subscriptions
        $total_subscriptions = $wpdb->get_var("
            SELECT COUNT(*) 
            FROM $table_subscriptions 
            WHERE 1=1 $date_clause
        ");
        
        // Get total paid subscriptions
        $paid_subscriptions = $wpdb->get_var("
            SELECT COUNT(*) 
            FROM $table_subscriptions 
            WHERE payment_status = 'success' $date_clause
        ");
        
        // Get total free trials
        $free_trials = $wpdb->get_var("
            SELECT COUNT(*) 
            FROM $table_subscriptions 
            WHERE payment_status = 'free_trial' $date_clause
        ");
        
        // Get total revenue
        $total_revenue = $wpdb->get_var("
            SELECT SUM(payment_amount) 
            FROM $table_subscriptions 
            WHERE payment_status = 'success' $date_clause
        ");
        
        // Get subscriptions by package
        $subscriptions_by_package = $wpdb->get_results("
            SELECT p.name, COUNT(*) as count
            FROM $table_subscriptions s
            JOIN {$wpdb->prefix}mexplay_subscription_packages p ON s.package_id = p.id
            WHERE 1=1 $date_clause
            GROUP BY s.package_id
            ORDER BY count DESC
        ");
        
        return array(
            'total_subscriptions' => $total_subscriptions,
            'paid_subscriptions' => $paid_subscriptions,
            'free_trials' => $free_trials,
            'total_revenue' => $total_revenue,
            'subscriptions_by_package' => $subscriptions_by_package
        );
    }

    /**
     * Check for expiring subscriptions and send reminders.
     *
     * @since    1.0.0
     * @param    int      $days_threshold   Number of days before expiry to send reminders.
     * @return   int      Number of reminders sent.
     */
    public function send_expiry_reminders($days_threshold = 3) {
        $user_manager = new Mexplay_OTT_Premium_User();
        $expiring_vouchers = $user_manager->get_users_with_expiring_subscriptions($days_threshold);
        
        $count = 0;
        if (!empty($expiring_vouchers)) {
            $email_manager = new Mexplay_OTT_Premium_Email();
            
            foreach ($expiring_vouchers as $voucher) {
                $result = $email_manager->send_expiry_reminder_email(
                    $voucher->user_email,
                    $voucher->display_name,
                    $voucher->voucher_code,
                    $voucher->valid_until,
                    $voucher->package_name
                );
                
                if ($result) {
                    $count++;
                    
                    // Log activity
                    $user_manager->log_activity(
                        $voucher->user_id,
                        'expiry_reminder_sent',
                        "Subscription expiry reminder sent for voucher: {$voucher->voucher_code}"
                    );
                }
            }
        }
        
        return $count;
    }

    /**
     * Update payment status for a subscription.
     *
     * @since    1.0.0
     * @param    int      $subscription_id   The subscription ID.
     * @param    string   $payment_status    The new payment status.
     * @param    string   $transaction_id    Transaction ID (optional).
     * @return   bool     True if update was successful, false otherwise.
     */
    public function update_payment_status($subscription_id, $payment_status, $transaction_id = '') {
        global $wpdb;
        $table_subscriptions = $wpdb->prefix . 'mexplay_user_subscriptions';
        
        $data = array(
            'payment_status' => $payment_status,
            'payment_date' => current_time('mysql')
        );
        
        $format = array('%s', '%s');
        
        if (!empty($transaction_id)) {
            $data['payment_id'] = $transaction_id;
            $format[] = '%s';
        }
        
        $result = $wpdb->update(
            $table_subscriptions,
            $data,
            array('id' => $subscription_id),
            $format,
            array('%d')
        );
        
        if ($result) {
            // Get subscription details
            $subscription = $wpdb->get_row($wpdb->prepare("
                SELECT user_id, package_id, voucher_id 
                FROM $table_subscriptions 
                WHERE id = %d
            ", $subscription_id));
            
            if ($subscription) {
                // If payment was successful, activate voucher if it's not already active
                if ($payment_status === 'success') {
                    $table_vouchers = $wpdb->prefix . 'mexplay_vouchers';
                    $voucher_status = $wpdb->get_var($wpdb->prepare("
                        SELECT status FROM $table_vouchers WHERE id = %d
                    ", $subscription->voucher_id));
                    
                    if ($voucher_status !== 'active') {
                        $wpdb->update(
                            $table_vouchers,
                            array(
                                'status' => 'active',
                                'updated_at' => current_time('mysql')
                            ),
                            array('id' => $subscription->voucher_id),
                            array('%s', '%s'),
                            array('%d')
                        );
                    }
                }
                
                // Log activity
                $user_manager = new Mexplay_OTT_Premium_User();
                $user_manager->log_activity(
                    $subscription->user_id,
                    'payment_status_updated',
                    "Payment status updated to {$payment_status} for subscription ID {$subscription_id}"
                );
            }
            
            return true;
        }
        
        return false;
    }
}
