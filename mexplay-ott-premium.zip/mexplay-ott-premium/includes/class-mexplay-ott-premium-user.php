<?php
/**
 * User management functionality.
 *
 * @link       https://mexplay.com
 * @since      1.0.0
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/includes
 */

/**
 * User management functionality.
 *
 * This class handles user-related operations such as profile updates,
 * activity logging, and user subscriptions.
 *
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/includes
 */
class Mexplay_OTT_Premium_User {

    /**
     * Update user profile data.
     *
     * @since    1.0.0
     * @param    int      $user_id      The user ID.
     * @param    string   $first_name   User's first name.
     * @param    string   $last_name    User's last name.
     * @param    string   $email        User's email address.
     * @param    string   $phone        User's phone number.
     * @return   array    Update result.
     */
    public function update_user_data($user_id, $first_name, $last_name, $email, $phone) {
        // Check if user exists
        $user = get_user_by('id', $user_id);
        
        if (!$user) {
            return array(
                'success' => false,
                'message' => 'User not found.'
            );
        }
        
        // Validate email
        if (!empty($email) && $email !== $user->user_email) {
            if (!is_email($email)) {
                return array(
                    'success' => false,
                    'message' => 'Invalid email address.'
                );
            }
            
            if (email_exists($email) && email_exists($email) != $user_id) {
                return array(
                    'success' => false,
                    'message' => 'Email address already in use by another account.'
                );
            }
            
            // Update user email
            $result = wp_update_user(array(
                'ID' => $user_id,
                'user_email' => $email
            ));
            
            if (is_wp_error($result)) {
                return array(
                    'success' => false,
                    'message' => $result->get_error_message()
                );
            }
        }
        
        // Update user meta
        update_user_meta($user_id, 'first_name', sanitize_text_field($first_name));
        update_user_meta($user_id, 'last_name', sanitize_text_field($last_name));
        update_user_meta($user_id, 'mexplay_user_phone', sanitize_text_field($phone));
        
        // Update display name
        $display_name = trim($first_name . ' ' . $last_name);
        if (!empty($display_name)) {
            wp_update_user(array(
                'ID' => $user_id,
                'display_name' => $display_name
            ));
        }
        
        // Log activity
        $this->log_activity($user_id, 'profile_updated', 'User profile information updated.');
        
        return array(
            'success' => true,
            'message' => 'User data updated successfully.'
        );
    }

    /**
     * Log user activity.
     *
     * @since    1.0.0
     * @param    int      $user_id      The user ID (0 for guests).
     * @param    string   $action       The action performed.
     * @param    string   $description  Description of the activity.
     * @param    string   $ip_address   IP address (optional).
     * @return   int      The activity log ID.
     */
    public function log_activity($user_id, $action, $description, $ip_address = '') {
        global $wpdb;
        $table_name = $wpdb->prefix . 'mexplay_activity_logs';
        
        // Get IP address if not provided
        if (empty($ip_address)) {
            $ip_address = $this->get_user_ip();
        }
        
        // Get user agent
        $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
        
        // Insert activity log
        $wpdb->insert(
            $table_name,
            array(
                'user_id' => $user_id,
                'action' => $action,
                'description' => $description,
                'ip_address' => $ip_address,
                'user_agent' => $user_agent,
                'created_at' => current_time('mysql')
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s')
        );
        
        return $wpdb->insert_id;
    }

    /**
     * Get user's IP address.
     *
     * @since    1.0.0
     * @return   string   The user's IP address.
     */
    private function get_user_ip() {
        // Check for shared internet/ISP IP
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        // Check for IPs passing through proxies
        elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            // Can include multiple IPs, first one is the user's
            $ip_list = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $ip = trim($ip_list[0]);
        }
        // Check for real IP address
        elseif (!empty($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        // Fallback
        else {
            $ip = '0.0.0.0';
        }
        
        return sanitize_text_field($ip);
    }

    /**
     * Check if a user has an active subscription.
     *
     * @since    1.0.0
     * @param    int      $user_id    The user ID.
     * @return   bool     True if user has an active subscription, false otherwise.
     */
    public function has_active_subscription($user_id) {
        global $wpdb;
        $table_vouchers = $wpdb->prefix . 'mexplay_vouchers';
        
        $current_time = current_time('mysql');
        
        $count = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*) 
            FROM $table_vouchers 
            WHERE user_id = %d 
            AND status = 'active' 
            AND valid_until >= %s
        ", $user_id, $current_time));
        
        return $count > 0;
    }

    /**
     * Get user's subscription details.
     *
     * @since    1.0.0
     * @param    int      $user_id    The user ID.
     * @return   array    User's subscription details or null if none found.
     */
    public function get_user_subscription($user_id) {
        global $wpdb;
        
        $table_vouchers = $wpdb->prefix . 'mexplay_vouchers';
        $table_packages = $wpdb->prefix . 'mexplay_subscription_packages';
        
        $current_time = current_time('mysql');
        
        $subscription = $wpdb->get_row($wpdb->prepare("
            SELECT v.*, p.name as package_name, p.description as package_description, p.price, p.is_trial
            FROM $table_vouchers v
            JOIN $table_packages p ON v.package_id = p.id
            WHERE v.user_id = %d 
            AND v.status = 'active' 
            AND v.valid_until >= %s
            ORDER BY v.created_at DESC
            LIMIT 1
        ", $user_id, $current_time));
        
        return $subscription;
    }

    /**
     * Assign a subscription package to a user (admin function).
     *
     * @since    1.0.0
     * @param    int      $user_id      The user ID.
     * @param    int      $package_id   The package ID to assign.
     * @return   array    Assignment result.
     */
    public function assign_package_to_user($user_id, $package_id) {
        // Verify user exists
        $user = get_user_by('id', $user_id);
        if (!$user) {
            return array(
                'success' => false,
                'message' => 'User not found.'
            );
        }
        
        // Create voucher for the user
        $voucher_manager = new Mexplay_OTT_Premium_Voucher();
        $voucher_result = $voucher_manager->create_voucher($user_id, $package_id);
        
        if (!$voucher_result['success']) {
            return array(
                'success' => false,
                'message' => $voucher_result['message']
            );
        }
        
        // Create subscription record
        global $wpdb;
        $table_name = $wpdb->prefix . 'mexplay_user_subscriptions';
        
        $wpdb->insert(
            $table_name,
            array(
                'user_id' => $user_id,
                'package_id' => $package_id,
                'voucher_id' => $voucher_result['voucher_id'],
                'payment_status' => 'admin_assigned',
                'payment_amount' => 0,
                'transaction_reference' => 'admin_assigned_' . time(),
                'created_at' => current_time('mysql')
            ),
            array('%d', '%d', '%d', '%s', '%f', '%s', '%s')
        );
        
        // Log activity
        $this->log_activity(
            get_current_user_id(), // Admin user ID
            'package_assigned', 
            "Package ID {$package_id} assigned to user ID {$user_id} with voucher {$voucher_result['voucher_code']}."
        );
        
        // Send welcome email
        $email_manager = new Mexplay_OTT_Premium_Email();
        $email_manager->send_welcome_email(
            $user->user_email,
            $user->display_name,
            $voucher_result['voucher_code'],
            $voucher_result['valid_until'],
            $voucher_result['package_name']
        );
        
        return array(
            'success' => true,
            'message' => 'Package assigned successfully. Voucher: ' . $voucher_result['voucher_code']
        );
    }

    /**
     * Get user subscription history.
     *
     * @since    1.0.0
     * @param    int      $user_id    The user ID.
     * @param    int      $limit      Maximum number of records to return.
     * @return   array    Subscription history.
     */
    public function get_subscription_history($user_id, $limit = 10) {
        global $wpdb;
        
        $table_subscriptions = $wpdb->prefix . 'mexplay_user_subscriptions';
        $table_packages = $wpdb->prefix . 'mexplay_subscription_packages';
        $table_vouchers = $wpdb->prefix . 'mexplay_vouchers';
        
        $history = $wpdb->get_results($wpdb->prepare("
            SELECT s.*, p.name as package_name, v.voucher_code, v.valid_until, v.valid_from
            FROM $table_subscriptions s
            JOIN $table_packages p ON s.package_id = p.id
            JOIN $table_vouchers v ON s.voucher_id = v.id
            WHERE s.user_id = %d
            ORDER BY s.created_at DESC
            LIMIT %d
        ", $user_id, $limit));
        
        return $history;
    }

    /**
     * Check if user is suspended.
     *
     * @since    1.0.0
     * @param    int      $user_id    The user ID.
     * @return   bool     True if user is suspended, false otherwise.
     */
    public function is_user_suspended($user_id) {
        $suspended = get_user_meta($user_id, 'mexplay_suspended', true);
        return !empty($suspended);
    }

    /**
     * Suspend or unsuspend a user.
     *
     * @since    1.0.0
     * @param    int      $user_id     The user ID.
     * @param    bool     $suspend     True to suspend, false to unsuspend.
     * @param    string   $reason      Reason for suspension.
     * @return   bool     Operation result.
     */
    public function toggle_user_suspension($user_id, $suspend = true, $reason = '') {
        // Check if user exists
        $user = get_user_by('id', $user_id);
        if (!$user) {
            return false;
        }
        
        if ($suspend) {
            // Suspend user
            update_user_meta($user_id, 'mexplay_suspended', '1');
            
            // Deactivate all active vouchers
            global $wpdb;
            $table_vouchers = $wpdb->prefix . 'mexplay_vouchers';
            
            $active_vouchers = $wpdb->get_results($wpdb->prepare("
                SELECT id FROM $table_vouchers 
                WHERE user_id = %d AND status = 'active'
            ", $user_id));
            
            $voucher_manager = new Mexplay_OTT_Premium_Voucher();
            foreach ($active_vouchers as $voucher) {
                $voucher_manager->deactivate_voucher($voucher->id, 'User suspended: ' . $reason);
            }
            
            // Log activity
            $this->log_activity(
                get_current_user_id(),
                'user_suspended',
                "User ID {$user_id} suspended. Reason: {$reason}"
            );
        } else {
            // Unsuspend user
            delete_user_meta($user_id, 'mexplay_suspended');
            
            // Log activity
            $this->log_activity(
                get_current_user_id(),
                'user_unsuspended',
                "User ID {$user_id} unsuspended."
            );
        }
        
        return true;
    }

    /**
     * Get users with expiring subscriptions.
     *
     * @since    1.0.0
     * @param    int      $days_threshold   Number of days before expiry to check.
     * @return   array    List of users with expiring subscriptions.
     */
    public function get_users_with_expiring_subscriptions($days_threshold = 3) {
        $voucher_manager = new Mexplay_OTT_Premium_Voucher();
        return $voucher_manager->get_expiring_vouchers($days_threshold);
    }

    /**
     * Search users by various criteria.
     *
     * @since    1.0.0
     * @param    string   $search_term   Search term.
     * @param    int      $limit         Maximum number of users to return.
     * @param    int      $offset        Offset for pagination.
     * @return   array    Search results.
     */
    public function search_users($search_term, $limit = 20, $offset = 0) {
        global $wpdb;
        
        // Prepare search clause
        $search_clause = '';
        if (!empty($search_term)) {
            $search_like = '%' . $wpdb->esc_like($search_term) . '%';
            $search_clause = $wpdb->prepare(
                "AND (u.display_name LIKE %s OR u.user_email LIKE %s OR um_phone.meta_value LIKE %s)",
                $search_like,
                $search_like,
                $search_like
            );
        }
        
        // Get users with their subscription details
        $query = $wpdb->prepare("
            SELECT u.ID, u.user_login, u.display_name, u.user_email, u.user_registered,
                   um_phone.meta_value as phone,
                   um_suspended.meta_value as suspended,
                   v.voucher_code, v.valid_from, v.valid_until, v.status as voucher_status,
                   p.name as package_name, p.is_trial, p.id as package_id,
                   (SELECT COUNT(*) FROM {$wpdb->prefix}mexplay_user_subscriptions WHERE user_id = u.ID) as subscriptions_count
            FROM {$wpdb->prefix}users u
            LEFT JOIN {$wpdb->prefix}usermeta um_phone ON u.ID = um_phone.user_id AND um_phone.meta_key = 'mexplay_user_phone'
            LEFT JOIN {$wpdb->prefix}usermeta um_suspended ON u.ID = um_suspended.user_id AND um_suspended.meta_key = 'mexplay_suspended'
            LEFT JOIN (
                SELECT user_id, voucher_code, valid_from, valid_until, status, package_id
                FROM {$wpdb->prefix}mexplay_vouchers
                WHERE (user_id, created_at) IN (
                    SELECT user_id, MAX(created_at)
                    FROM {$wpdb->prefix}mexplay_vouchers
                    GROUP BY user_id
                )
            ) v ON u.ID = v.user_id
            LEFT JOIN {$wpdb->prefix}mexplay_subscription_packages p ON v.package_id = p.id
            WHERE 1=1 {$search_clause}
            ORDER BY u.user_registered DESC
            LIMIT %d OFFSET %d
        ", $limit, $offset);
        
        $users = $wpdb->get_results($query);
        
        // Count total users for pagination
        $count_query = "
            SELECT COUNT(DISTINCT u.ID)
            FROM {$wpdb->prefix}users u
            LEFT JOIN {$wpdb->prefix}usermeta um_phone ON u.ID = um_phone.user_id AND um_phone.meta_key = 'mexplay_user_phone'
            WHERE 1=1 {$search_clause}
        ";
        $total_users = $wpdb->get_var($count_query);
        
        return array(
            'users' => $users,
            'total' => $total_users
        );
    }
}
