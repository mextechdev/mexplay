<?php
/**
 * The core plugin class.
 *
 * @since      1.0.0
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * @since      1.0.0
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/includes
 */
class Mexplay_OTT_Premium {

    /**
     * The loader that's responsible for maintaining and registering all hooks that power
     * the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      Mexplay_OTT_Premium_Loader    $loader    Maintains and registers all hooks for the plugin.
     */
    protected $loader;

    /**
     * The unique identifier of this plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string    $plugin_name    The string used to uniquely identify this plugin.
     */
    protected $plugin_name;

    /**
     * The current version of the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string    $version    The current version of the plugin.
     */
    protected $version;

    /**
     * Define the core functionality of the plugin.
     *
     * @since    1.0.0
     */
    public function __construct() {
        if (defined('MEXPLAY_OTT_PREMIUM_VERSION')) {
            $this->version = MEXPLAY_OTT_PREMIUM_VERSION;
        } else {
            $this->version = '1.0.0';
        }
        $this->plugin_name = 'mexplay-ott-premium';

        $this->load_dependencies();
        $this->set_locale();
        $this->define_admin_hooks();
        $this->define_public_hooks();
        $this->define_shortcodes();
    }

    /**
     * Load the required dependencies for this plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function load_dependencies() {

        /**
         * The class responsible for orchestrating the actions and filters of the
         * core plugin.
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-mexplay-ott-premium-loader.php';

        /**
         * The class responsible for defining internationalization functionality
         * of the plugin.
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-mexplay-ott-premium-i18n.php';

        /**
         * The class responsible for defining all actions that occur in the admin area.
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'admin/class-mexplay-ott-premium-admin.php';

        /**
         * The class responsible for defining all actions that occur in the public-facing
         * side of the site.
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'public/class-mexplay-ott-premium-public.php';

        /**
         * Load core plugin classes
         */
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-mexplay-ott-premium-paystack.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-mexplay-ott-premium-voucher.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-mexplay-ott-premium-user.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-mexplay-ott-premium-subscription.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-mexplay-ott-premium-email.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-mexplay-ott-premium-shortcodes.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-mexplay-ott-premium-content-restriction.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-mexplay-ott-premium-db.php';

        $this->loader = new Mexplay_OTT_Premium_Loader();
        $this->db = new Mexplay_OTT_Premium_DB();
    }

    /**
     * Define the locale for this plugin for internationalization.
     *
     * @since    1.0.0
     * @access   private
     */
    private function set_locale() {
        $plugin_i18n = new Mexplay_OTT_Premium_i18n();
        $this->loader->add_action('plugins_loaded', $plugin_i18n, 'load_plugin_textdomain');
    }

    /**
     * Register all of the hooks related to the admin area functionality
     * of the plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_admin_hooks() {
        $plugin_admin = new Mexplay_OTT_Premium_Admin($this->get_plugin_name(), $this->get_version());

        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_styles');
        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts');
        $this->loader->add_action('admin_menu', $plugin_admin, 'add_admin_menu');
        
        // Hook for Paystack webhook handling
        $this->loader->add_action('rest_api_init', $plugin_admin, 'register_paystack_webhook_endpoint');

        // Custom admin AJAX endpoints
        $this->loader->add_action('wp_ajax_mexplay_add_subscription_package', $plugin_admin, 'add_subscription_package');
        $this->loader->add_action('wp_ajax_mexplay_edit_subscription_package', $plugin_admin, 'edit_subscription_package');
        $this->loader->add_action('wp_ajax_mexplay_delete_subscription_package', $plugin_admin, 'delete_subscription_package');
        $this->loader->add_action('wp_ajax_mexplay_manage_user', $plugin_admin, 'manage_user');
        $this->loader->add_action('wp_ajax_mexplay_test_email', $plugin_admin, 'test_email');
        $this->loader->add_action('wp_ajax_mexplay_save_email_template', $plugin_admin, 'save_email_template');
        $this->loader->add_action('wp_ajax_mexplay_save_paystack_settings', $plugin_admin, 'save_paystack_settings');
        
        // Content restriction metabox
        $content_restriction = new Mexplay_OTT_Premium_Content_Restriction();
        $this->loader->add_action('add_meta_boxes', $content_restriction, 'add_restriction_meta_box');
        $this->loader->add_action('save_post', $content_restriction, 'save_restriction_meta_box');
    }

    /**
     * Register all of the hooks related to the public-facing functionality
     * of the plugin.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_public_hooks() {
        $plugin_public = new Mexplay_OTT_Premium_Public($this->get_plugin_name(), $this->get_version());

        $this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_styles');
        $this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_scripts');
        
        // Custom session management
        $this->loader->add_action('init', $plugin_public, 'start_session', 1);
        $this->loader->add_action('wp_logout', $plugin_public, 'end_session');
        
        // Registration and login handlers
        $this->loader->add_action('init', $plugin_public, 'register_user_handler');
        $this->loader->add_action('init', $plugin_public, 'login_user_handler');
        
        // Subscription handling
        $this->loader->add_action('init', $plugin_public, 'handle_subscription_selection');
        
        // Hook for Paystack callback processing
        $this->loader->add_action('init', $plugin_public, 'process_paystack_callback');
        
        // Content restriction
        $content_restriction = new Mexplay_OTT_Premium_Content_Restriction();
        $this->loader->add_filter('the_content', $content_restriction, 'restrict_content');

        // AJAX handlers for frontend
        $this->loader->add_action('wp_ajax_mexplay_update_profile', $plugin_public, 'update_profile');
        $this->loader->add_action('wp_ajax_mexplay_renew_subscription', $plugin_public, 'renew_subscription');
        $this->loader->add_action('wp_ajax_nopriv_mexplay_get_subscription_packages', $plugin_public, 'get_subscription_packages');
        $this->loader->add_action('wp_ajax_mexplay_get_subscription_packages', $plugin_public, 'get_subscription_packages');
    }

    /**
     * Register shortcodes.
     *
     * @since    1.0.0
     * @access   private
     */
    private function define_shortcodes() {
        $plugin_shortcodes = new Mexplay_OTT_Premium_Shortcodes($this->loader);
        $plugin_shortcodes->register_shortcodes();
    }

    /**
     * Run the loader to execute all of the hooks with WordPress.
     *
     * @since    1.0.0
     */
    public function run() {
        $this->loader->run();
    }

    /**
     * The name of the plugin used to uniquely identify it within the context of
     * WordPress and to define internationalization functionality.
     *
     * @since     1.0.0
     * @return    string    The name of the plugin.
     */
    public function get_plugin_name() {
        return $this->plugin_name;
    }

    /**
     * The reference to the class that orchestrates the hooks with the plugin.
     *
     * @since     1.0.0
     * @return    Mexplay_OTT_Premium_Loader    Orchestrates the hooks of the plugin.
     */
    public function get_loader() {
        return $this->loader;
    }

    /**
     * Retrieve the version number of the plugin.
     *
     * @since     1.0.0
     * @return    string    The version number of the plugin.
     */
    public function get_version() {
        return $this->version;
    }
    
    /**
     * Retrieve the database instance.
     *
     * @since     1.0.0
     * @return    Mexplay_OTT_Premium_DB    The database instance.
     */
    public function get_db() {
        return $this->db;
    }
}
