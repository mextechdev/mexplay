<?php
/**
 * Paystack payment gateway integration.
 *
 * @link       https://mexplay.com
 * @since      1.0.0
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/includes
 */

/**
 * Paystack payment gateway integration.
 *
 * This class manages the integration with Paystack payment gateway
 * for processing subscription payments.
 *
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/includes
 */
class Mexplay_OTT_Premium_Paystack {

    /**
     * Get Paystack API keys based on settings.
     *
     * @since    1.0.0
     * @return   array    The Paystack API keys.
     */
    private function get_paystack_keys() {
        $test_mode = get_option('mexplay_paystack_test_mode', 'yes');
        
        if ($test_mode === 'yes') {
            return array(
                'secret_key' => get_option('mexplay_paystack_test_secret_key', ''),
                'public_key' => get_option('mexplay_paystack_test_public_key', '')
            );
        } else {
            return array(
                'secret_key' => get_option('mexplay_paystack_live_secret_key', ''),
                'public_key' => get_option('mexplay_paystack_live_public_key', '')
            );
        }
    }

    /**
     * Initialize Paystack payment.
     *
     * @since    1.0.0
     * @param    string   $email        Customer email address.
     * @param    float    $amount       Payment amount in naira.
     * @param    string   $callback_url Callback URL for redirect after payment.
     * @param    array    $metadata     Additional metadata for the transaction.
     * @return   array    Payment initialization response.
     */
    public function initialize_payment($email, $amount, $callback_url, $metadata = array()) {
        $keys = $this->get_paystack_keys();
        $secret_key = $keys['secret_key'];
        
        if (empty($secret_key)) {
            return array(
                'status' => 'error',
                'message' => 'Paystack API key is not configured.',
                'data' => null
            );
        }
        
        // Convert amount to kobo (the smallest currency unit in Nigeria)
        $amount_in_kobo = $amount * 100;
        
        $url = 'https://api.paystack.co/transaction/initialize';
        
        $headers = array(
            'Authorization' => 'Bearer ' . $secret_key,
            'Content-Type' => 'application/json',
            'Cache-Control' => 'no-cache'
        );
        
        $body = array(
            'email' => $email,
            'amount' => $amount_in_kobo,
            'callback_url' => $callback_url,
            'metadata' => $metadata
        );
        
        $args = array(
            'headers' => $headers,
            'body' => json_encode($body),
            'timeout' => 60,
            'redirection' => 5,
            'httpversion' => '1.0',
            'blocking' => true,
            'sslverify' => true
        );
        
        $response = wp_remote_post($url, $args);
        
        if (is_wp_error($response)) {
            return array(
                'status' => 'error',
                'message' => $response->get_error_message(),
                'data' => null
            );
        }
        
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        if ($response_body['status']) {
            return array(
                'status' => 'success',
                'message' => $response_body['message'],
                'data' => $response_body['data']
            );
        } else {
            return array(
                'status' => 'error',
                'message' => $response_body['message'],
                'data' => null
            );
        }
    }

    /**
     * Verify Paystack transaction.
     *
     * @since    1.0.0
     * @param    string   $reference   Transaction reference.
     * @return   array    Verification response.
     */
    public function verify_transaction($reference) {
        $keys = $this->get_paystack_keys();
        $secret_key = $keys['secret_key'];
        
        if (empty($secret_key)) {
            return array(
                'status' => 'error',
                'message' => 'Paystack API key is not configured.',
                'data' => null
            );
        }
        
        $url = 'https://api.paystack.co/transaction/verify/' . rawurlencode($reference);
        
        $headers = array(
            'Authorization' => 'Bearer ' . $secret_key,
            'Cache-Control' => 'no-cache'
        );
        
        $args = array(
            'headers' => $headers,
            'timeout' => 60,
            'redirection' => 5,
            'httpversion' => '1.0',
            'blocking' => true,
            'sslverify' => true
        );
        
        $response = wp_remote_get($url, $args);
        
        if (is_wp_error($response)) {
            return array(
                'status' => 'error',
                'message' => $response->get_error_message(),
                'amount' => 0,
                'transaction_id' => null
            );
        }
        
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        if ($response_body['status']) {
            $data = $response_body['data'];
            
            if ($data['status'] === 'success') {
                return array(
                    'status' => 'success',
                    'message' => 'Transaction verified successfully',
                    'amount' => $data['amount'],
                    'transaction_id' => $data['id'],
                    'reference' => $data['reference'],
                    'customer_email' => $data['customer']['email']
                );
            } else {
                return array(
                    'status' => 'error',
                    'message' => 'Transaction not successful: ' . $data['gateway_response'],
                    'amount' => 0,
                    'transaction_id' => null
                );
            }
        } else {
            return array(
                'status' => 'error',
                'message' => $response_body['message'],
                'amount' => 0,
                'transaction_id' => null
            );
        }
    }

    /**
     * Process Paystack webhook.
     *
     * @since    1.0.0
     * @param    WP_REST_Request $request The request object.
     * @return   array    Processing result.
     */
    public function process_webhook($request) {
        $keys = $this->get_paystack_keys();
        $secret_key = $keys['secret_key'];
        
        if (empty($secret_key)) {
            return array(
                'success' => false,
                'message' => 'Paystack API key is not configured.'
            );
        }
        
        // Retrieve the request body and parse JSON
        $input = file_get_contents('php://input');
        $event = json_decode($input, true);
        
        // Verify that the request is from Paystack
        $header_signature = isset($_SERVER['HTTP_X_PAYSTACK_SIGNATURE']) ? sanitize_text_field($_SERVER['HTTP_X_PAYSTACK_SIGNATURE']) : '';
        
        if (!$header_signature) {
            return array(
                'success' => false,
                'message' => 'Missing Paystack signature.'
            );
        }
        
        $calculated_signature = hash_hmac('sha512', $input, $secret_key);
        
        if ($calculated_signature !== $header_signature) {
            return array(
                'success' => false,
                'message' => 'Invalid Paystack signature.'
            );
        }
        
        if (!isset($event['event'])) {
            return array(
                'success' => false,
                'message' => 'Invalid event data.'
            );
        }
        
        // Handle the webhook event
        switch ($event['event']) {
            case 'charge.success':
                return $this->handle_successful_charge($event['data']);
                
            case 'subscription.create':
                return $this->handle_subscription_created($event['data']);
                
            case 'subscription.disable':
                return $this->handle_subscription_disabled($event['data']);
                
            default:
                return array(
                    'success' => true,
                    'message' => 'Event received but not processed: ' . $event['event']
                );
        }
    }

    /**
     * Handle successful charge webhook event.
     *
     * @since    1.0.0
     * @param    array    $data   Transaction data.
     * @return   array    Processing result.
     */
    private function handle_successful_charge($data) {
        global $wpdb;
        
        // Check if this payment has been processed before
        $table_subscriptions = $wpdb->prefix . 'mexplay_user_subscriptions';
        $existing_payment = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table_subscriptions WHERE payment_id = %s OR transaction_reference = %s",
            $data['id'],
            $data['reference']
        ));
        
        if ($existing_payment) {
            return array(
                'success' => true,
                'message' => 'Payment already processed.'
            );
        }
        
        // Get user by email
        $user = get_user_by('email', $data['customer']['email']);
        
        if (!$user) {
            return array(
                'success' => false,
                'message' => 'User not found for email: ' . $data['customer']['email']
            );
        }
        
        // Extract package ID from metadata if available
        $package_id = 0;
        if (isset($data['metadata']['custom_fields'])) {
            foreach ($data['metadata']['custom_fields'] as $field) {
                if ($field['variable_name'] === 'package_id') {
                    $package_id = intval($field['value']);
                    break;
                }
            }
        }
        
        if (empty($package_id)) {
            return array(
                'success' => false,
                'message' => 'Package ID not found in transaction metadata.'
            );
        }
        
        // Create subscription and voucher
        $subscription_manager = new Mexplay_OTT_Premium_Subscription();
        $result = $subscription_manager->create_paid_subscription(
            $user->ID,
            $package_id,
            $data['amount'] / 100, // Convert from kobo to naira
            $data['reference'],
            $data['id']
        );
        
        if ($result['success']) {
            // Send welcome email
            $email_manager = new Mexplay_OTT_Premium_Email();
            $email_manager->send_welcome_email(
                $user->user_email,
                $user->display_name,
                $result['voucher_code'],
                $result['expiry_date'],
                $result['package_name']
            );
            
            return array(
                'success' => true,
                'message' => 'Payment processed successfully: ' . $data['reference']
            );
        } else {
            return array(
                'success' => false,
                'message' => 'Failed to process payment: ' . $result['message']
            );
        }
    }

    /**
     * Handle subscription created webhook event.
     *
     * @since    1.0.0
     * @param    array    $data   Subscription data.
     * @return   array    Processing result.
     */
    private function handle_subscription_created($data) {
        // Log subscription creation
        $log_message = 'Subscription created: ' . $data['subscription_code'] . ' for customer: ' . $data['customer']['email'];
        error_log($log_message);
        
        return array(
            'success' => true,
            'message' => 'Subscription creation logged.'
        );
    }

    /**
     * Handle subscription disabled webhook event.
     *
     * @since    1.0.0
     * @param    array    $data   Subscription data.
     * @return   array    Processing result.
     */
    private function handle_subscription_disabled($data) {
        // Get user by email
        $user = get_user_by('email', $data['customer']['email']);
        
        if (!$user) {
            return array(
                'success' => false,
                'message' => 'User not found for email: ' . $data['customer']['email']
            );
        }
        
        // Disable active vouchers for this subscription code
        global $wpdb;
        $table_vouchers = $wpdb->prefix . 'mexplay_vouchers';
        
        $wpdb->update(
            $table_vouchers,
            array(
                'status' => 'inactive',
                'updated_at' => current_time('mysql')
            ),
            array(
                'user_id' => $user->ID,
                'status' => 'active'
            ),
            array('%s', '%s'),
            array('%d', '%s')
        );
        
        // Log subscription disabling
        $log_message = 'Subscription disabled: ' . $data['subscription_code'] . ' for customer: ' . $data['customer']['email'];
        error_log($log_message);
        
        return array(
            'success' => true,
            'message' => 'Subscription disabled successfully.'
        );
    }
}
