<?php
/**
 * Shortcodes functionality.
 *
 * @link       https://mexplay.com
 * @since      1.0.0
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/includes
 */

/**
 * Shortcodes functionality.
 *
 * This class handles all the shortcodes for the plugin.
 *
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/includes
 */
class Mexplay_OTT_Premium_Shortcodes {

    /**
     * The loader that's responsible for maintaining and registering all hooks that power
     * the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      Mexplay_OTT_Premium_Loader    $loader    Maintains and registers all hooks for the plugin.
     */
    protected $loader;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param    Mexplay_OTT_Premium_Loader    $loader    The loader object.
     */
    public function __construct($loader) {
        $this->loader = $loader;
    }

    /**
     * Register the shortcodes for the plugin.
     *
     * @since    1.0.0
     */
    public function register_shortcodes() {
        add_shortcode('mexplay_login', array($this, 'login_form_shortcode'));
        add_shortcode('mexplay_register', array($this, 'register_form_shortcode'));
        add_shortcode('mexplay_subscription', array($this, 'subscription_page_shortcode'));
        add_shortcode('mexplay_dashboard', array($this, 'user_dashboard_shortcode'));
        
        // Add body class filter for mexplay pages
        $this->loader->add_filter('body_class', $this, 'add_mexplay_body_class');
    }
    
    /**
     * Add mexplay-body class to body tag on mexplay pages.
     *
     * @since    1.0.0
     * @param    array    $classes    Current body classes.
     * @return   array    Modified body classes.
     */
    public function add_mexplay_body_class($classes) {
        global $post;
        
        if (is_object($post) && is_a($post, 'WP_Post')) {
            // Check if current page contains any of our shortcodes
            if (
                has_shortcode($post->post_content, 'mexplay_login') ||
                has_shortcode($post->post_content, 'mexplay_register') ||
                has_shortcode($post->post_content, 'mexplay_subscription') ||
                has_shortcode($post->post_content, 'mexplay_dashboard') ||
                strpos($post->post_name, 'mexplay-') === 0
            ) {
                $classes[] = 'mexplay-body';
            }
        }
        
        return $classes;
    }

    /**
     * Login form shortcode callback.
     *
     * @since    1.0.0
     * @param    array    $atts    Shortcode attributes.
     * @return   string   The login form HTML.
     */
    public function login_form_shortcode($atts) {
        ob_start();
        include_once MEXPLAY_OTT_PREMIUM_PLUGIN_DIR . 'public/partials/mexplay-ott-premium-login.php';
        return ob_get_clean();
    }

    /**
     * Register form shortcode callback.
     *
     * @since    1.0.0
     * @param    array    $atts    Shortcode attributes.
     * @return   string   The registration form HTML.
     */
    public function register_form_shortcode($atts) {
        ob_start();
        include_once MEXPLAY_OTT_PREMIUM_PLUGIN_DIR . 'public/partials/mexplay-ott-premium-register.php';
        return ob_get_clean();
    }

    /**
     * Subscription page shortcode callback.
     *
     * @since    1.0.0
     * @param    array    $atts    Shortcode attributes.
     * @return   string   The subscription page HTML.
     */
    public function subscription_page_shortcode($atts) {
        ob_start();
        include_once MEXPLAY_OTT_PREMIUM_PLUGIN_DIR . 'public/partials/mexplay-ott-premium-subscription.php';
        return ob_get_clean();
    }

    /**
     * User dashboard shortcode callback.
     *
     * @since    1.0.0
     * @param    array    $atts    Shortcode attributes.
     * @return   string   The user dashboard HTML.
     */
    public function user_dashboard_shortcode($atts) {
        ob_start();
        include_once MEXPLAY_OTT_PREMIUM_PLUGIN_DIR . 'public/partials/mexplay-ott-premium-dashboard.php';
        return ob_get_clean();
    }
}