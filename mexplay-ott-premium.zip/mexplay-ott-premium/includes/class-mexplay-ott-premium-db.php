<?php
/**
 * Database connection and operations functionality.
 *
 * @link       https://mexplay.com
 * @since      1.0.0
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/includes
 */

/**
 * Database connection and operations functionality.
 *
 * This class handles the database connection and operations for the plugin.
 *
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/includes
 */
class Mexplay_OTT_Premium_DB {

    /**
     * The database connection instance.
     *
     * @since    1.0.0
     * @access   private
     * @var      PDO    $conn    The database connection.
     */
    private $conn;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     */
    public function __construct() {
        $this->connect();
    }

    /**
     * Connect to the database.
     *
     * @since    1.0.0
     * @access   private
     */
    private function connect() {
        try {
            // First check if the pgsql driver is available
            if (!in_array('pgsql', PDO::getAvailableDrivers())) {
                throw new PDOException('could not find driver');
            }
            
            // In a real WordPress environment, these would be fetched from wp-config.php
            // For this demo, we're using environment variables
            $host = getenv('PGHOST');
            $port = getenv('PGPORT');
            $dbname = getenv('PGDATABASE');
            $user = getenv('PGUSER');
            $password = getenv('PGPASSWORD');
            
            $dsn = "pgsql:host={$host};port={$port};dbname={$dbname}";
            $this->conn = new PDO($dsn, $user, $password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            error_log('Database Connection Error: ' . $e->getMessage());
            
            // We'll comment out the error message about PostgreSQL driver since we have fallbacks
            // if ($e->getMessage() === 'could not find driver') {
            //     $admin_notice = 'MexPlay OTT Premium Plugin Error: The PostgreSQL PDO driver is not installed on your server. Please contact your hosting provider to install the php-pgsql extension.';
            //     add_action('admin_notices', function() use ($admin_notice) {
            //         echo '<div class="error"><p>' . esc_html($admin_notice) . '</p></div>';
            //     });
            // }
            
            // Fallback to MySQL if available for development/testing purposes only
            if (defined('WP_DEBUG') && WP_DEBUG && in_array('mysql', PDO::getAvailableDrivers())) {
                try {
                    global $wpdb;
                    $dsn = "mysql:host={$wpdb->dbhost};dbname={$wpdb->dbname}";
                    $this->conn = new PDO($dsn, $wpdb->dbuser, $wpdb->dbpassword);
                    $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    error_log('MexPlay: Fallback to MySQL connection established for development purposes');
                } catch (PDOException $mysql_e) {
                    error_log('MySQL Fallback Connection Error: ' . $mysql_e->getMessage());
                }
            }
        }
    }

    /**
     * Get all subscription packages.
     *
     * @since    1.0.0
     * @return   array   An array of subscription packages.
     */
    public function get_all_packages() {
        try {
            $stmt = $this->conn->prepare("SELECT * FROM mexplay_subscription_packages ORDER BY price ASC");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log('Database Query Error: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Get a subscription package by ID.
     *
     * @since    1.0.0
     * @param    int     $id   The package ID.
     * @return   array   The subscription package.
     */
    public function get_package_by_id($id) {
        try {
            $stmt = $this->conn->prepare("SELECT * FROM mexplay_subscription_packages WHERE id = :id");
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log('Database Query Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Add a new subscription package.
     *
     * @since    1.0.0
     * @param    array    $package_data   The package data.
     * @return   bool     True on success, false on failure.
     */
    public function add_package($package_data) {
        try {
            $stmt = $this->conn->prepare("
                INSERT INTO mexplay_subscription_packages 
                (name, description, duration, price, is_free_trial) 
                VALUES (:name, :description, :duration, :price, :is_free_trial)
            ");
            
            $stmt->bindParam(':name', $package_data['name'], PDO::PARAM_STR);
            $stmt->bindParam(':description', $package_data['description'], PDO::PARAM_STR);
            $stmt->bindParam(':duration', $package_data['duration'], PDO::PARAM_INT);
            $stmt->bindParam(':price', $package_data['price'], PDO::PARAM_STR);
            $stmt->bindParam(':is_free_trial', $package_data['is_free_trial'], PDO::PARAM_BOOL);
            
            return $stmt->execute();
        } catch (PDOException $e) {
            error_log('Database Query Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Update a subscription package.
     *
     * @since    1.0.0
     * @param    int      $id             The package ID.
     * @param    array    $package_data   The package data.
     * @return   bool     True on success, false on failure.
     */
    public function update_package($id, $package_data) {
        try {
            $stmt = $this->conn->prepare("
                UPDATE mexplay_subscription_packages 
                SET name = :name, 
                    description = :description, 
                    duration = :duration, 
                    price = :price, 
                    is_free_trial = :is_free_trial,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = :id
            ");
            
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->bindParam(':name', $package_data['name'], PDO::PARAM_STR);
            $stmt->bindParam(':description', $package_data['description'], PDO::PARAM_STR);
            $stmt->bindParam(':duration', $package_data['duration'], PDO::PARAM_INT);
            $stmt->bindParam(':price', $package_data['price'], PDO::PARAM_STR);
            $stmt->bindParam(':is_free_trial', $package_data['is_free_trial'], PDO::PARAM_BOOL);
            
            return $stmt->execute();
        } catch (PDOException $e) {
            error_log('Database Query Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Delete a subscription package.
     *
     * @since    1.0.0
     * @param    int      $id   The package ID.
     * @return   bool     True on success, false on failure.
     */
    public function delete_package($id) {
        try {
            $stmt = $this->conn->prepare("DELETE FROM mexplay_subscription_packages WHERE id = :id");
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (PDOException $e) {
            error_log('Database Query Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Get user subscriptions.
     *
     * @since    1.0.0
     * @param    int      $user_id   The user ID. If null, return all subscriptions.
     * @return   array    An array of user subscriptions.
     */
    public function get_user_subscriptions($user_id = null) {
        try {
            if ($user_id) {
                $stmt = $this->conn->prepare("
                    SELECT s.*, p.name as package_name, p.description as package_description 
                    FROM mexplay_user_subscriptions s
                    JOIN mexplay_subscription_packages p ON s.package_id = p.id
                    WHERE s.user_id = :user_id
                    ORDER BY s.created_at DESC
                ");
                $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            } else {
                $stmt = $this->conn->prepare("
                    SELECT s.*, p.name as package_name, p.description as package_description 
                    FROM mexplay_user_subscriptions s
                    JOIN mexplay_subscription_packages p ON s.package_id = p.id
                    ORDER BY s.created_at DESC
                ");
            }
            
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log('Database Query Error: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Get active user subscription.
     *
     * @since    1.0.0
     * @param    int      $user_id   The user ID.
     * @return   array    The active subscription or false if none exists.
     */
    public function get_active_subscription($user_id) {
        try {
            $stmt = $this->conn->prepare("
                SELECT s.*, p.name as package_name, p.description as package_description 
                FROM mexplay_user_subscriptions s
                JOIN mexplay_subscription_packages p ON s.package_id = p.id
                WHERE s.user_id = :user_id 
                AND s.status = 'active' 
                AND s.end_date > CURRENT_TIMESTAMP
                ORDER BY s.end_date DESC
                LIMIT 1
            ");
            
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log('Database Query Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Add a new user subscription.
     *
     * @since    1.0.0
     * @param    array    $subscription_data   The subscription data.
     * @return   int      The new subscription ID or false on failure.
     */
    public function add_subscription($subscription_data) {
        try {
            $this->conn->beginTransaction();
            
            $stmt = $this->conn->prepare("
                INSERT INTO mexplay_user_subscriptions 
                (user_id, package_id, start_date, end_date, status, payment_reference) 
                VALUES (:user_id, :package_id, :start_date, :end_date, :status, :payment_reference)
                RETURNING id
            ");
            
            $stmt->bindParam(':user_id', $subscription_data['user_id'], PDO::PARAM_INT);
            $stmt->bindParam(':package_id', $subscription_data['package_id'], PDO::PARAM_INT);
            $stmt->bindParam(':start_date', $subscription_data['start_date'], PDO::PARAM_STR);
            $stmt->bindParam(':end_date', $subscription_data['end_date'], PDO::PARAM_STR);
            $stmt->bindParam(':status', $subscription_data['status'], PDO::PARAM_STR);
            $stmt->bindParam(':payment_reference', $subscription_data['payment_reference'], PDO::PARAM_STR);
            
            $stmt->execute();
            $subscription_id = $stmt->fetchColumn();
            
            $this->conn->commit();
            return $subscription_id;
        } catch (PDOException $e) {
            $this->conn->rollBack();
            error_log('Database Query Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Generate and save a voucher code for a subscription.
     *
     * @since    1.0.0
     * @param    int      $subscription_id   The subscription ID.
     * @param    int      $user_id           The user ID.
     * @return   string   The generated voucher code or false on failure.
     */
    public function generate_voucher($subscription_id, $user_id) {
        try {
            // Generate a unique 12-character voucher code
            $code = strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 12));
            
            $stmt = $this->conn->prepare("
                INSERT INTO mexplay_vouchers 
                (code, subscription_id, user_id) 
                VALUES (:code, :subscription_id, :user_id)
                RETURNING code
            ");
            
            $stmt->bindParam(':code', $code, PDO::PARAM_STR);
            $stmt->bindParam(':subscription_id', $subscription_id, PDO::PARAM_INT);
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            
            $stmt->execute();
            return $stmt->fetchColumn();
        } catch (PDOException $e) {
            error_log('Database Query Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Get a voucher by code.
     *
     * @since    1.0.0
     * @param    string   $code   The voucher code.
     * @return   array    The voucher data or false if not found.
     */
    public function get_voucher_by_code($code) {
        try {
            $stmt = $this->conn->prepare("
                SELECT v.*, s.status as subscription_status, s.end_date as subscription_end_date 
                FROM mexplay_vouchers v
                JOIN mexplay_user_subscriptions s ON v.subscription_id = s.id
                WHERE v.code = :code
            ");
            
            $stmt->bindParam(':code', $code, PDO::PARAM_STR);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log('Database Query Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Validate a voucher code.
     *
     * @since    1.0.0
     * @param    string   $code      The voucher code.
     * @param    int      $user_id   The user ID.
     * @return   bool     True if valid, false otherwise.
     */
    public function validate_voucher($code, $user_id) {
        try {
            $stmt = $this->conn->prepare("
                SELECT v.*, s.status as subscription_status, s.end_date as subscription_end_date 
                FROM mexplay_vouchers v
                JOIN mexplay_user_subscriptions s ON v.subscription_id = s.id
                WHERE v.code = :code AND v.user_id = :user_id AND v.is_active = TRUE
                AND s.status = 'active' AND s.end_date > CURRENT_TIMESTAMP
            ");
            
            $stmt->bindParam(':code', $code, PDO::PARAM_STR);
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            error_log('Database Query Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Get a setting value.
     *
     * @since    1.0.0
     * @param    string   $setting_name   The setting name.
     * @return   string   The setting value or empty string if not found.
     */
    public function get_setting($setting_name) {
        try {
            $stmt = $this->conn->prepare("SELECT setting_value FROM mexplay_settings WHERE setting_name = :setting_name");
            $stmt->bindParam(':setting_name', $setting_name, PDO::PARAM_STR);
            $stmt->execute();
            
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result ? $result['setting_value'] : '';
        } catch (PDOException $e) {
            error_log('Database Query Error: ' . $e->getMessage());
            return '';
        }
    }

    /**
     * Update a setting.
     *
     * @since    1.0.0
     * @param    string   $setting_name    The setting name.
     * @param    string   $setting_value   The setting value.
     * @return   bool     True on success, false on failure.
     */
    public function update_setting($setting_name, $setting_value) {
        try {
            $stmt = $this->conn->prepare("
                UPDATE mexplay_settings 
                SET setting_value = :setting_value, updated_at = CURRENT_TIMESTAMP
                WHERE setting_name = :setting_name
            ");
            
            $stmt->bindParam(':setting_name', $setting_name, PDO::PARAM_STR);
            $stmt->bindParam(':setting_value', $setting_value, PDO::PARAM_STR);
            
            return $stmt->execute();
        } catch (PDOException $e) {
            error_log('Database Query Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Get an email template.
     *
     * @since    1.0.0
     * @param    string   $template_name   The template name.
     * @return   array    The email template or false if not found.
     */
    public function get_email_template($template_name) {
        try {
            $stmt = $this->conn->prepare("SELECT * FROM mexplay_email_templates WHERE template_name = :template_name");
            $stmt->bindParam(':template_name', $template_name, PDO::PARAM_STR);
            $stmt->execute();
            
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log('Database Query Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Update an email template.
     *
     * @since    1.0.0
     * @param    string   $template_name   The template name.
     * @param    string   $subject         The email subject.
     * @param    string   $body            The email body.
     * @return   bool     True on success, false on failure.
     */
    public function update_email_template($template_name, $subject, $body) {
        try {
            $stmt = $this->conn->prepare("
                UPDATE mexplay_email_templates 
                SET subject = :subject, body = :body, updated_at = CURRENT_TIMESTAMP
                WHERE template_name = :template_name
            ");
            
            $stmt->bindParam(':template_name', $template_name, PDO::PARAM_STR);
            $stmt->bindParam(':subject', $subject, PDO::PARAM_STR);
            $stmt->bindParam(':body', $body, PDO::PARAM_STR);
            
            return $stmt->execute();
        } catch (PDOException $e) {
            error_log('Database Query Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Log user activity.
     *
     * @since    1.0.0
     * @param    int      $user_id      The user ID.
     * @param    string   $action       The action performed.
     * @param    string   $details      Additional details.
     * @param    string   $ip_address   The user's IP address.
     * @return   bool     True on success, false on failure.
     */
    public function log_activity($user_id, $action, $details = '', $ip_address = '') {
        try {
            $stmt = $this->conn->prepare("
                INSERT INTO mexplay_activity_logs 
                (user_id, action, details, ip_address) 
                VALUES (:user_id, :action, :details, :ip_address)
            ");
            
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmt->bindParam(':action', $action, PDO::PARAM_STR);
            $stmt->bindParam(':details', $details, PDO::PARAM_STR);
            $stmt->bindParam(':ip_address', $ip_address, PDO::PARAM_STR);
            
            return $stmt->execute();
        } catch (PDOException $e) {
            error_log('Database Query Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Get user activity logs.
     *
     * @since    1.0.0
     * @param    int      $user_id   The user ID. If null, return all logs.
     * @param    int      $limit     The maximum number of logs to return.
     * @return   array    An array of activity logs.
     */
    public function get_activity_logs($user_id = null, $limit = 100) {
        try {
            if ($user_id) {
                $stmt = $this->conn->prepare("
                    SELECT * FROM mexplay_activity_logs 
                    WHERE user_id = :user_id 
                    ORDER BY created_at DESC 
                    LIMIT :limit
                ");
                $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
                $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            } else {
                $stmt = $this->conn->prepare("
                    SELECT * FROM mexplay_activity_logs 
                    ORDER BY created_at DESC 
                    LIMIT :limit
                ");
                $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            }
            
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log('Database Query Error: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Check if a user has had a free trial.
     *
     * @since    1.0.0
     * @param    int      $user_id   The user ID.
     * @return   bool     True if the user has had a free trial, false otherwise.
     */
    public function has_used_free_trial($user_id) {
        try {
            $stmt = $this->conn->prepare("
                SELECT COUNT(*) FROM mexplay_user_subscriptions s
                JOIN mexplay_subscription_packages p ON s.package_id = p.id
                WHERE s.user_id = :user_id AND p.is_free_trial = TRUE
            ");
            
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetchColumn() > 0;
        } catch (PDOException $e) {
            error_log('Database Query Error: ' . $e->getMessage());
            return false;
        }
    }
}