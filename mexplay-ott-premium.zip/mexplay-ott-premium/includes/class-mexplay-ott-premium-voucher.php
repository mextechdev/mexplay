<?php
/**
 * Voucher management.
 *
 * @link       https://mexplay.com
 * @since      1.0.0
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/includes
 */

/**
 * Voucher management.
 *
 * This class handles the generation, validation, and management
 * of subscription vouchers.
 *
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/includes
 */
class Mexplay_OTT_Premium_Voucher {

    /**
     * Generate a unique voucher code.
     *
     * @since    1.0.0
     * @param    int      $length    The length of the voucher code.
     * @return   string   The generated voucher code.
     */
    public function generate_voucher_code($length = 16) {
        $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        
        // Add dashes for readability
        $formattedString = substr($randomString, 0, 4) . '-' . 
                           substr($randomString, 4, 4) . '-' . 
                           substr($randomString, 8, 4) . '-' . 
                           substr($randomString, 12, 4);
        
        // Ensure the voucher code is unique
        global $wpdb;
        $table_name = $wpdb->prefix . 'mexplay_vouchers';
        $existing_voucher = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table_name WHERE voucher_code = %s", $formattedString));
        
        if ($existing_voucher) {
            // If the voucher code already exists, generate a new one recursively
            return $this->generate_voucher_code($length);
        }
        
        return $formattedString;
    }

    /**
     * Create a new voucher for a user and subscription package.
     *
     * @since    1.0.0
     * @param    int      $user_id       The user ID.
     * @param    int      $package_id    The subscription package ID.
     * @param    string   $payment_ref   Optional payment reference.
     * @return   array    Creation result with voucher details.
     */
    public function create_voucher($user_id, $package_id, $payment_ref = '') {
        global $wpdb;
        
        // Get package details
        $table_packages = $wpdb->prefix . 'mexplay_subscription_packages';
        $package = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_packages WHERE id = %d", $package_id));
        
        if (!$package) {
            return array(
                'success' => false,
                'message' => 'Invalid subscription package.'
            );
        }
        
        // Calculate validity period
        $valid_from = current_time('mysql');
        
        $valid_until = date('Y-m-d H:i:s', strtotime("+{$package->duration} {$package->duration_unit}", strtotime($valid_from)));
        
        // Generate voucher code
        $voucher_code = $this->generate_voucher_code();
        
        // Insert voucher into database
        $table_vouchers = $wpdb->prefix . 'mexplay_vouchers';
        
        $result = $wpdb->insert(
            $table_vouchers,
            array(
                'user_id' => $user_id,
                'voucher_code' => $voucher_code,
                'package_id' => $package_id,
                'status' => 'active',
                'valid_from' => $valid_from,
                'valid_until' => $valid_until,
                'payment_reference' => $payment_ref,
                'created_at' => current_time('mysql')
            ),
            array('%d', '%s', '%d', '%s', '%s', '%s', '%s', '%s')
        );
        
        if (!$result) {
            return array(
                'success' => false,
                'message' => 'Failed to create voucher. Database error: ' . $wpdb->last_error
            );
        }
        
        $voucher_id = $wpdb->insert_id;
        
        // Log activity
        $user_manager = new Mexplay_OTT_Premium_User();
        $user_manager->log_activity($user_id, 'voucher_created', "Voucher {$voucher_code} created for package {$package->name}.");
        
        return array(
            'success' => true,
            'voucher_id' => $voucher_id,
            'voucher_code' => $voucher_code,
            'valid_from' => $valid_from,
            'valid_until' => $valid_until,
            'package_name' => $package->name,
            'is_trial' => $package->is_trial
        );
    }

    /**
     * Validate a voucher code for a user.
     *
     * @since    1.0.0
     * @param    string   $voucher_code   The voucher code to validate.
     * @param    int      $user_id        The user ID.
     * @return   array    Validation result.
     */
    public function validate_voucher($voucher_code, $user_id) {
        global $wpdb;
        $table_vouchers = $wpdb->prefix . 'mexplay_vouchers';
        
        // Get voucher from database
        $voucher = $wpdb->get_row($wpdb->prepare("
            SELECT v.*, p.name as package_name 
            FROM $table_vouchers v
            JOIN {$wpdb->prefix}mexplay_subscription_packages p ON v.package_id = p.id
            WHERE v.voucher_code = %s
        ", $voucher_code));
        
        if (!$voucher) {
            return array(
                'valid' => false,
                'message' => 'Invalid voucher code.'
            );
        }
        
        // Check if voucher belongs to the user
        if ($voucher->user_id != $user_id) {
            return array(
                'valid' => false,
                'message' => 'This voucher code does not belong to your account.'
            );
        }
        
        // Check if voucher is active
        if ($voucher->status !== 'active') {
            return array(
                'valid' => false,
                'message' => 'This voucher is no longer active.'
            );
        }
        
        // Check if voucher is not expired
        $current_time = current_time('timestamp');
        $expiry_time = strtotime($voucher->valid_until);
        
        if ($current_time > $expiry_time) {
            // Update voucher status to expired
            $wpdb->update(
                $table_vouchers,
                array('status' => 'expired', 'updated_at' => current_time('mysql')),
                array('id' => $voucher->id),
                array('%s', '%s'),
                array('%d')
            );
            
            return array(
                'valid' => false,
                'message' => 'This voucher has expired. Please renew your subscription.'
            );
        }
        
        // Log successful validation
        $user_manager = new Mexplay_OTT_Premium_User();
        $user_manager->log_activity($user_id, 'voucher_validated', "Voucher {$voucher_code} validated successfully.");
        
        return array(
            'valid' => true,
            'voucher' => $voucher,
            'message' => 'Voucher validated successfully.'
        );
    }

    /**
     * Check if a user has already used a free trial.
     *
     * @since    1.0.0
     * @param    int      $user_id    The user ID.
     * @return   bool     True if the user has used a free trial, false otherwise.
     */
    public function has_used_free_trial($user_id) {
        global $wpdb;
        
        $table_vouchers = $wpdb->prefix . 'mexplay_vouchers';
        $table_packages = $wpdb->prefix . 'mexplay_subscription_packages';
        
        $has_trial = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*) 
            FROM $table_vouchers v
            JOIN $table_packages p ON v.package_id = p.id
            WHERE v.user_id = %d AND p.is_trial = 1
        ", $user_id));
        
        return $has_trial > 0;
    }

    /**
     * Expire all vouchers that have passed their valid_until date.
     *
     * @since    1.0.0
     * @return   int      Number of vouchers expired.
     */
    public function expire_outdated_vouchers() {
        global $wpdb;
        $table_vouchers = $wpdb->prefix . 'mexplay_vouchers';
        
        $current_time = current_time('mysql');
        
        $result = $wpdb->query($wpdb->prepare("
            UPDATE $table_vouchers 
            SET status = 'expired', updated_at = %s
            WHERE status = 'active' AND valid_until < %s
        ", $current_time, $current_time));
        
        return $result;
    }

    /**
     * Get active vouchers that are about to expire.
     *
     * @since    1.0.0
     * @param    int      $days_threshold   Number of days before expiry to check.
     * @return   array    List of vouchers about to expire.
     */
    public function get_expiring_vouchers($days_threshold = 3) {
        global $wpdb;
        
        $table_vouchers = $wpdb->prefix . 'mexplay_vouchers';
        $table_packages = $wpdb->prefix . 'mexplay_subscription_packages';
        
        $current_time = current_time('mysql');
        $threshold_date = date('Y-m-d H:i:s', strtotime("+{$days_threshold} days", strtotime($current_time)));
        
        $vouchers = $wpdb->get_results($wpdb->prepare("
            SELECT v.*, u.user_email, u.display_name, p.name as package_name
            FROM $table_vouchers v
            JOIN {$wpdb->users} u ON v.user_id = u.ID
            JOIN $table_packages p ON v.package_id = p.id
            WHERE v.status = 'active' 
            AND v.valid_until BETWEEN %s AND %s
        ", $current_time, $threshold_date));
        
        return $vouchers;
    }

    /**
     * Deactivate a voucher.
     *
     * @since    1.0.0
     * @param    int      $voucher_id   The voucher ID.
     * @param    string   $reason       Reason for deactivation.
     * @return   bool     True if deactivation was successful, false otherwise.
     */
    public function deactivate_voucher($voucher_id, $reason = '') {
        global $wpdb;
        $table_vouchers = $wpdb->prefix . 'mexplay_vouchers';
        
        $voucher = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_vouchers WHERE id = %d", $voucher_id));
        
        if (!$voucher) {
            return false;
        }
        
        $result = $wpdb->update(
            $table_vouchers,
            array(
                'status' => 'inactive',
                'updated_at' => current_time('mysql')
            ),
            array('id' => $voucher_id),
            array('%s', '%s'),
            array('%d')
        );
        
        if ($result) {
            // Log activity
            $user_manager = new Mexplay_OTT_Premium_User();
            $user_manager->log_activity(
                $voucher->user_id, 
                'voucher_deactivated', 
                "Voucher {$voucher->voucher_code} deactivated. Reason: {$reason}"
            );
            
            return true;
        }
        
        return false;
    }

    /**
     * Reactivate an inactive voucher.
     *
     * @since    1.0.0
     * @param    int      $voucher_id        The voucher ID.
     * @param    string   $new_valid_until   New expiry date (optional).
     * @return   bool     True if reactivation was successful, false otherwise.
     */
    public function reactivate_voucher($voucher_id, $new_valid_until = '') {
        global $wpdb;
        $table_vouchers = $wpdb->prefix . 'mexplay_vouchers';
        
        $voucher = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_vouchers WHERE id = %d", $voucher_id));
        
        if (!$voucher) {
            return false;
        }
        
        $update_data = array(
            'status' => 'active',
            'updated_at' => current_time('mysql')
        );
        
        $update_format = array('%s', '%s');
        
        if (!empty($new_valid_until)) {
            $update_data['valid_until'] = $new_valid_until;
            $update_format[] = '%s';
        }
        
        $result = $wpdb->update(
            $table_vouchers,
            $update_data,
            array('id' => $voucher_id),
            $update_format,
            array('%d')
        );
        
        if ($result) {
            // Log activity
            $user_manager = new Mexplay_OTT_Premium_User();
            $user_manager->log_activity(
                $voucher->user_id, 
                'voucher_reactivated', 
                "Voucher {$voucher->voucher_code} reactivated."
            );
            
            return true;
        }
        
        return false;
    }

    /**
     * Get all active vouchers for a user.
     *
     * @since    1.0.0
     * @param    int      $user_id    The user ID.
     * @return   array    List of active vouchers.
     */
    public function get_user_active_vouchers($user_id) {
        global $wpdb;
        
        $table_vouchers = $wpdb->prefix . 'mexplay_vouchers';
        $table_packages = $wpdb->prefix . 'mexplay_subscription_packages';
        
        $current_time = current_time('mysql');
        
        $vouchers = $wpdb->get_results($wpdb->prepare("
            SELECT v.*, p.name as package_name, p.description as package_description, p.is_trial
            FROM $table_vouchers v
            JOIN $table_packages p ON v.package_id = p.id
            WHERE v.user_id = %d 
            AND v.status = 'active' 
            AND v.valid_until >= %s
            ORDER BY v.created_at DESC
        ", $user_id, $current_time));
        
        return $vouchers;
    }
}
