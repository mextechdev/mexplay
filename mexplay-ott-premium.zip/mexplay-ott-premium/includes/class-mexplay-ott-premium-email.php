<?php
/**
 * Email functionality.
 *
 * @link       https://mexplay.com
 * @since      1.0.0
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/includes
 */

/**
 * Email functionality.
 *
 * This class handles the sending of email notifications to users.
 *
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/includes
 */
class Mexplay_OTT_Premium_Email {

    /**
     * Send an email using WordPress mail function or SMTP.
     *
     * @since    1.0.0
     * @param    string   $to          Recipient email address.
     * @param    string   $subject     Email subject.
     * @param    string   $message     Email message (HTML).
     * @param    array    $headers     Additional headers.
     * @param    array    $attachments Attachments.
     * @return   bool     Whether the email was sent successfully.
     */
    public function send_email($to, $subject, $message, $headers = array(), $attachments = array()) {
        // Get SMTP settings
        $smtp_host = get_option('mexplay_smtp_host', '');
        
        // Use WordPress mail if no SMTP host is configured
        if (empty($smtp_host)) {
            return $this->send_wp_mail($to, $subject, $message, $headers, $attachments);
        }
        
        // Use SMTP
        return $this->send_smtp_email($to, $subject, $message, $headers, $attachments);
    }

    /**
     * Send email using WordPress mail function.
     *
     * @since    1.0.0
     * @param    string   $to          Recipient email address.
     * @param    string   $subject     Email subject.
     * @param    string   $message     Email message (HTML).
     * @param    array    $headers     Additional headers.
     * @param    array    $attachments Attachments.
     * @return   bool     Whether the email was sent successfully.
     */
    private function send_wp_mail($to, $subject, $message, $headers = array(), $attachments = array()) {
        // Get from name and email
        $from_email = get_option('mexplay_smtp_from_email', get_option('admin_email'));
        $from_name = get_option('mexplay_smtp_from_name', get_option('blogname'));
        
        // Set default headers if not provided
        if (empty($headers)) {
            $headers = array(
                'Content-Type: text/html; charset=UTF-8',
                'From: ' . $from_name . ' <' . $from_email . '>'
            );
        }
        
        // Send email
        return wp_mail($to, $subject, $message, $headers, $attachments);
    }

    /**
     * Send email using SMTP.
     *
     * @since    1.0.0
     * @param    string   $to          Recipient email address.
     * @param    string   $subject     Email subject.
     * @param    string   $message     Email message (HTML).
     * @param    array    $headers     Additional headers.
     * @param    array    $attachments Attachments.
     * @return   bool     Whether the email was sent successfully.
     */
    private function send_smtp_email($to, $subject, $message, $headers = array(), $attachments = array()) {
        // Get SMTP settings
        $smtp_host = get_option('mexplay_smtp_host', '');
        $smtp_port = get_option('mexplay_smtp_port', '587');
        $smtp_username = get_option('mexplay_smtp_username', '');
        $smtp_password = get_option('mexplay_smtp_password', '');
        $smtp_from_email = get_option('mexplay_smtp_from_email', get_option('admin_email'));
        $smtp_from_name = get_option('mexplay_smtp_from_name', get_option('blogname'));
        $smtp_encryption = get_option('mexplay_smtp_encryption', 'tls');
        
        // Configure PHPMailer
        add_action('phpmailer_init', function($phpmailer) use ($smtp_host, $smtp_port, $smtp_username, $smtp_password, $smtp_from_email, $smtp_from_name, $smtp_encryption) {
            $phpmailer->isSMTP();
            $phpmailer->Host = $smtp_host;
            $phpmailer->SMTPAuth = true;
            $phpmailer->Port = $smtp_port;
            $phpmailer->Username = $smtp_username;
            $phpmailer->Password = $smtp_password;
            $phpmailer->From = $smtp_from_email;
            $phpmailer->FromName = $smtp_from_name;
            
            if ($smtp_encryption !== 'none') {
                $phpmailer->SMTPSecure = $smtp_encryption;
            }
        });
        
        // Use WordPress mail with SMTP configuration
        return $this->send_wp_mail($to, $subject, $message, $headers, $attachments);
    }

    /**
     * Send welcome email to a new subscriber.
     *
     * @since    1.0.0
     * @param    string   $to           Recipient email address.
     * @param    string   $user_name    User's name.
     * @param    string   $voucher_code Voucher code.
     * @param    string   $expiry_date  Voucher expiry date.
     * @param    string   $package_name Subscription package name.
     * @return   bool     Whether the email was sent successfully.
     */
    public function send_welcome_email($to, $user_name, $voucher_code, $expiry_date, $package_name) {
        $subject = get_option('mexplay_welcome_email_subject', 'Welcome to MexPlay OTT Premium');
        $body = get_option('mexplay_welcome_email_body', '<p>Hello {user_name},</p><p>Welcome to MexPlay OTT Premium! Thank you for registering.</p><p>Your subscription is now active.</p><p>Voucher Code: {voucher_code}</p><p>Valid Until: {expiry_date}</p><p>Enjoy your premium content!</p>');
        
        // Format expiry date
        $formatted_expiry = date('F j, Y', strtotime($expiry_date));
        
        // Replace placeholders
        $body = str_replace(
            array('{user_name}', '{voucher_code}', '{expiry_date}', '{package_name}', '{site_name}'),
            array($user_name, $voucher_code, $formatted_expiry, $package_name, get_option('blogname')),
            $body
        );
        
        // Add header and footer
        $header = get_option('mexplay_email_template_header', '<div style="background-color:#000000; color:#ffffff; padding:20px; text-align:center;"><h1 style="color:#d96e28;">MexPlay OTT Premium</h1></div>');
        $footer = get_option('mexplay_email_template_footer', '<div style="background-color:#000000; color:#ffffff; padding:20px; text-align:center;"><p>&copy; ' . date('Y') . ' MexPlay OTT Premium. All Rights Reserved.</p></div>');
        
        $message = $header . '<div style="padding: 20px;">' . $body . '</div>' . $footer;
        
        // Send email
        return $this->send_email($to, $subject, $message);
    }

    /**
     * Send expiry reminder email to a subscriber.
     *
     * @since    1.0.0
     * @param    string   $to           Recipient email address.
     * @param    string   $user_name    User's name.
     * @param    string   $voucher_code Voucher code.
     * @param    string   $expiry_date  Voucher expiry date.
     * @param    string   $package_name Subscription package name.
     * @return   bool     Whether the email was sent successfully.
     */
    public function send_expiry_reminder_email($to, $user_name, $voucher_code, $expiry_date, $package_name) {
        $subject = get_option('mexplay_expiry_email_subject', 'Your MexPlay OTT Premium Subscription is Expiring Soon');
        $body = get_option('mexplay_expiry_email_body', '<p>Hello {user_name},</p><p>Your subscription is about to expire on {expiry_date}.</p><p>To continue enjoying our premium content, please renew your subscription.</p><p>Thank you for being a valued member!</p>');
        
        // Format expiry date
        $formatted_expiry = date('F j, Y', strtotime($expiry_date));
        
        // Create login URL
        $login_url = site_url('/mexplay-login/');
        
        // Replace placeholders
        $body = str_replace(
            array('{user_name}', '{voucher_code}', '{expiry_date}', '{package_name}', '{site_name}', '{login_url}'),
            array($user_name, $voucher_code, $formatted_expiry, $package_name, get_option('blogname'), $login_url),
            $body
        );
        
        // Add header and footer
        $header = get_option('mexplay_email_template_header', '<div style="background-color:#000000; color:#ffffff; padding:20px; text-align:center;"><h1 style="color:#d96e28;">MexPlay OTT Premium</h1></div>');
        $footer = get_option('mexplay_email_template_footer', '<div style="background-color:#000000; color:#ffffff; padding:20px; text-align:center;"><p>&copy; ' . date('Y') . ' MexPlay OTT Premium. All Rights Reserved.</p></div>');
        
        $message = $header . '<div style="padding: 20px;">' . $body . '</div>' . $footer;
        
        // Send email
        return $this->send_email($to, $subject, $message);
    }

    /**
     * Send password reset email.
     *
     * @since    1.0.0
     * @param    string   $to           Recipient email address.
     * @param    string   $user_name    User's name.
     * @param    string   $new_password New password.
     * @return   bool     Whether the email was sent successfully.
     */
    public function send_password_reset_email($to, $user_name, $new_password) {
        $subject = 'Your MexPlay OTT Premium Password has been Reset';
        
        $body = '<p>Hello ' . $user_name . ',</p>';
        $body .= '<p>Your password has been reset by an administrator.</p>';
        $body .= '<p>Your new password is: <strong>' . $new_password . '</strong></p>';
        $body .= '<p>Please login using this new password and change it immediately for security.</p>';
        $body .= '<p>Login URL: <a href="' . site_url('/mexplay-login/') . '">' . site_url('/mexplay-login/') . '</a></p>';
        $body .= '<p>Thank you for using MexPlay OTT Premium!</p>';
        
        // Add header and footer
        $header = get_option('mexplay_email_template_header', '<div style="background-color:#000000; color:#ffffff; padding:20px; text-align:center;"><h1 style="color:#d96e28;">MexPlay OTT Premium</h1></div>');
        $footer = get_option('mexplay_email_template_footer', '<div style="background-color:#000000; color:#ffffff; padding:20px; text-align:center;"><p>&copy; ' . date('Y') . ' MexPlay OTT Premium. All Rights Reserved.</p></div>');
        
        $message = $header . '<div style="padding: 20px;">' . $body . '</div>' . $footer;
        
        // Send email
        return $this->send_email($to, $subject, $message);
    }

    /**
     * Send payment confirmation email.
     *
     * @since    1.0.0
     * @param    string   $to             Recipient email address.
     * @param    string   $user_name      User's name.
     * @param    string   $voucher_code   Voucher code.
     * @param    string   $expiry_date    Voucher expiry date.
     * @param    string   $package_name   Subscription package name.
     * @param    float    $payment_amount Payment amount.
     * @param    string   $payment_ref    Payment reference.
     * @return   bool     Whether the email was sent successfully.
     */
    public function send_payment_confirmation_email($to, $user_name, $voucher_code, $expiry_date, $package_name, $payment_amount, $payment_ref) {
        $subject = 'MexPlay OTT Premium Payment Confirmation';
        
        $body = '<p>Hello ' . $user_name . ',</p>';
        $body .= '<p>Thank you for your payment. Your subscription to MexPlay OTT Premium has been confirmed.</p>';
        
        $body .= '<div style="margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px;">';
        $body .= '<h3 style="margin-top: 0; color: #4e8457;">Payment Details</h3>';
        $body .= '<p><strong>Package:</strong> ' . $package_name . '</p>';
        $body .= '<p><strong>Amount Paid:</strong> ₦' . number_format($payment_amount, 2) . '</p>';
        $body .= '<p><strong>Payment Reference:</strong> ' . $payment_ref . '</p>';
        $body .= '<p><strong>Date:</strong> ' . date('F j, Y') . '</p>';
        $body .= '</div>';
        
        $body .= '<div style="margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px;">';
        $body .= '<h3 style="margin-top: 0; color: #d96e28;">Subscription Details</h3>';
        $body .= '<p><strong>Voucher Code:</strong> ' . $voucher_code . '</p>';
        $body .= '<p><strong>Valid Until:</strong> ' . date('F j, Y', strtotime($expiry_date)) . '</p>';
        $body .= '</div>';
        
        $body .= '<p>You can log in to your account using the voucher code above.</p>';
        $body .= '<p>Login URL: <a href="' . site_url('/mexplay-login/') . '">' . site_url('/mexplay-login/') . '</a></p>';
        $body .= '<p>Thank you for choosing MexPlay OTT Premium!</p>';
        
        // Add header and footer
        $header = get_option('mexplay_email_template_header', '<div style="background-color:#000000; color:#ffffff; padding:20px; text-align:center;"><h1 style="color:#d96e28;">MexPlay OTT Premium</h1></div>');
        $footer = get_option('mexplay_email_template_footer', '<div style="background-color:#000000; color:#ffffff; padding:20px; text-align:center;"><p>&copy; ' . date('Y') . ' MexPlay OTT Premium. All Rights Reserved.</p></div>');
        
        $message = $header . '<div style="padding: 20px;">' . $body . '</div>' . $footer;
        
        // Send email
        return $this->send_email($to, $subject, $message);
    }

    /**
     * Schedule expiry reminder emails.
     *
     * @since    1.0.0
     * @return   bool     Whether the scheduling was successful.
     */
    public function schedule_expiry_reminders() {
        if (!wp_next_scheduled('mexplay_check_expiring_subscriptions')) {
            wp_schedule_event(time(), 'daily', 'mexplay_check_expiring_subscriptions');
            
            // Add the action hook for the scheduled event
            add_action('mexplay_check_expiring_subscriptions', array($this, 'send_scheduled_reminders'));
            
            return true;
        }
        
        return false;
    }

    /**
     * Send scheduled reminders.
     *
     * @since    1.0.0
     */
    public function send_scheduled_reminders() {
        $subscription_manager = new Mexplay_OTT_Premium_Subscription();
        $reminders_sent = $subscription_manager->send_expiry_reminders(3); // 3 days before expiry
        
        error_log("MexPlay OTT Premium: Sent {$reminders_sent} expiry reminder emails.");
    }
}
