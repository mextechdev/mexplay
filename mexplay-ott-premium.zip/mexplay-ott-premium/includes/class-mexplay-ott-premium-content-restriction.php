<?php
/**
 * Content restriction functionality.
 *
 * @link       https://mexplay.com
 * @since      1.0.0
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/includes
 */

/**
 * Content restriction functionality.
 *
 * This class handles the content restriction based on user subscription status.
 *
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/includes
 */
class Mexplay_OTT_Premium_Content_Restriction {

    /**
     * Restrict content based on subscription status.
     *
     * @since    1.0.0
     * @param    string   $content   The content of the post.
     * @return   string   The filtered content.
     */
    public function restrict_content($content) {
        // Only apply restrictions to singular posts/pages
        if (!is_singular()) {
            return $content;
        }
        
        // Skip restriction for plugin's own pages
        global $post;
        if (has_shortcode($post->post_content, 'mexplay_login') || 
            has_shortcode($post->post_content, 'mexplay_register') || 
            has_shortcode($post->post_content, 'mexplay_subscription') ||
            has_shortcode($post->post_content, 'mexplay_dashboard')) {
            return $content;
        }
        
        // Skip restriction for administrators
        if (current_user_can('administrator')) {
            return $content;
        }
        
        // Check if post is restricted
        $is_restricted = get_post_meta($post->ID, 'mexplay_content_restricted', true);
        
        // If not restricted, return content as is
        if (!$is_restricted) {
            return $content;
        }
        
        // Check if user is logged in
        if (!is_user_logged_in()) {
            return $this->get_restricted_content_message('login_required');
        }
        
        // Check if user has active subscription
        $user_manager = new Mexplay_OTT_Premium_User();
        $current_user_id = get_current_user_id();
        
        if (!$user_manager->has_active_subscription($current_user_id)) {
            return $this->get_restricted_content_message('subscription_required');
        }
        
        // User has access, return the content
        return $content;
    }
    
    /**
     * Get the message to display when content is restricted.
     *
     * @since    1.0.0
     * @param    string   $reason   The reason for restriction ('login_required' or 'subscription_required').
     * @return   string   The restricted content message.
     */
    private function get_restricted_content_message($reason) {
        $message = '<div class="mexplay-restricted-content">';
        
        if ($reason === 'login_required') {
            $message .= '<h3>Premium Content</h3>';
            $message .= '<p>This content is only available to MexPlay premium subscribers.</p>';
            $message .= '<p>Please log in to access this content or subscribe to a membership plan.</p>';
            $message .= '<div class="mexplay-buttons">';
            $message .= '<a href="' . site_url('/mexplay-login/') . '" class="mexplay-button">Login</a>';
            $message .= '<a href="' . site_url('/mexplay-register/') . '" class="mexplay-button accent">Register</a>';
            $message .= '</div>';
        } else {
            $message .= '<h3>Premium Content</h3>';
            $message .= '<p>This content is only available to MexPlay premium subscribers.</p>';
            $message .= '<p>Your subscription has expired or you don\'t have an active subscription.</p>';
            $message .= '<div class="mexplay-buttons">';
            $message .= '<a href="' . site_url('/mexplay-subscription/') . '" class="mexplay-button accent">Subscribe Now</a>';
            $message .= '<a href="' . site_url('/mexplay-dashboard/') . '" class="mexplay-button">Go to Dashboard</a>';
            $message .= '</div>';
        }
        
        $message .= '</div>';
        
        return $message;
    }
    
    /**
     * Add meta box for content restriction in post/page editor.
     *
     * @since    1.0.0
     */
    public function add_restriction_meta_box() {
        add_meta_box(
            'mexplay_content_restriction',
            'MexPlay Content Restriction',
            array($this, 'render_restriction_meta_box'),
            array('post', 'page'),
            'side',
            'high'
        );
    }
    
    /**
     * Render the content restriction meta box.
     *
     * @since    1.0.0
     * @param    object   $post   The post object.
     */
    public function render_restriction_meta_box($post) {
        // Add nonce for security
        wp_nonce_field('mexplay_content_restriction_nonce', 'mexplay_content_restriction_nonce');
        
        // Get current value
        $is_restricted = get_post_meta($post->ID, 'mexplay_content_restricted', true);
        
        // Render checkbox
        echo '<div style="padding: 10px 0;">';
        echo '<label for="mexplay_content_restricted">';
        echo '<input type="checkbox" id="mexplay_content_restricted" name="mexplay_content_restricted" value="1" ' . checked($is_restricted, '1', false) . '>';
        echo ' Restrict access to premium subscribers only';
        echo '</label>';
        echo '</div>';
        
        echo '<p class="description">When checked, only users with an active subscription will be able to view this content.</p>';
    }
    
    /**
     * Save the content restriction meta box data.
     *
     * @since    1.0.0
     * @param    int      $post_id   The post ID.
     */
    public function save_restriction_meta_box($post_id) {
        // Check for nonce
        if (!isset($_POST['mexplay_content_restriction_nonce']) || 
            !wp_verify_nonce($_POST['mexplay_content_restriction_nonce'], 'mexplay_content_restriction_nonce')) {
            return;
        }
        
        // Check if this is an autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        // Check user permissions
        if (isset($_POST['post_type']) && 
            ('page' === $_POST['post_type'] || 'post' === $_POST['post_type'])) {
            if (!current_user_can('edit_page', $post_id) && !current_user_can('edit_post', $post_id)) {
                return;
            }
        }
        
        // Save the data
        if (isset($_POST['mexplay_content_restricted'])) {
            update_post_meta($post_id, 'mexplay_content_restricted', '1');
        } else {
            delete_post_meta($post_id, 'mexplay_content_restricted');
        }
    }
}