<?php
/**
 * Fired during plugin activation.
 *
 * @since      1.0.0
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Mexplay_OTT_Premium
 * @subpackage Mexplay_OTT_Premium/includes
 */
class Mexplay_OTT_Premium_Activator {

    /**
     * Activate the plugin and set up database tables.
     *
     * @since    1.0.0
     */
    public static function activate() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        // Create subscription packages table
        $table_packages = $wpdb->prefix . 'mexplay_subscription_packages';
        $sql_packages = "CREATE TABLE $table_packages (
            id int(11) NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            description text,
            price decimal(10,2) NOT NULL,
            duration int(11) NOT NULL,
            duration_unit varchar(20) NOT NULL,
            is_trial tinyint(1) NOT NULL DEFAULT 0,
            status varchar(20) NOT NULL DEFAULT 'active',
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        // Create vouchers table
        $table_vouchers = $wpdb->prefix . 'mexplay_vouchers';
        $sql_vouchers = "CREATE TABLE $table_vouchers (
            id int(11) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            voucher_code varchar(50) NOT NULL,
            package_id int(11) NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'active',
            valid_from datetime NOT NULL,
            valid_until datetime NOT NULL,
            payment_reference varchar(100),
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY voucher_code (voucher_code)
        ) $charset_collate;";

        // Create user subscription history table
        $table_subscriptions = $wpdb->prefix . 'mexplay_user_subscriptions';
        $sql_subscriptions = "CREATE TABLE $table_subscriptions (
            id int(11) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            package_id int(11) NOT NULL,
            voucher_id int(11) NOT NULL,
            payment_id varchar(100),
            payment_status varchar(20) NOT NULL DEFAULT 'pending',
            payment_amount decimal(10,2),
            transaction_reference varchar(100),
            payment_date datetime,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        // Create activity logs table
        $table_logs = $wpdb->prefix . 'mexplay_activity_logs';
        $sql_logs = "CREATE TABLE $table_logs (
            id int(11) NOT NULL AUTO_INCREMENT,
            user_id bigint(20),
            action varchar(100) NOT NULL,
            description text,
            ip_address varchar(45),
            user_agent text,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        // WordPress database upgrade function
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_packages);
        dbDelta($sql_vouchers);
        dbDelta($sql_subscriptions);
        dbDelta($sql_logs);
        
        // Create pages for the plugin if they don't exist
        self::create_pages();
        
        // Add default options
        add_option('mexplay_email_template_header', '<div style="background-color:#000000; color:#ffffff; padding:20px; text-align:center;"><h1 style="color:#d96e28;">MexPlay OTT Premium</h1></div>');
        add_option('mexplay_email_template_footer', '<div style="background-color:#000000; color:#ffffff; padding:20px; text-align:center;"><p>&copy; ' . date('Y') . ' MexPlay OTT Premium. All Rights Reserved.</p></div>');
        add_option('mexplay_welcome_email_subject', 'Welcome to MexPlay OTT Premium');
        add_option('mexplay_welcome_email_body', '<p>Hello {user_name},</p><p>Welcome to MexPlay OTT Premium! Thank you for registering.</p><p>Your subscription is now active.</p><p>Voucher Code: {voucher_code}</p><p>Valid Until: {expiry_date}</p><p>Enjoy your premium content!</p>');
        add_option('mexplay_expiry_email_subject', 'Your MexPlay OTT Premium Subscription is Expiring Soon');
        add_option('mexplay_expiry_email_body', '<p>Hello {user_name},</p><p>Your subscription is about to expire on {expiry_date}.</p><p>To continue enjoying our premium content, please renew your subscription.</p><p>Thank you for being a valued member!</p>');
        add_option('mexplay_smtp_host', '');
        add_option('mexplay_smtp_port', '587');
        add_option('mexplay_smtp_username', '');
        add_option('mexplay_smtp_password', '');
        add_option('mexplay_smtp_from_email', get_option('admin_email'));
        add_option('mexplay_smtp_from_name', get_option('blogname'));
        add_option('mexplay_smtp_encryption', 'tls');
        
        // Paystack settings
        add_option('mexplay_paystack_test_mode', 'yes');
        add_option('mexplay_paystack_test_secret_key', '');
        add_option('mexplay_paystack_test_public_key', '');
        add_option('mexplay_paystack_live_secret_key', '');
        add_option('mexplay_paystack_live_public_key', '');
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Create pages needed for the plugin
     */
    private static function create_pages() {
        $pages = array(
            'mexplay-login' => array(
                'title' => 'MexPlay Login',
                'content' => '[mexplay_login]',
            ),
            'mexplay-register' => array(
                'title' => 'MexPlay Register',
                'content' => '[mexplay_register]',
            ),
            'mexplay-subscription' => array(
                'title' => 'MexPlay Subscription',
                'content' => '[mexplay_subscription]',
            ),
            'mexplay-dashboard' => array(
                'title' => 'MexPlay Dashboard',
                'content' => '[mexplay_dashboard]',
            ),
            'mexplay-thank-you' => array(
                'title' => 'MexPlay Thank You',
                'content' => '<h2>Thank You for Your Subscription!</h2><p>Your payment has been processed successfully and your voucher has been generated.</p><p>Voucher details are available in your dashboard.</p><p><a href="' . site_url('/mexplay-login/') . '" class="mexplay-button">Login to Your Account</a></p>',
            ),
        );
        
        foreach ($pages as $slug => $page) {
            $existing_page = get_page_by_path($slug);
            
            if (!$existing_page) {
                wp_insert_post(array(
                    'post_title' => $page['title'],
                    'post_content' => $page['content'],
                    'post_status' => 'publish',
                    'post_type' => 'page',
                    'post_name' => $slug,
                ));
            }
        }
    }
}
